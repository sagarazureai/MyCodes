const form = document.getElementById("orchestrateForm");
const objectiveField = document.getElementById("objective");
const activeAgent = document.getElementById("activeAgent");
const scenarioApplied = document.getElementById("scenarioApplied");
const traceList = document.getElementById("traceList");
const kpiCards = document.getElementById("kpiCards");
const shortageList = document.getElementById("shortageList");
const lineUtilList = document.getElementById("lineUtilList");
const actionList = document.getElementById("actionList");
const demandChart = document.getElementById("demandChart");
const utilChart = document.getElementById("utilChart");
const gapChart = document.getElementById("gapChart");
const scenarioRulesList = document.getElementById("scenarioRulesList");

const escapeHtml = (value) =>
  String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");

const clearActiveNodes = () => {
  document.querySelectorAll(".agent-node").forEach((node) => node.classList.remove("active"));
  const root = document.querySelector('[data-agent="Manufacturing AI agent"]');
  if (root) root.classList.add("active");
};

const markActiveAgent = (agentName) => {
  clearActiveNodes();
  const activeNode = document.querySelector(`[data-agent="${agentName}"]`);
  if (activeNode) {
    activeNode.classList.add("active");
  }
};

const addTraceItem = (call) => {
  const li = document.createElement("li");
  const inputText = escapeHtml(JSON.stringify(call.input_snapshot || {}, null, 2));
  const outputText = escapeHtml(JSON.stringify(call.output_snapshot || {}, null, 2));

  li.innerHTML = `
    <div class="trace-head">
      <span class="trace-agent">${escapeHtml(call.agent || "")}</span>
      <span class="trace-id">${escapeHtml(call.id || "")}</span>
    </div>
    <p>${escapeHtml(call.action || "")}</p>
    <p class="trace-result">${escapeHtml(call.result || "")}</p>
    <div class="trace-payload-grid">
      <div class="trace-payload">
        <p>Input Payload</p>
        <pre>${inputText}</pre>
      </div>
      <div class="trace-payload">
        <p>Output Payload</p>
        <pre>${outputText}</pre>
      </div>
    </div>
  `;
  traceList.appendChild(li);
};

const renderBarChart = (container, rows, valueKey, valueSuffix = "", maxOverride = null) => {
  if (!container) return;
  if (!rows.length) {
    container.innerHTML = "<p class='muted'>No data</p>";
    return;
  }
  const maxValue = maxOverride ?? Math.max(...rows.map((row) => Number(row[valueKey]) || 0), 1);
  container.innerHTML = rows
    .map((row) => {
      const value = Number(row[valueKey]) || 0;
      const pct = Math.min(100, (value / maxValue) * 100);
      const label = escapeHtml(row.label || row.name || row.sku || row.line || row.material || "Item");
      return `
        <div class="bar-row">
          <span class="bar-label">${label}</span>
          <div class="bar-track"><div class="bar-fill" style="width:${pct}%"></div></div>
          <span class="bar-value">${value}${valueSuffix}</span>
        </div>
      `;
    })
    .join("");
};

const renderProcessedResults = (processed) => {
  const kpis = processed?.kpis || {};
  const shortages = processed?.shortages || [];
  const lineUtilization = processed?.line_utilization || [];
  const actions = processed?.recommended_actions || [];
  const demandBySku = processed?.demand_by_sku || {};

  kpiCards.innerHTML = `
    <div class="kpi-card"><p class="kpi-label">Total Orders</p><p class="kpi-value">${kpis.total_orders ?? "-"}</p></div>
    <div class="kpi-card"><p class="kpi-label">Units Planned</p><p class="kpi-value">${kpis.total_units_planned ?? "-"}</p></div>
    <div class="kpi-card"><p class="kpi-label">Materials Short</p><p class="kpi-value">${kpis.materials_short ?? "-"}</p></div>
    <div class="kpi-card"><p class="kpi-label">Supply Coverage</p><p class="kpi-value">${kpis.supply_coverage_pct ?? "-"}%</p></div>
    <div class="kpi-card"><p class="kpi-label">Bottleneck Utilization</p><p class="kpi-value">${kpis.bottleneck_utilization_pct ?? "-"}%</p></div>
    <div class="kpi-card"><p class="kpi-label">Execution Risk</p><p class="kpi-value">${kpis.execution_risk_score ?? "-"}</p></div>
  `;

  shortageList.innerHTML = shortages.length
    ? shortages
        .map(
          (item) =>
            `<li>${item.material}: required ${item.required}, available ${item.available}, gap ${item.gap}</li>`
        )
        .join("")
    : "<li>No shortages in dummy scenario.</li>";

  lineUtilList.innerHTML = lineUtilization.length
    ? lineUtilization
        .map(
          (line) =>
            `<li>${line.line}: ${line.utilization_pct}% utilization (${line.demand_units}/${line.effective_capacity})</li>`
        )
        .join("")
    : "<li>No line data.</li>";

  actionList.innerHTML = actions.length
    ? actions.map((item) => `<li>${item}</li>`).join("")
    : "<li>No actions generated.</li>";

  const demandRows = Object.entries(demandBySku).map(([sku, qty]) => ({ sku, units: qty, label: sku }));
  renderBarChart(demandChart, demandRows, "units");
  renderBarChart(utilChart, lineUtilization, "utilization_pct", "%", 140);
  renderBarChart(gapChart, shortages, "gap");
};

const playCalls = async (calls) => {
  traceList.innerHTML = "";

  for (const call of calls) {
    activeAgent.textContent = call.agent;
    markActiveAgent(call.agent);
    addTraceItem(call);
    await new Promise((resolve) => setTimeout(resolve, 850));
  }

  activeAgent.textContent = "Execution completed";
  clearActiveNodes();
};

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const objective = objectiveField.value.trim();

  if (!objective) {
    activeAgent.textContent = "Please enter an objective.";
    return;
  }

  activeAgent.textContent = "Planning...";
  if (scenarioApplied) scenarioApplied.textContent = "Scenario: computing objective impact...";
  if (scenarioRulesList) scenarioRulesList.innerHTML = "";
  traceList.innerHTML = "";

  try {
    const response = await fetch("/api/orchestrate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ objective }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Failed to orchestrate");
    }

    renderProcessedResults(data.processed_results || {});
    if (scenarioRulesList) {
      const rules = data.scenario_rules || [];
      scenarioRulesList.innerHTML = rules.length
        ? rules.map((rule) => `<li>${escapeHtml(rule)}</li>`).join("")
        : "<li>No scenario rules generated.</li>";
    }
    if (scenarioApplied) {
      scenarioApplied.textContent = data.scenario_applied || "Scenario: baseline";
    }
    await playCalls(data.calls || []);
  } catch (error) {
    activeAgent.textContent = `Error: ${error.message}`;
    if (scenarioApplied) scenarioApplied.textContent = "Scenario: unavailable";
    clearActiveNodes();
  }
});
