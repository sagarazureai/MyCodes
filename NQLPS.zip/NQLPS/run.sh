#!/bin/bash
# NQL & PowerShell Generator/Analyzer - Linux/macOS Launcher
# Powered by Gemini 2.5 Flash

echo "============================================"
echo "  NQL & PowerShell Generator/Analyzer"
echo "  Powered by Gemini 2.5 Flash"
echo "============================================"
echo ""

# Check if Python 3 is installed
if command -v python3 &>/dev/null; then
    PYTHON=python3
elif command -v python &>/dev/null; then
    PYTHON=python
else
    echo "[ERROR] Python 3 is not installed or not in PATH."
    echo "Please install Python 3.8+ from https://www.python.org/downloads/"
    exit 1
fi

echo "[INFO] Python found:"
$PYTHON --version
echo ""

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "[INFO] Creating virtual environment..."
    $PYTHON -m venv venv
    if [ $? -ne 0 ]; then
        echo "[ERROR] Failed to create virtual environment."
        exit 1
    fi
    echo "[INFO] Virtual environment created."
fi

# Activate virtual environment
source venv/bin/activate

# Install dependencies
echo "[INFO] Checking dependencies..."
pip install -r requirements.txt --quiet --disable-pip-version-check
if [ $? -ne 0 ]; then
    echo "[ERROR] Failed to install dependencies."
    exit 1
fi
echo "[INFO] Dependencies are ready."
echo ""

# Start the application
echo "[INFO] Starting the application..."
echo "[INFO] Open your browser and go to: http://localhost:5000"
echo "[INFO] Press Ctrl+C to stop the server."
echo "============================================"
echo ""

python app.py
