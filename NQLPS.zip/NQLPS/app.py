"""
NQL & PowerShell Generator/Analyzer
A Flask web application that generates and analyzes NQL queries and PowerShell scripts
using Google's Gemini AI API.
"""

import os
import json
import urllib.request
import urllib.error
from flask import Flask, request, jsonify, render_template

app = Flask(__name__, template_folder='templates', static_folder='static')

# API key can be overridden at runtime via the settings UI (stored in-memory)
_runtime_api_key = None


def get_api_key():
    return _runtime_api_key or os.environ.get('GEMINI_API_KEY', 'AQ.Ab8RN6LbaGva7fPc-HSf20IuvRP8ar3TVf25lTWcvTb_r4SrxA')


def get_model():
    return os.environ.get('GEMINI_MODEL', 'gemini-2.5-flash')


FALLBACK_MODELS = ['gemini-2.5-flash', 'gemini-2.0-flash', 'gemini-flash']


def get_gemini_url(model=None):
    m = model or get_model()
    return f'https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent?key={get_api_key()}'

NQL_REFERENCE = """
Nexthink Query Language (NQL) Reference Guide:

## Specifying Table
Every NQL query starts by specifying the table: `namespace.table`
Example: `execution.events` or `device.devices`
Shortcuts: `applications`, `binaries`, `campaigns`, `devices`, `users`

## Time Frame
After table name, specify a time frame:
- `devices during past 7d`
- `execution.crashes during past 24h`
- `users during past 30d`
- Formats: `past Nd` (days), `past Nh` (hours), `past Nw` (weeks), `past Nm` (months)

## NQL Keywords

### where (filter results)
Syntax: `... | where <field> <operator> <value>`
Operators: `==`, `!=`, `<`, `>`, `<=`, `>=`, `in`, `not in`, `contains`, `matches`
Example: `devices during past 7d | where operating_system.platform == Windows`
Multiple conditions: `... | where field1 == "value1" and field2 == "value2"`
Pattern matching: `*` (any chars), `?` (single char)
Example: `users during past 7d | where username == "*jo*"`

### list (select fields)
Syntax: `... | list field1, field2, field3`
Example: `users during past 7d | list username, type`

### sort (order results)
Syntax: `... | sort field asc` or `... | sort field desc`
Example: `users during past 7d | list username, type | sort username asc`

### limit (max results)
Syntax: `... | limit N`
Example: `devices during past 7d | limit 10`

### summarize (aggregation)
Syntax: `... | summarize <alias> = <aggregation_function> by <field>`
Functions: `count()`, `sum()`, `avg()`, `min()`, `max()`, `number_of_*.sum()`
Group by property: `... | summarize total = count() by public_ip.ip_address`
Group by period: `... | summarize total = count() by 1d`
Group by property and period: `... | summarize total = count() by 1d, device.operating_system.platform`
Example: `execution.crashes during past 7d | summarize total = count() by 1d | sort start_time asc`

### compute (calculated metrics)
Syntax: `... | compute <alias> = <function>`
Functions: `time.last()`, `time.first()`, `count()`, `sum()`, `avg()`
Example: `devices | compute last_crash_time = time.last()`

### include (join related data)
Syntax: `... | include <namespace.table> [during past Nd]`
Example: `devices during past 7d | include execution.crashes during past 7d`

## Comparison Operators
`==`, `!=`, `<`, `>`, `<=`, `>=`

## Logical Operators
`and`, `or`, `not`

## Bitwise Operators
`and`, `or`

## Common Tables
- `devices` - device information
- `users` - user information
- `execution.events` - execution events
- `execution.crashes` - crash events
- `web.errors` - web errors
- `applications` - application data
- `packages` - package information
- `connection.events` - network connections
- `collaboration.sessions` - collaboration sessions

## Common Fields
- `device.name`, `device.operating_system.platform`, `device.hardware.type`
- `user.username`, `user.type`
- `operating_system.platform`, `operating_system.version`
- `public_ip.ip_address`
- `username`, `type`, `name`

## Query Structure
1. Start with table: `devices`
2. Add time frame: `during past 7d`
3. Add filters: `| where ...`
4. Add aggregations: `| summarize ...`
5. Add computed fields: `| compute ...`
6. Select fields: `| list ...`
7. Sort: `| sort ... desc`
8. Limit: `| limit N`

All clauses are pipe-separated (|) and executed left to right.
"""


def call_gemini(prompt, system_instruction=None):
    """Call Gemini API and return the text response."""
    payload = {
        'contents': [{'parts': [{'text': prompt}]}],
        'generationConfig': {
            'temperature': 0.7,
            'topK': 40,
            'topP': 0.95,
            'maxOutputTokens': 8192,
        },
    }
    if system_instruction:
        payload['systemInstruction'] = {'parts': [{'text': system_instruction}]}

    headers = {'Content-Type': 'application/json'}
    data = json.dumps(payload).encode('utf-8')

    for model in FALLBACK_MODELS:
        url = get_gemini_url(model)
        req = urllib.request.Request(url, data=data, headers=headers, method='POST')
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                result = json.loads(resp.read().decode('utf-8'))
            candidates = result.get('candidates', [])
            if candidates:
                parts = candidates[0].get('content', {}).get('parts', [])
                if parts:
                    return parts[0].get('text', '')
            return 'No response generated.'
        except urllib.error.HTTPError as e:
            error_body = e.read().decode('utf-8', errors='replace')
            try:
                err_json = json.loads(error_body)
                msg = err_json.get('error', {}).get('message', error_body)
                status = err_json.get('error', {}).get('status', '')
            except Exception:
                msg = error_body
                status = ''
            # If rate limited or overloaded, try next model
            if e.code in (429, 503) or 'high demand' in msg.lower() or status == 'RESOURCE_EXHAUSTED':
                continue
            return f'API Error: {msg}'
        except Exception as e:
            return f'Error: {str(e)}'

    return 'API Error: All models are currently overloaded. Please try again later.'


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/api/settings', methods=['GET', 'POST'])
def settings():
    global _runtime_api_key
    if request.method == 'GET':
        key = get_api_key()
        masked = key[:8] + '...' + key[-4:] if len(key) > 12 else '***'
        return jsonify({'apiKey': masked, 'model': get_model(), 'configured': bool(key)})
    else:
        data = request.get_json() or {}
        new_key = data.get('apiKey', '').strip()
        if new_key:
            _runtime_api_key = new_key
            return jsonify({'status': 'ok', 'message': 'API key updated.'})
        return jsonify({'error': 'No API key provided.'}), 400


@app.route('/api/generate', methods=['POST'])
def generate():
    """Generate NQL query and/or PowerShell script from a natural language requirement."""
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400

    requirement = data.get('requirement', '').strip()
    script_type = data.get('type', 'both')  # 'nql', 'powershell', or 'both'

    if not requirement:
        return jsonify({'error': 'Please provide a requirement description.'}), 400

    results = {}

    if script_type in ('nql', 'both'):
        nql_prompt = f"""You are an expert Nexthink Query Language (NQL) developer.
Generate a complete, syntactically correct NQL query based on the following requirement.

Use this NQL syntax reference:
{NQL_REFERENCE}

Requirement: {requirement}

Rules:
- Generate ONLY the NQL query code, no explanations in the code block
- Use proper NQL syntax with pipe (|) separators
- Include time frames where appropriate (e.g., "during past 7d")
- Use proper table names and field paths
- Add comments using // syntax where helpful

Respond in this exact format:
### NQL_QUERY
```nql
<the nql query here>
```

### EXPLANATION
<Line-by-line explanation of the NQL query, explaining each clause and what it does>"""
        nql_response = call_gemini(nql_prompt)
        results['nql'] = nql_response

    if script_type in ('powershell', 'both'):
        ps_prompt = f"""You are an expert PowerShell script developer.
Generate a complete, production-ready PowerShell script that accomplishes the following requirement.
This script should be the PowerShell equivalent or companion to an NQL query for the same requirement.

Requirement: {requirement}

Rules:
- Generate ONLY the PowerShell script code, no explanations in the code block
- Use proper PowerShell cmdlets and syntax
- Include error handling with try/catch where appropriate
- Add comments using # syntax
- Use proper variable naming ($PascalCase)
- Include parameter declarations at the top if the script accepts parameters
- Make the script self-contained and runnable

Respond in this exact format:
### POWERSHELL_SCRIPT
```powershell
<the powershell script here>
```

### EXPLANATION
<Line-by-line explanation of the PowerShell script, explaining each section, cmdlet, and what it does>"""
        ps_response = call_gemini(ps_prompt)
        results['powershell'] = ps_response

    return jsonify(results)


@app.route('/api/analyze', methods=['POST'])
def analyze():
    """Analyze a .ps1 file or NQL query and provide line-by-line explanation and insights."""
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided'}), 400

    code = data.get('code', '').strip()
    analysis_type = data.get('type', 'auto')  # 'nql', 'powershell', or 'auto'

    if not code:
        return jsonify({'error': 'Please provide code to analyze.'}), 400

    # Auto-detect type
    if analysis_type == 'auto':
        nql_keywords = ['during past', '| where', '| list', '| sort', '| summarize',
                        '| compute', '| limit', '| include', 'execution.', 'device.',
                        'web.errors', 'applications', 'binaries', 'devices', 'users']
        ps_keywords = ['$', 'param', 'Get-', 'Set-', 'New-', 'Remove-', 'Write-',
                       'try', 'catch', 'function', 'Invoke-', 'ForEach-Object',
                       'Select-Object', 'Where-Object', '#']
        nql_score = sum(1 for kw in nql_keywords if kw.lower() in code.lower())
        ps_score = sum(1 for kw in ps_keywords if kw.lower() in code.lower())
        analysis_type = 'nql' if nql_score > ps_score else 'powershell'

    if analysis_type == 'nql':
        type_label = 'NQL Query'
        prompt = f"""You are an expert Nexthink Query Language (NQL) analyst.
Analyze the following NQL query and provide a detailed, line-by-line explanation.

Use this NQL syntax reference:
{NQL_REFERENCE}

NQL Query to analyze:
```
{code}
```

Provide your analysis in the following JSON format (return ONLY valid JSON, no markdown):
{{
  "type": "NQL Query",
  "summary": "<1-2 sentence overview of what this query does>",
  "lineByLine": [
    {{"line": "<the line of code>", "explanation": "<what this line does>"}}
  ],
  "insights": [
    "<insight 1 - e.g., performance considerations, potential issues, best practices>",
    "<insight 2>"
  ],
  "suggestions": [
    "<suggestion 1 - improvements or alternatives>",
    "<suggestion 2>"
  ]
}}"""
    else:
        type_label = 'PowerShell Script'
        prompt = f"""You are an expert PowerShell script analyst.
Analyze the following PowerShell script and provide a detailed, line-by-line explanation.

PowerShell Script to analyze:
```
{code}
```

Provide your analysis in the following JSON format (return ONLY valid JSON, no markdown):
{{
  "type": "PowerShell Script",
  "summary": "<1-2 sentence overview of what this script does>",
  "lineByLine": [
    {{"line": "<the line of code>", "explanation": "<what this line does>"}}
  ],
  "insights": [
    "<insight 1 - e.g., security considerations, performance, error handling>",
    "<insight 2>"
  ],
  "suggestions": [
    "<suggestion 1 - improvements or alternatives>",
    "<suggestion 2>"
  ]
}}"""

    response = call_gemini(prompt)

    # Try to parse JSON from response
    try:
        # Strip markdown code fences if present
        clean = response.strip()
        if clean.startswith('```'):
            lines = clean.split('\n')
            # Remove first and last lines (fences)
            lines = [l for l in lines if not l.strip().startswith('```')]
            clean = '\n'.join(lines)
        # Find JSON object
        start = clean.find('{')
        end = clean.rfind('}')
        if start != -1 and end != -1:
            clean = clean[start:end + 1]
        analysis = json.loads(clean)
        return jsonify(analysis)
    except (json.JSONDecodeError, Exception):
        return jsonify({
            'type': type_label,
            'summary': 'Analysis completed but could not be structured.',
            'rawResponse': response,
            'lineByLine': [],
            'insights': [],
            'suggestions': [],
        })


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
