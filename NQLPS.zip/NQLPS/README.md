# NQL & PowerShell Generator/Analyzer

A web application that generates and analyzes **Nexthink Query Language (NQL)** queries and **PowerShell scripts** using Google's Gemini 2.5 Flash AI model.

## Features

- **Generate Mode**: Describe what you need in plain English, and the app generates:
  - NQL queries with syntax based on [official Nexthink documentation](https://docs.nexthink.com/platform/understanding-key-data-platform-concepts/nexthink-query-language-nql)
  - Equivalent PowerShell scripts
  - Line-by-line explanations for both

- **Analyze Mode**: Paste or upload a `.ps1` / `.nql` file and get:
  - A summary of what the code does
  - Line-by-line explanation
  - Insights (performance, security, best practices)
  - Suggestions for improvement

## How to Run

### Windows
1. Double-click `run.bat`
2. Your browser opens automatically at `http://localhost:5000`

### Linux / macOS
```bash
chmod +x run.sh
./run.sh
```

The launcher script will:
1. Check Python is installed
2. Create a virtual environment
3. Install dependencies (Flask)
4. Start the web server

### Manual Run
```bash
python -m venv venv
source venv/bin/activate    # Linux/macOS
# or: venv\Scripts\activate   # Windows
pip install -r requirements.txt
python app.py
```

## Requirements

- Python 3.8+
- Internet connection (for Gemini API calls)
- No other dependencies beyond Flask

## Tech Stack

- **Backend**: Python + Flask
- **AI**: Google Gemini 2.5 Flash API
- **Frontend**: HTML, CSS, JavaScript (vanilla, no frameworks)
- **NQL Reference**: [Nexthink Documentation](https://docs.nexthink.com/platform/understanding-key-data-platform-concepts/nexthink-query-language-nql)

## Usage

1. **Generate**: Type your requirement (e.g., "Show all devices that crashed in the last 7 days, grouped by OS") and click Generate. The app creates NQL and PowerShell code with explanations.

2. **Analyze**: Switch to Analyze mode, paste your code or drag-and-drop a `.ps1`/`.nql` file, and click Analyze. The app breaks down every line and provides insights and suggestions.
