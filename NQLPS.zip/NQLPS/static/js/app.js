// State
let currentGenType = 'both';

// Mode Switching
function switchMode(mode) {
    document.querySelectorAll('.mode-tab').forEach(tab => {
        tab.classList.toggle('active', tab.dataset.mode === mode);
    });
    document.getElementById('generate-mode').style.display = mode === 'generate' ? 'block' : 'none';
    document.getElementById('analyze-mode').style.display = mode === 'analyze' ? 'block' : 'none';
}

// Update Generation Type
function updateGenType() {
    const checked = document.querySelector('input[name="gen-type"]:checked');
    if (checked) {
        currentGenType = checked.value;
    }
}

// Generate
async function generate() {
    const requirement = document.getElementById('requirement-input').value.trim();
    if (!requirement) {
        showToast('Please enter a requirement description.', 'error');
        return;
    }

    const btn = event.currentTarget;
    const spinner = document.getElementById('gen-spinner');
    btn.disabled = true;
    spinner.classList.add('active');

    try {
        const response = await fetch('/api/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ requirement, type: currentGenType }),
        });
        const data = await response.json();

        if (data.error) {
            showToast(data.error, 'error');
            return;
        }

        const resultsDiv = document.getElementById('gen-results');
        resultsDiv.style.display = 'flex';

        if (data.nql) {
            document.getElementById('nql-panel').style.display = 'block';
            const { code, explanation } = parseResponse(data.nql, 'nql');
            document.getElementById('nql-code').textContent = code;
            document.getElementById('nql-explanation').innerHTML = formatExplanation(explanation);
        } else {
            document.getElementById('nql-panel').style.display = 'none';
        }

        if (data.powershell) {
            document.getElementById('ps-panel').style.display = 'block';
            const { code, explanation } = parseResponse(data.powershell, 'powershell');
            document.getElementById('ps-code').textContent = code;
            document.getElementById('ps-explanation').innerHTML = formatExplanation(explanation);
        } else {
            document.getElementById('ps-panel').style.display = 'none';
        }

        showToast('Generation complete!', 'success');
    } catch (err) {
        showToast('Failed to generate. Check your connection.', 'error');
    } finally {
        btn.disabled = false;
        spinner.classList.remove('active');
    }
}

// Parse AI Response
function parseResponse(text, type) {
    let code = '';
    let explanation = '';

    // Extract code block
    const codeRegex = type === 'nql'
        ? /```(?:nql)?\s*\n([\s\S]*?)```/
        : /```(?:powershell|ps1)?\s*\n([\s\S]*?)```/;
    const codeMatch = text.match(codeRegex);
    if (codeMatch) {
        code = codeMatch[1].trim();
    }

    // Extract explanation
    const explMatch = text.match(/###\s*EXPLANATION\s*\n([\s\S]*)/i);
    if (explMatch) {
        explanation = explMatch[1].trim();
    } else {
        // Try to get everything after the code block
        const afterCode = text.split(/```/);
        if (afterCode.length >= 3) {
            explanation = afterCode.slice(2).join('```').trim();
        } else {
            explanation = text;
        }
    }

    return { code, explanation };
}

// Format explanation as HTML
function formatExplanation(text) {
    if (!text) return '<p>No explanation available.</p>';
    // Basic markdown formatting
    let html = text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/`([^`]+)`/g, '<code>$1</code>')
        .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
        .replace(/^### (.+)$/gm, '<h3>$1</h3>')
        .replace(/^## (.+)$/gm, '<h3>$1</h3>')
        .replace(/^# (.+)$/gm, '<h3>$1</h3>')
        .replace(/^\d+\.\s(.+)$/gm, '<li>$1</li>')
        .replace(/^[-*]\s(.+)$/gm, '<li>$1</li>')
        .replace(/(<li>.*<\/li>\n?)+/g, (match) => '<ul>' + match + '</ul>')
        .replace(/\n\n/g, '</p><p>')
        .replace(/\n/g, '<br>');

    if (!html.startsWith('<')) {
        html = '<p>' + html + '</p>';
    }

    return html;
}

// Analyze
async function analyze() {
    const code = document.getElementById('analyze-input').value.trim();
    if (!code) {
        showToast('Please paste code or upload a file to analyze.', 'error');
        return;
    }

    const type = document.querySelector('input[name="ana-type"]:checked').value;
    const btn = event.currentTarget;
    const spinner = document.getElementById('ana-spinner');
    btn.disabled = true;
    spinner.classList.add('active');

    try {
        const response = await fetch('/api/analyze', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ code, type }),
        });
        const data = await response.json();

        if (data.error) {
            showToast(data.error, 'error');
            return;
        }

        displayAnalysis(data);
        showToast('Analysis complete!', 'success');
    } catch (err) {
        showToast('Failed to analyze. Check your connection.', 'error');
    } finally {
        btn.disabled = false;
        spinner.classList.remove('active');
    }
}

// Display Analysis Results
function displayAnalysis(data) {
    const resultsDiv = document.getElementById('analyze-results');
    resultsDiv.style.display = 'flex';

    const titleEl = document.getElementById('analysis-title');
    const icon = data.type === 'NQL Query' ? 'fa-database' : 'fa-terminal';
    titleEl.innerHTML = `<i class="fa-solid ${icon}"></i> Analysis Results - ${data.type || 'Code'}`;

    document.getElementById('analysis-summary').textContent = data.summary || 'No summary available.';

    // Line by line
    const lineByLineDiv = document.getElementById('line-by-line');
    lineByLineDiv.innerHTML = '';

    if (data.lineByLine && data.lineByLine.length > 0) {
        data.lineByLine.forEach((item, index) => {
            const lineDiv = document.createElement('div');
            lineDiv.className = 'line-item';
            lineDiv.innerHTML = `
                <div class="line-number">${index + 1}</div>
                <div class="line-detail">
                    <div class="line-code">${escapeHtml(item.line || '')}</div>
                    <div class="line-explanation">${escapeHtml(item.explanation || '')}</div>
                </div>
            `;
            lineByLineDiv.appendChild(lineDiv);
        });
    } else {
        lineByLineDiv.innerHTML = '<p style="color: var(--text-muted); padding: 12px;">No line-by-line breakdown available.</p>';
    }

    // Insights
    const insightsList = document.getElementById('insights-list');
    insightsList.innerHTML = '';
    if (data.insights && data.insights.length > 0) {
        data.insights.forEach(insight => {
            const li = document.createElement('li');
            li.textContent = insight;
            insightsList.appendChild(li);
        });
    } else {
        insightsList.innerHTML = '<li>No insights available.</li>';
    }

    // Suggestions
    const suggestionsList = document.getElementById('suggestions-list');
    suggestionsList.innerHTML = '';
    if (data.suggestions && data.suggestions.length > 0) {
        data.suggestions.forEach(suggestion => {
            const li = document.createElement('li');
            li.textContent = suggestion;
            suggestionsList.appendChild(li);
        });
    } else {
        suggestionsList.innerHTML = '<li>No suggestions available.</li>';
    }

    // Scroll to results
    resultsDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Utility Functions
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function copyCode(elementId) {
    const code = document.getElementById(elementId).textContent;
    navigator.clipboard.writeText(code).then(() => {
        showToast('Copied to clipboard!', 'success');
    }).catch(() => {
        showToast('Failed to copy.', 'error');
    });
}

function downloadCode(elementId, filename) {
    const code = document.getElementById(elementId).textContent;
    const blob = new Blob([code], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    URL.revokeObjectURL(a.href);
    showToast('Downloaded!', 'success');
}

function copyAnalysis() {
    const summary = document.getElementById('analysis-summary').textContent;
    const lines = Array.from(document.querySelectorAll('.line-item'))
        .map((item, i) => `${i + 1}. ${item.querySelector('.line-code').textContent} - ${item.querySelector('.line-explanation').textContent}`)
        .join('\n');
    const insights = Array.from(document.querySelectorAll('#insights-list li'))
        .map(li => '- ' + li.textContent).join('\n');
    const suggestions = Array.from(document.querySelectorAll('#suggestions-list li'))
        .map(li => '- ' + li.textContent).join('\n');

    const text = `Summary:\n${summary}\n\nLine-by-Line:\n${lines}\n\nInsights:\n${insights}\n\nSuggestions:\n${suggestions}`;
    navigator.clipboard.writeText(text).then(() => {
        showToast('Analysis copied!', 'success');
    }).catch(() => {
        showToast('Failed to copy.', 'error');
    });
}

function clearGenerate() {
    document.getElementById('requirement-input').value = '';
    document.getElementById('gen-results').style.display = 'none';
    document.getElementById('nql-code').textContent = '';
    document.getElementById('nql-explanation').innerHTML = '';
    document.getElementById('ps-code').textContent = '';
    document.getElementById('ps-explanation').innerHTML = '';
}

function clearAnalyze() {
    document.getElementById('analyze-input').value = '';
    document.getElementById('analyze-results').style.display = 'none';
}

function showToast(message, type) {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = 'toast show ' + (type || '');
    setTimeout(() => {
        toast.className = 'toast ' + (type || '');
    }, 3000);
}

// File Upload
document.addEventListener('DOMContentLoaded', () => {
    const uploadZone = document.getElementById('upload-zone');
    const fileInput = document.getElementById('file-input');

    uploadZone.addEventListener('click', () => fileInput.click());

    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            readFile(file);
        }
    });

    uploadZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadZone.classList.add('dragover');
    });

    uploadZone.addEventListener('dragleave', () => {
        uploadZone.classList.remove('dragover');
    });

    uploadZone.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadZone.classList.remove('dragover');
        const file = e.dataTransfer.files[0];
        if (file) {
            readFile(file);
        }
    });

    function readFile(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            document.getElementById('analyze-input').value = e.target.result;
            // Auto-detect type from extension
            if (file.name.endsWith('.ps1') || file.name.endsWith('.psm1') || file.name.endsWith('.psd1')) {
                document.querySelector('input[name="ana-type"][value="powershell"]').checked = true;
            } else if (file.name.endsWith('.nql')) {
                document.querySelector('input[name="ana-type"][value="nql"]').checked = true;
            } else {
                document.querySelector('input[name="ana-type"][value="auto"]').checked = true;
            }
            showToast(`Loaded: ${file.name}`, 'success');
        };
        reader.readAsText(file);
    }

    // Keyboard shortcut: Ctrl+Enter to generate or analyze
    document.getElementById('requirement-input').addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            generate();
        }
    });
    document.getElementById('analyze-input').addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            analyze();
        }
    });

    // Load current settings on page load
    loadSettings();
});

// Settings
async function loadSettings() {
    try {
        const res = await fetch('/api/settings');
        const data = await res.json();
        document.getElementById('current-key').textContent = data.apiKey || 'Not set';
    } catch (e) {
        document.getElementById('current-key').textContent = 'Unable to load';
    }
}

function openSettings() {
    document.getElementById('settings-modal').style.display = 'flex';
    loadSettings();
}

function closeSettings() {
    document.getElementById('settings-modal').style.display = 'none';
    document.getElementById('api-key-input').value = '';
}

async function saveSettings() {
    const key = document.getElementById('api-key-input').value.trim();
    if (!key) {
        showToast('Please enter an API key.', 'error');
        return;
    }
    try {
        const res = await fetch('/api/settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ apiKey: key }),
        });
        const data = await res.json();
        if (data.error) {
            showToast(data.error, 'error');
            return;
        }
        showToast('API key saved!', 'success');
        closeSettings();
        loadSettings();
    } catch (e) {
        showToast('Failed to save settings.', 'error');
    }
}
