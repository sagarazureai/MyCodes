@echo off
title NQL & PowerShell Generator/Analyzer
color 0B

echo ============================================
echo   NQL ^& PowerShell Generator/Analyzer
echo   Powered by Gemini 2.5 Flash
echo ============================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH.
    echo Please install Python 3.8+ from https://www.python.org/downloads/
    echo.
    pause
    exit /b 1
)

REM Show Python version
echo [INFO] Python found:
python --version
echo.

REM Create virtual environment if it doesn't exist
if not exist "venv" (
    echo [INFO] Creating virtual environment...
    python -m venv venv
    if errorlevel 1 (
        echo [ERROR] Failed to create virtual environment.
        pause
        exit /b 1
    )
    echo [INFO] Virtual environment created.
)

REM Activate virtual environment
call venv\Scripts\activate.bat

REM Install dependencies
echo [INFO] Checking dependencies...
pip install -r requirements.txt --quiet --disable-pip-version-check
if errorlevel 1 (
    echo [ERROR] Failed to install dependencies.
    pause
    exit /b 1
)
echo [INFO] Dependencies are ready.
echo.

REM Set the API key (already embedded in app.py, but can override here)
REM set GEMINI_API_KEY=AQ.Ab8RN6LbaGva7fPc-HSf20IuvRP8ar3TVf25lTWcvTb_r4SrxA

REM Start the application
echo [INFO] Starting the application...
echo [INFO] Open your browser and go to: http://localhost:5000
echo [INFO] Press Ctrl+C to stop the server.
echo ============================================
echo.

python app.py

pause
