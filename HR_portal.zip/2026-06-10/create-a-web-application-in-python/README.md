# HR Genie

Interactive Python web application for HR workflow automation.

## Run

```powershell
.venv\Scripts\python.exe app.py
```

Open:

```text
http://127.0.0.1:8000
```

## Features

- PwC-inspired HR dashboard visual language.
- JD creation with role, department, experience, work mode, skills, and business outcome.
- CV screening that compares multiple candidate summaries and ranks by matching percentage.
- L0 interview bot with skill selection, 2-3 question flow, speech synthesis, speech capture where supported, and answer assessment as correct, close, or incorrect.
