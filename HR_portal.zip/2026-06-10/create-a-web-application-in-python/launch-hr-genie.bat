@echo off
setlocal

cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
  echo Local Python environment was not found.
  echo Run: uv venv .venv
  pause
  exit /b 1
)

start "HR Genie Server" /min ".venv\Scripts\python.exe" "app.py"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:8000"

echo HR Genie is launching at http://127.0.0.1:8000
echo You can close this window.
endlocal
