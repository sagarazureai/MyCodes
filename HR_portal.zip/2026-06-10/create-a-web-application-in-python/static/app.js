const skillQuestions = {
  Python: [
    {
      q: "Explain how you would use Python to clean a messy HR data set before building a dashboard.",
      keys: ["pandas", "dataframe", "null", "duplicate", "validation", "transform"]
    },
    {
      q: "What is the difference between a list and a dictionary, and when would you use each?",
      keys: ["key", "value", "index", "lookup", "ordered", "mapping"]
    },
    {
      q: "How do you make a Python script reliable for a recurring recruitment report?",
      keys: ["logging", "exception", "test", "schedule", "parameter", "monitor"]
    }
  ],
  SQL: [
    {
      q: "How would you find the top five skills requested across active job postings?",
      keys: ["group by", "count", "order by", "limit", "skill"]
    },
    {
      q: "Explain the difference between inner join and left join with a candidate example.",
      keys: ["matching", "all", "left", "null", "join"]
    },
    {
      q: "How would you validate that a hiring funnel report is accurate?",
      keys: ["reconcile", "source", "count", "filter", "duplicate", "audit"]
    }
  ],
  "Stakeholder Management": [
    {
      q: "How would you handle conflicting hiring priorities from two business leaders?",
      keys: ["align", "priority", "tradeoff", "data", "timeline", "communicate"]
    },
    {
      q: "What would you do if a hiring manager rejects every shortlisted candidate?",
      keys: ["calibrate", "feedback", "criteria", "profile", "market", "evidence"]
    },
    {
      q: "How do you keep interviewers engaged when hiring volume is high?",
      keys: ["cadence", "expectation", "schedule", "feedback", "ownership"]
    }
  ],
  "Cloud Fundamentals": [
    {
      q: "What cloud services would you use for a scalable CV screening workflow?",
      keys: ["storage", "queue", "function", "database", "api", "security"]
    },
    {
      q: "How would you protect candidate data in a cloud-based HR platform?",
      keys: ["encryption", "access", "role", "audit", "privacy", "retention"]
    },
    {
      q: "How do autoscaling and monitoring help during high recruitment demand?",
      keys: ["scale", "metric", "alert", "traffic", "availability"]
    }
  ],
  "Talent Acquisition": [
    {
      q: "What signals tell you a candidate is a strong fit beyond keyword matching?",
      keys: ["impact", "context", "growth", "communication", "domain", "evidence"]
    },
    {
      q: "How would you improve offer acceptance for a hard-to-hire skill?",
      keys: ["benchmark", "candidate", "experience", "speed", "value", "market"]
    },
    {
      q: "How do you design a fair shortlisting process?",
      keys: ["criteria", "consistent", "bias", "evidence", "rubric", "blind"]
    }
  ]
};

const sampleCandidates = [
  {
    name: "Aarav Mehta",
    cv: "Senior analyst with Python, pandas, SQL, Power BI dashboarding, statistics, attrition modeling, and stakeholder management for HR leadership."
  },
  {
    name: "Nisha Rao",
    cv: "Talent acquisition specialist with interview scheduling, candidate experience, HR operations, stakeholder calibration, and recruiting analytics."
  },
  {
    name: "Kabir Shah",
    cv: "Cloud data engineer using Python, SQL, Azure functions, data pipelines, security controls, monitoring, and automated reporting."
  }
];

let currentQuestionIndex = 0;
let currentQuestions = [];
let owner = "HR";

const $ = (id) => document.getElementById(id);

function normalizeWords(text) {
  return text.toLowerCase().replace(/[^a-z0-9+#.\s-]/g, " ").split(/\s+/).filter(Boolean);
}

function generateJd() {
  const role = $("roleTitle").value.trim();
  const department = $("department").value.trim();
  const exp = $("experience").value;
  const mode = $("workMode").value;
  const skills = $("skills").value.split(",").map((s) => s.trim()).filter(Boolean);
  const outcome = $("outcome").value.trim();

  $("jdOutput").innerHTML = `
    <h3>${role}</h3>
    <p><strong>${department}</strong> · ${exp} · ${mode}</p>
    <p>${outcome}</p>
    <h4>Key responsibilities</h4>
    <ul>
      <li>Translate business hiring needs into measurable role outcomes.</li>
      <li>Build insight-led reports and communicate recommendations to HR leaders.</li>
      <li>Partner with recruiters and interview panels to refine candidate scorecards.</li>
    </ul>
    <h4>Required skills</h4>
    <div class="tags">${skills.map((skill) => `<span>${skill}</span>`).join("")}</div>
  `;
}

function createCandidate(candidate = { name: "", cv: "" }) {
  const card = document.createElement("article");
  card.className = "candidate-card";
  card.innerHTML = `
    <input aria-label="Candidate name" value="${candidate.name}" placeholder="Candidate name">
    <textarea aria-label="Candidate CV" placeholder="Paste CV summary">${candidate.cv}</textarea>
  `;
  $("candidateInputs").appendChild(card);
}

function loadSamples() {
  $("candidateInputs").innerHTML = "";
  sampleCandidates.forEach(createCandidate);
}

function scoreCandidate(cv, requiredSkills) {
  const text = cv.toLowerCase();
  const skillHits = requiredSkills.filter((skill) => text.includes(skill.toLowerCase()));
  const jdWords = normalizeWords(`${$("skills").value} ${$("outcome").value}`);
  const cvWords = new Set(normalizeWords(cv));
  const keywordHits = jdWords.filter((word) => word.length > 3 && cvWords.has(word));
  const uniqueKeywordHits = [...new Set(keywordHits)];
  const raw = (skillHits.length / Math.max(requiredSkills.length, 1)) * 68 + Math.min(uniqueKeywordHits.length * 4, 32);
  return {
    score: Math.min(98, Math.round(raw)),
    hits: [...new Set([...skillHits, ...uniqueKeywordHits.slice(0, 6)])]
  };
}

function matchCvs() {
  const requiredSkills = $("skills").value.split(",").map((s) => s.trim()).filter(Boolean);
  const cards = [...document.querySelectorAll(".candidate-card")];
  const results = cards.map((card) => {
    const name = card.querySelector("input").value.trim() || "Unnamed candidate";
    const cv = card.querySelector("textarea").value.trim();
    return { name, cv, ...scoreCandidate(cv, requiredSkills) };
  }).sort((a, b) => b.score - a.score);

  $("rankings").innerHTML = results.map((result, index) => `
    <article class="rank-row">
      <strong>#${index + 1} ${result.name}</strong>
      <div class="bar" aria-label="${result.score}% match"><span style="--score:${result.score}%"></span></div>
      <strong>${result.score}%</strong>
      <div class="tags">${result.hits.length ? result.hits.map((hit) => `<span>${hit}</span>`).join("") : "<span>Low evidence</span>"}</div>
    </article>
  `).join("");

  const top = results[0];
  $("topCandidate").textContent = top ? `${top.name} is the strongest match` : "No candidates found";
  $("topReason").textContent = top ? `${top.score}% match based on JD skills and role outcome keywords.` : "Add candidate CVs to compare.";
  $("screenedCount").textContent = String(48 + results.length);
  $("readiness").textContent = `${Math.min(96, 86 + results.length)}%`;
}

function speak(text) {
  if (!("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 0.94;
  utterance.pitch = 1.02;
  window.speechSynthesis.speak(utterance);
}

function startInterview() {
  const skill = $("skillFocus").value;
  currentQuestions = skillQuestions[skill];
  currentQuestionIndex = 0;
  showQuestion();
  $("history").innerHTML = "";
  $("assessment").className = "assessment empty";
  $("assessment").textContent = "Assessment will appear here.";
}

function showQuestion() {
  const item = currentQuestions[currentQuestionIndex];
  if (!item) return;
  $("questionCounter").textContent = `Question ${currentQuestionIndex + 1} of ${currentQuestions.length}`;
  $("currentQuestion").textContent = `${owner} selected ${$("skillFocus").value}: ${item.q}`;
  $("answerText").value = "";
  speak(item.q);
}

function nextQuestion() {
  if (!currentQuestions.length) return startInterview();
  currentQuestionIndex = (currentQuestionIndex + 1) % currentQuestions.length;
  showQuestion();
}

function assessAnswer() {
  if (!currentQuestions.length) startInterview();
  const item = currentQuestions[currentQuestionIndex];
  const answer = $("answerText").value.trim();
  const lower = answer.toLowerCase();
  const hits = item.keys.filter((key) => lower.includes(key));
  const score = Math.round((hits.length / item.keys.length) * 100);
  let verdict = "incorrect";
  let label = "Incorrect answer";
  let message = "The response misses the expected concepts. Ask a follow-up or mark for recruiter review.";

  if (score >= 45 || hits.length >= 3) {
    verdict = "correct";
    label = "Correct answer";
    message = "The response covers the core concepts with enough evidence for L0 qualification.";
  } else if (score >= 20 || hits.length >= 1 || answer.split(/\s+/).length > 18) {
    verdict = "close";
    label = "Close answer";
    message = "The response is partially aligned but needs more precision or examples.";
  }

  $("assessment").className = `assessment ${verdict}`;
  $("assessment").innerHTML = `<strong>${label}</strong><p>${message}</p><p>Matched evidence: ${hits.join(", ") || "none"}</p>`;

  const record = document.createElement("article");
  record.innerHTML = `<strong>${$("skillFocus").value} · ${label}</strong><p>${answer || "No answer captured."}</p>`;
  $("history").prepend(record);
}

function listenAnswer() {
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Recognition) {
    $("answerText").placeholder = "Speech recognition is not available in this browser. Type the answer here.";
    $("answerText").focus();
    return;
  }
  const recognition = new Recognition();
  recognition.lang = "en-IN";
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  recognition.onstart = () => { $("listenAnswer").textContent = "Listening..."; };
  recognition.onend = () => { $("listenAnswer").textContent = "Listen"; };
  recognition.onresult = (event) => {
    $("answerText").value = event.results[0][0].transcript;
  };
  recognition.start();
}

document.querySelectorAll(".segmented button").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".segmented button").forEach((b) => b.classList.remove("selected"));
    button.classList.add("selected");
    owner = button.dataset.owner;
    if (currentQuestions.length) showQuestion();
  });
});

$("generateJd").addEventListener("click", generateJd);
$("loadSamples").addEventListener("click", loadSamples);
$("addCandidate").addEventListener("click", () => createCandidate());
$("matchCvs").addEventListener("click", matchCvs);
$("startInterview").addEventListener("click", startInterview);
$("nextQuestion").addEventListener("click", nextQuestion);
$("assessAnswer").addEventListener("click", assessAnswer);
$("listenAnswer").addEventListener("click", listenAnswer);

generateJd();
loadSamples();
matchCvs();
