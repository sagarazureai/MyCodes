@echo off
setlocal
cd /d "%~dp0"

set "PYTHON_CMD="

where python >nul 2>nul && set "PYTHON_CMD=python"
if not defined PYTHON_CMD where py >nul 2>nul && set "PYTHON_CMD=py"
if not defined PYTHON_CMD where python3 >nul 2>nul && set "PYTHON_CMD=python3"
if not defined PYTHON_CMD where uv >nul 2>nul && set "PYTHON_CMD=uv run python"

if not defined PYTHON_CMD (
  echo Python or uv was not found on PATH.
  echo Install Python 3.10+ from https://www.python.org/downloads/ or install uv, then run this file again.
  pause
  exit /b 1
)

%PYTHON_CMD% app.py
