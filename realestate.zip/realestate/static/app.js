let dashboard = null;
let allTenders = [];

const $ = (id) => document.getElementById(id);

async function loadData(refresh = false) {
  $("refreshBtn").disabled = true;
  $("refreshBtn").textContent = refresh ? "Refreshing..." : "Loading...";
  try {
    const res = await fetch(`/api/tenders${refresh ? "?refresh=1" : ""}`);
    dashboard = await res.json();
    allTenders = dashboard.tenders || [];
    renderDashboard(dashboard);
  } catch (err) {
    $("statusStrip").innerHTML = `<div class="warning">Could not load dashboard: ${escapeHtml(err.message)}</div>`;
  } finally {
    $("refreshBtn").disabled = false;
    $("refreshBtn").textContent = "Refresh";
  }
}

function renderDashboard(data) {
  const counts = data.counts || {};
  $("totalCount").textContent = counts.total || 0;
  $("openCount").textContent = counts.open || 0;
  $("progressCount").textContent = counts.in_progress || 0;
  $("upcomingCount").textContent = counts.upcoming || 0;
  $("closedCount").textContent = counts.closed || 0;
  $("awardCount").textContent = counts.awards || 0;

  const source = data.source || {};
  $("statusStrip").innerHTML = `
    <div class="${source.live ? "ok" : "warning"}">${source.live ? "Live portal data" : "Cached or sample data"}</div>
    <div>Updated ${formatDate(source.last_updated)}</div>
    ${source.warning ? `<div class="warning">${escapeHtml(source.warning)}</div>` : ""}
  `;

  const insights = data.insights || {};
  const urgentCount = (insights.closing_soon || []).length;
  $("insightBody").innerHTML = `
    <div class="spotlight">
      <div>
        <span>Urgent deadlines</span>
        <strong>${urgentCount}</strong>
      </div>
      <p>${escapeHtml(insights.headline || "")}</p>
    </div>
    <div class="insight-chips">
      <span><strong>Top organisation</strong>${escapeHtml(truncate(insights.top_organisation || "Unknown", 118))}</span>
      <span><strong>Award activity</strong>${escapeHtml(truncate(insights.award_activity || "", 118))}</span>
      <span><strong>Bidder data</strong>${escapeHtml(truncate(insights.data_gap || "", 136))}</span>
    </div>
    <h3>Closing soon</h3>
    <ul>${(insights.closing_soon || []).slice(0, 6).map(t => `<li>${escapeHtml(t.title)} <span>${escapeHtml(t.closing_date || "")}</span></li>`).join("") || "<li>No urgent public deadlines found.</li>"}</ul>
  `;

  $("dateList").innerHTML = (data.closing_dates || []).slice(0, 12).map(row => `
    <div class="date-row">
      <div><strong>${escapeHtml(row.date)}</strong><span>${row.count} tender(s), ${row.open_count} open</span></div>
      <meter min="0" max="${Math.max(...(data.closing_dates || [{count: 1}]).map(x => x.count || 1))}" value="${row.count}"></meter>
    </div>
  `).join("");

  $("orgList").innerHTML = (data.organisations || []).map(([name, count]) => `
    <div class="org-row"><span>${escapeHtml(name)}</span><strong>${count}</strong></div>
  `).join("");

  renderTenders(allTenders);
}

function renderTenders(tenders) {
  $("tenderRows").innerHTML = tenders.map(t => `
    <tr>
      <td><span class="badge ${statusClass(t.status)}">${escapeHtml(t.status || "Unknown")}</span></td>
      <td><a href="${escapeAttr(t.url || "#")}" target="_blank" rel="noreferrer">${escapeHtml(t.title || "")}</a></td>
      <td>${escapeHtml(t.reference || t.tender_id || "")}</td>
      <td>${escapeHtml(t.closing_date || "Unknown")}</td>
      <td>${escapeHtml(t.opening_date || "Unknown")}</td>
      <td>${escapeHtml(t.organisation || "Unknown")}</td>
      <td>${escapeHtml((t.submitted_bidders || []).join(", ") || t.bidder_submission_visibility || "Unavailable")}</td>
    </tr>
  `).join("");
}

function statusClass(status) {
  return String(status || "").toLowerCase().replace(/\s+/g, "-");
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (ch) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[ch]));
}

function escapeAttr(value) {
  return escapeHtml(value).replace(/"/g, "&quot;");
}

function formatDate(value) {
  if (!value) return "unknown";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString();
}

function truncate(value, limit) {
  const text = String(value ?? "").trim();
  return text.length > limit ? `${text.slice(0, limit - 1)}...` : text;
}

$("refreshBtn").addEventListener("click", () => loadData(true));
$("filterInput").addEventListener("input", (event) => {
  const q = event.target.value.toLowerCase();
  renderTenders(allTenders.filter(t => [t.title, t.reference, t.tender_id, t.organisation, t.status].join(" ").toLowerCase().includes(q)));
});

$("chatForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const input = $("chatInput");
  const question = input.value.trim();
  if (!question) return;
  appendChat(question, "user");
  input.value = "";
  appendChat("Thinking...", "bot pending");
  const pending = $("chatLog").lastElementChild;
  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({question})
    });
    const data = await res.json();
    pending.textContent = data.answer || "No answer returned.";
    pending.className = `bot ${data.mode || "local"}`;
  } catch (err) {
    pending.textContent = `Chat failed: ${err.message}`;
    pending.className = "bot warning";
  }
});

function appendChat(text, cls) {
  const div = document.createElement("div");
  div.className = cls;
  div.textContent = text;
  $("chatLog").appendChild(div);
  $("chatLog").scrollTop = $("chatLog").scrollHeight;
}

loadData(false);
