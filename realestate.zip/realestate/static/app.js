let dashboard = null;
let allTenders = [];
let websiteDocuments = [];
let uploadedDocuments = [];

const $ = (id) => document.getElementById(id);

async function loadData(refresh = false) {
  $("refreshBtn").disabled = true;
  $("refreshBtn").textContent = refresh ? "Refreshing..." : "Loading...";
  try {
    const res = await fetch(`/api/tenders${refresh ? "?refresh=1" : ""}`);
    dashboard = await res.json();
    allTenders = dashboard.tenders || [];
    websiteDocuments = dashboard.documents || [];
    uploadedDocuments = dashboard.uploaded_documents || [];
    renderDashboard(dashboard);
    renderDocuments();
  } catch (err) {
    $("statusStrip").innerHTML = `<div class="warning">Could not load dashboard: ${escapeHtml(err.message)}</div>`;
  } finally {
    $("refreshBtn").disabled = false;
    $("refreshBtn").textContent = "Refresh";
  }
}

function renderDashboard(data) {
  const counts = data.counts || {};
  $("totalCount").textContent = counts.total || 0;
  $("openCount").textContent = counts.open || 0;
  $("progressCount").textContent = counts.in_progress || 0;
  $("upcomingCount").textContent = counts.upcoming || 0;
  $("closedCount").textContent = counts.closed || 0;
  $("docCount").textContent = counts.documents || 0;
  $("awardCount").textContent = counts.awards || 0;

  const source = data.source || {};
  $("statusStrip").innerHTML = `
    <div class="${source.live ? "ok" : "warning"}">${source.live ? "Live portal data" : "Cached or sample data"}</div>
    <div>Updated ${formatDate(source.last_updated)}</div>
    ${source.warning ? `<div class="warning">${escapeHtml(source.warning)}</div>` : ""}
  `;

  const insights = data.insights || {};
  const urgentCount = (insights.closing_soon || []).length;
  $("insightBody").innerHTML = `
    <div class="spotlight">
      <div>
        <span>Urgent deadlines</span>
        <strong>${urgentCount}</strong>
      </div>
      <p>${escapeHtml(insights.headline || "")}</p>
    </div>
    <div class="insight-chips">
      <span><strong>Top organisation</strong>${escapeHtml(truncate(insights.top_organisation || "Unknown", 118))}</span>
      <span><strong>Award activity</strong>${escapeHtml(truncate(insights.award_activity || "", 118))}</span>
      <span><strong>Bidder data</strong>${escapeHtml(truncate(insights.data_gap || "", 136))}</span>
    </div>
    <h3>Closing soon</h3>
    <ul>${(insights.closing_soon || []).slice(0, 6).map(t => `<li>${escapeHtml(t.title)} <span>${escapeHtml(t.closing_date || "")}</span></li>`).join("") || "<li>No urgent public deadlines found.</li>"}</ul>
  `;

  $("dateList").innerHTML = (data.closing_dates || []).slice(0, 12).map(row => `
    <div class="date-row">
      <div><strong>${escapeHtml(row.date)}</strong><span>${row.count} tender(s), ${row.open_count} open</span></div>
      <meter min="0" max="${Math.max(...(data.closing_dates || [{count: 1}]).map(x => x.count || 1))}" value="${row.count}"></meter>
    </div>
  `).join("");

  $("orgList").innerHTML = (data.organisations || []).map(([name, count]) => `
    <div class="org-row"><span>${escapeHtml(name)}</span><strong>${count}</strong></div>
  `).join("");

  renderTenders(allTenders);
}

function renderTenders(tenders) {
  $("tenderRows").innerHTML = tenders.map(t => `
    <tr>
      <td><span class="badge ${statusClass(t.status)}">${escapeHtml(t.status || "Unknown")}</span></td>
      <td><a href="${escapeAttr(t.url || "#")}" target="_blank" rel="noreferrer">${escapeHtml(t.title || "")}</a></td>
      <td>${escapeHtml(t.reference || t.tender_id || "")}</td>
      <td>${escapeHtml(t.closing_date || "Unknown")}</td>
      <td>${escapeHtml(t.opening_date || "Unknown")}</td>
      <td>${escapeHtml(t.organisation || "Unknown")}</td>
      <td>
        ${escapeHtml((t.submitted_bidders || []).join(", ") || t.bidder_submission_visibility || "Unavailable")}
        ${renderTenderDocHint(t)}
      </td>
    </tr>
  `).join("");
}

function renderTenderDocHint(tender) {
  const docs = tender.documents || [];
  if (!docs.length) return "";
  return `<div class="tender-doc-hint">${docs.length} document link(s) found</div>`;
}

function renderDocuments() {
  $("websiteDocCount").textContent = `${websiteDocuments.length} found`;
  $("uploadedDocCount").textContent = `${uploadedDocuments.length} uploaded`;
  $("websiteDocs").innerHTML = renderDocCards(websiteDocuments, "No website document links found yet. Click Refresh to inspect public tender detail pages.");
  $("uploadedDocs").innerHTML = renderDocCards(uploadedDocuments, "No uploaded files yet. Upload a text, CSV, PDF, Word, or Excel document to start.");
}

function renderDocCards(documents, emptyText) {
  if (!documents.length) {
    return `<div class="doc-card empty"><h3>No documents yet</h3><p>${escapeHtml(emptyText)}</p></div>`;
  }
  return documents.map(doc => `
    <article class="doc-card">
      <h3>${escapeHtml(doc.name || "Document")}</h3>
      <div class="doc-meta">
        <span>${escapeHtml((doc.type || "document").toUpperCase())}</span>
        <span>${escapeHtml(doc.source || "website")}</span>
        ${doc.closing_date ? `<span>Closes ${escapeHtml(doc.closing_date)}</span>` : ""}
        ${doc.size ? `<span>${formatBytes(doc.size)}</span>` : ""}
      </div>
      ${(doc.summary_lines || []).slice(0, 2).map(line => `<p>${escapeHtml(line)}</p>`).join("")}
      ${doc.tender_title ? `<p><strong>Tender:</strong> ${escapeHtml(truncate(doc.tender_title, 150))}</p>` : ""}
      ${doc.downloadable && doc.url ? `<a href="${escapeAttr(doc.url)}" target="_blank" rel="noreferrer">Download / Review</a>` : ""}
    </article>
  `).join("");
}

function statusClass(status) {
  return String(status || "").toLowerCase().replace(/\s+/g, "-");
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (ch) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[ch]));
}

function escapeAttr(value) {
  return escapeHtml(value).replace(/"/g, "&quot;");
}

function formatDate(value) {
  if (!value) return "unknown";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString();
}

function formatBytes(bytes) {
  const size = Number(bytes || 0);
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

function truncate(value, limit) {
  const text = String(value ?? "").trim();
  return text.length > limit ? `${text.slice(0, limit - 1)}...` : text;
}

$("refreshBtn").addEventListener("click", () => loadData(true));
$("filterInput").addEventListener("input", (event) => {
  const q = event.target.value.toLowerCase();
  renderTenders(allTenders.filter(t => [t.title, t.reference, t.tender_id, t.organisation, t.status].join(" ").toLowerCase().includes(q)));
});

document.querySelectorAll(".tab-btn").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach(item => item.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach(item => item.classList.remove("active"));
    button.classList.add("active");
    $(button.dataset.tab).classList.add("active");
  });
});

$("chatForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const input = $("chatInput");
  const question = input.value.trim();
  if (!question) return;
  appendChat(question, "user");
  input.value = "";
  appendChat("Thinking...", "bot pending");
  const pending = $("chatLog").lastElementChild;
  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({question})
    });
    const data = await res.json();
    pending.textContent = data.answer || "No answer returned.";
    pending.className = `bot ${data.mode || "local"}`;
  } catch (err) {
    pending.textContent = `Chat failed: ${err.message}`;
    pending.className = "bot warning";
  }
});

$("websiteDocChatForm").addEventListener("submit", (event) => {
  event.preventDefault();
  sendDocChat("website", $("websiteDocChatInput"), $("websiteDocChatLog"));
});

$("uploadDocChatForm").addEventListener("submit", (event) => {
  event.preventDefault();
  sendDocChat("uploaded", $("uploadDocChatInput"), $("uploadDocChatLog"));
});

$("uploadForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const file = $("uploadInput").files[0];
  if (!file) return;
  const formData = new FormData();
  formData.append("file", file);
  const button = event.target.querySelector("button");
  button.disabled = true;
  button.textContent = "Uploading...";
  try {
    const res = await fetch("/api/upload", { method: "POST", body: formData });
    const data = await res.json();
    if (data.error) throw new Error(data.error);
    uploadedDocuments.unshift(data.document);
    renderDocuments();
    appendChat(`Uploaded ${data.document.name}. ${data.document.summary_lines.join(" ")} You can now ask detailed questions from this file.`, "bot", $("uploadDocChatLog"));
    $("uploadInput").value = "";
  } catch (err) {
    appendChat(`Upload failed: ${err.message}`, "bot warning", $("uploadDocChatLog"));
  } finally {
    button.disabled = false;
    button.textContent = "Upload";
  }
});

async function sendDocChat(scope, input, log) {
  const question = input.value.trim();
  if (!question) return;
  appendChat(question, "user", log);
  input.value = "";
  appendChat("Reading document context...", "bot pending", log);
  const pending = log.lastElementChild;
  try {
    const res = await fetch("/api/document-chat", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({question, scope})
    });
    const data = await res.json();
    pending.textContent = data.answer || "No answer returned.";
    pending.className = `bot ${data.mode || "local"}`;
  } catch (err) {
    pending.textContent = `Document chat failed: ${err.message}`;
    pending.className = "bot warning";
  }
}

function appendChat(text, cls, target = $("chatLog")) {
  const div = document.createElement("div");
  div.className = cls;
  div.textContent = text;
  target.appendChild(div);
  target.scrollTop = target.scrollHeight;
}

loadData(false);
