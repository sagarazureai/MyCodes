# RealEstate Tender Intelligence

A lightweight Python web application for monitoring public tender activity from the Government of India eProcurement portal:

https://eprocure.gov.in/eprocure/app

The app provides:

- Tender counts by status: open, in progress, upcoming, and closed
- Tenders grouped by bid submission closing date
- Key deadline insights
- Latest tender, closing-date, corrigendum, and award feeds
- A chatbot-style question box for tender-specific questions
- Optional OpenAI-powered answers when `OPENAI_API_KEY` is configured

## Quick Start

From this folder:

```powershell
cd realestate
.\start.bat
```

Or manually:

```powershell
python app.py
```

Then open:

```text
http://127.0.0.1:8080
```

## API Key

Create a `.env` file in this folder:

```text
OPENAI_API_KEY=your_key_here
OPENAI_MODEL=gpt-5
```

The app also works without an API key. In that mode the chatbot uses local tender data and rule-based answers.

## Notes

The eProcure portal exposes some public list pages without login, but full bidder participation such as "who submitted bids" may be restricted, appear only on specific tender detail pages after opening, or require site-side captcha/session navigation. The dashboard marks those fields as unavailable when not visible publicly.
