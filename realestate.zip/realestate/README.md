# RealEstate Tender Intelligence

A lightweight Python web application for monitoring public tender activity from the Government of India eProcurement portal:

https://eprocure.gov.in/eprocure/app

The app provides:

- Tender counts by status: open, in progress, upcoming, and closed
- Tenders grouped by bid submission closing date
- Key deadline insights
- Latest tender, closing-date, corrigendum, and award feeds
- Public tender document links when they are visible on tender detail pages
- Two-line document summaries for website and uploaded documents
- A chatbot-style question box for tender-specific questions
- Separate document chat for website documents and uploaded files
- Optional OpenAI-powered answers when `OPENAI_API_KEY` is configured

## Quick Start

From this folder:

```powershell
cd realestate
.\start.bat
```

Or manually:

```powershell
python app.py
# or, if Python is not on PATH but uv is available:
uv run python app.py
```

Then open:

```text
http://127.0.0.1:8080
```

## API Key

Create a `.env` file in this folder:

```text
OPENAI_API_KEY=your_key_here
OPENAI_MODEL=gpt-5
```

The app also works without an API key. In that mode the chatbot uses local tender data and rule-based answers.

## Document Review

The **Website Documents** tab lists document links discovered from public tender detail pages, with a short two-line summary and a download/review link where available.

The **Upload & Converse** tab stores uploaded files under `uploads/` and creates a two-line summary. Text-like files such as `.txt`, `.csv`, `.md`, `.json`, `.xml`, and `.html` are readable locally. PDFs and Office files are stored and summarized by metadata unless readable text can be extracted or an OpenAI key is configured.

## Notes

The eProcure portal exposes some public list pages without login, but full bidder participation such as "who submitted bids" may be restricted, appear only on specific tender detail pages after opening, or require site-side captcha/session navigation. The dashboard marks those fields as unavailable when not visible publicly.
