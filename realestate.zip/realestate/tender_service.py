from collections import Counter, defaultdict
from datetime import datetime, timedelta
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urljoin, urlparse
from urllib.request import Request, urlopen
import json
import os
import re
import ssl
import time
import zipfile
import zlib


BASE_URL = "https://eprocure.gov.in/eprocure/app"
TODAY = datetime.now


class LinkTextParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
        self.text = []
        self._href = None
        self._anchor = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == "a":
            self._href = dict(attrs).get("href", "")
            self._anchor = []

    def handle_endtag(self, tag):
        if tag.lower() == "a" and self._href is not None:
            label = " ".join(" ".join(self._anchor).split())
            if label:
                self.links.append({"text": label, "href": urljoin(BASE_URL, self._href)})
            self._href = None
            self._anchor = []

    def handle_data(self, data):
        clean = " ".join(data.split())
        if not clean:
            return
        self.text.append(clean)
        if self._href is not None:
            self._anchor.append(clean)


class TenderService:
    def __init__(self, root: Path):
        self.root = root
        self.cache_file = root / "data" / "cache.json"
        self.upload_dir = root / "uploads"
        self.upload_index = self.upload_dir / "uploads.json"
        self.cache_file.parent.mkdir(exist_ok=True)
        self.upload_dir.mkdir(exist_ok=True)

    def get_dashboard(self, refresh=False):
        if not refresh:
            cached = self._read_cache(max_age_seconds=900)
            if cached:
                return self._normalize_dashboard(cached)

        try:
            dashboard = self._build_dashboard(live=True)
            self.cache_file.write_text(json.dumps(dashboard, indent=2, ensure_ascii=False), encoding="utf-8")
            return dashboard
        except Exception as exc:
            cached = self._read_cache(max_age_seconds=None)
            if cached:
                cached["source"]["warning"] = f"Live refresh failed; showing cached data. {exc}"
                return self._normalize_dashboard(cached)
            sample = self._sample_dashboard(str(exc))
            self.cache_file.write_text(json.dumps(sample, indent=2, ensure_ascii=False), encoding="utf-8")
            return sample

    def _normalize_dashboard(self, dashboard):
        dashboard.setdefault("documents", [])
        dashboard.setdefault("uploaded_documents", self._read_uploads())
        counts = dashboard.setdefault("counts", {})
        counts.setdefault("documents", len(dashboard.get("documents", [])))
        counts["uploaded_documents"] = len(self._read_uploads())
        for tender in dashboard.get("tenders", []):
            tender.setdefault("documents", [])
        return dashboard

    def answer_question(self, question):
        data = self.get_dashboard(refresh=False)
        if not question:
            return {"answer": "Ask about deadlines, open tenders, closed tenders, organisations, references, or bidder availability.", "mode": "local"}

        api_key = os.environ.get("OPENAI_API_KEY", "").strip()
        if api_key:
            answer = self._answer_with_openai(question, data, api_key)
            if answer:
                return {"answer": answer, "mode": "openai"}

        return {"answer": self._answer_locally(question, data), "mode": "local"}

    def get_documents(self):
        data = self.get_dashboard(refresh=False)
        return {
            "website": data.get("documents", []),
            "uploaded": self._read_uploads(),
            "counts": {
                "website": len(data.get("documents", [])),
                "uploaded": len(self._read_uploads()),
            },
        }

    def save_upload(self, filename, content):
        safe_name = self._safe_filename(filename)
        if not safe_name:
            safe_name = f"document_{int(time.time())}.bin"
        target = self.upload_dir / f"{int(time.time())}_{safe_name}"
        target.write_bytes(content)
        extracted = self._clean_extracted_text(self._extract_upload_text(target, safe_name, content))
        doc = {
            "id": f"upload-{target.stem}",
            "source": "upload",
            "name": safe_name,
            "type": target.suffix.lower().lstrip(".") or "file",
            "size": len(content),
            "uploaded_at": TODAY().isoformat(timespec="seconds"),
            "path": str(target),
            "text_excerpt": extracted[:120000],
            "summary_lines": self._two_line_summary(safe_name, extracted, uploaded=True),
            "downloadable": False,
            "url": "",
        }
        uploads = [d for d in self._read_uploads() if d.get("id") != doc["id"]]
        uploads.insert(0, doc)
        self.upload_index.write_text(json.dumps(uploads, indent=2, ensure_ascii=False), encoding="utf-8")
        return doc

    def answer_document_question(self, question, scope="all", doc_id=""):
        docs = self.get_documents()
        selected = []
        if scope == "website":
            selected = docs["website"]
        elif scope == "uploaded":
            selected = docs["uploaded"]
        else:
            selected = docs["website"] + docs["uploaded"]
        if doc_id:
            selected = [d for d in selected if d.get("id") == doc_id]
        if not question:
            return {"answer": "Ask about available downloads, uploaded document summaries, clauses, dates, eligibility, scope, or risks.", "mode": "local"}

        api_key = os.environ.get("OPENAI_API_KEY", "").strip()
        payload = {"question": question, "documents": selected[:25]}
        if api_key:
            answer = self._answer_with_openai_for_payload(
                "You are a tender document analyst. Answer from the supplied website/uploaded document metadata and extracted text. If document text is unavailable, say that clearly and use the available metadata.",
                payload,
                api_key,
            )
            if answer:
                return {"answer": answer, "mode": "openai"}
        return {"answer": self._answer_documents_locally(question, selected), "mode": "local"}

    def _build_dashboard(self, live):
        home = self._fetch(BASE_URL)
        closing = self._fetch(f"{BASE_URL}?page=FrontEndListTendersbyDate&service=page")
        awards = self._fetch(f"{BASE_URL}?page=ResultOfTenders&service=page")
        corrigendum = self._fetch(f"{BASE_URL}?page=FrontEndLatestCorrigendum&service=page")

        tenders = []
        tenders.extend(self._parse_latest_tenders(home, "Latest Tenders"))
        tenders.extend(self._parse_closing_page(closing))
        tenders.extend(self._parse_latest_tenders(corrigendum, "Corrigendum"))
        awards_list = self._parse_awards(awards)

        tenders = self._dedupe(tenders)
        now = TODAY()
        for tender in tenders:
            closing_dt = self._parse_date(tender.get("closing_date"))
            opening_dt = self._parse_date(tender.get("opening_date"))
            tender["status"] = self._status_for(closing_dt, opening_dt, now)
            tender["days_to_close"] = None if not closing_dt else (closing_dt.date() - now.date()).days
            tender["bidder_submission_visibility"] = "Not available on public list page"
            tender["submitted_bidders"] = []
            tender["documents"] = []

        documents = self._discover_documents(tenders)
        docs_by_tender = defaultdict(list)
        for doc in documents:
            docs_by_tender[doc.get("tender_id") or doc.get("tender_title")].append(doc)
        for tender in tenders:
            key = tender.get("tender_id") or tender.get("title")
            tender["documents"] = docs_by_tender.get(key, [])

        counts = Counter(t["status"] for t in tenders)
        by_date = defaultdict(list)
        for tender in tenders:
            by_date[tender.get("closing_date") or "Unknown"].append(tender)

        deadline_rows = []
        for date_label, items in by_date.items():
            deadline_rows.append({
                "date": date_label,
                "count": len(items),
                "open_count": sum(1 for x in items if x["status"] == "Open"),
                "titles": [x["title"] for x in items[:5]],
            })

        deadline_rows.sort(key=lambda row: self._parse_date(row["date"]) or datetime.max)
        organisations = Counter(t.get("organisation") or "Unknown" for t in tenders)
        categories = Counter(t.get("category") or "Tender" for t in tenders)

        insights = self._make_insights(tenders, awards_list, organisations)
        return {
            "source": {
                "portal": BASE_URL,
                "live": live,
                "last_updated": now.isoformat(timespec="seconds"),
                "notes": [
                    "Active tender bulk search on eProcure may require captcha; this app uses public list/detail pages that are readable without login.",
                    "Bidder names are shown only when publicly exposed by the portal for a tender detail/status page.",
                ],
            },
            "counts": {
                "total": len(tenders),
                "open": counts.get("Open", 0),
                "in_progress": counts.get("In Progress", 0),
                "upcoming": counts.get("Upcoming", 0),
                "closed": counts.get("Closed", 0),
                "awards": len(awards_list),
                "corrigenda": categories.get("Corrigendum", 0),
                "documents": len(documents),
                "uploaded_documents": len(self._read_uploads()),
            },
            "insights": insights,
            "closing_dates": deadline_rows,
            "organisations": organisations.most_common(8),
            "tenders": tenders[:250],
            "documents": documents[:200],
            "uploaded_documents": self._read_uploads(),
            "awards": awards_list[:50],
        }

    def _fetch(self, url):
        req = Request(url, headers={
            "User-Agent": "Mozilla/5.0 TenderInsights/1.0",
            "Accept": "text/html,application/xhtml+xml",
        })
        ctx = ssl.create_default_context()
        with urlopen(req, timeout=25, context=ctx) as res:
            return res.read().decode("utf-8", errors="replace")

    def _parse_latest_tenders(self, html, category):
        parser = LinkTextParser()
        parser.feed(html)
        text = " ".join(parser.text)
        tenders = []
        date_re = r"\d{2}-[A-Za-z]{3}-\d{4}\s+\d{2}:\d{2}\s+[AP]M"
        for link in parser.links:
            label = re.sub(r"^\d+\.\s*", "", link["text"]).strip(" []")
            if not label or len(label) < 8:
                continue
            idx = text.find(link["text"])
            window = text[idx: idx + 450] if idx >= 0 else ""
            dates = re.findall(date_re, window)
            ref = ""
            if dates:
                before_first_date = window.split(dates[0])[0]
                ref = before_first_date.replace(link["text"], "").strip(" -[]")
            if dates or category == "Corrigendum":
                tenders.append({
                    "title": label,
                    "reference": ref,
                    "tender_id": self._extract_tender_id(window),
                    "closing_date": dates[0] if len(dates) > 0 else "",
                    "opening_date": dates[1] if len(dates) > 1 else "",
                    "published_date": "",
                    "organisation": self._extract_org(window),
                    "category": category,
                    "url": link["href"],
                })
        return tenders

    def _parse_closing_page(self, html):
        parser = LinkTextParser()
        parser.feed(html)
        text = " ".join(parser.text)
        tenders = []
        date_re = r"\d{2}-[A-Za-z]{3}-\d{4}\s+\d{2}:\d{2}\s+[AP]M"
        for link in parser.links:
            title = link["text"].strip(" []")
            if len(title) < 8 or title.lower() in {"back", "next", "previous"}:
                continue
            idx = text.find(link["text"])
            window = text[max(0, idx - 180): idx + 550] if idx >= 0 else ""
            dates = re.findall(date_re, window)
            ids = re.findall(r"\[(20\d{2}_[^\]]+)\]", window)
            refs = re.findall(r"\[([^\[\]]+)\]", window)
            if len(dates) >= 2:
                tenders.append({
                    "title": title,
                    "reference": refs[0] if refs else "",
                    "tender_id": ids[0] if ids else self._extract_tender_id(window),
                    "published_date": dates[0],
                    "closing_date": dates[1],
                    "opening_date": dates[2] if len(dates) > 2 else "",
                    "organisation": self._extract_org_after_title(window, title),
                    "category": "Closing Date",
                    "url": link["href"],
                })
        return tenders

    def _parse_awards(self, html):
        parser = LinkTextParser()
        parser.feed(html)
        awards = []
        text = " ".join(parser.text)
        for link in parser.links:
            label = link["text"].strip(" []")
            if len(label) > 8 and label.lower() not in {"back", "search"}:
                idx = text.find(link["text"])
                window = text[idx: idx + 350] if idx >= 0 else ""
                awards.append({
                    "title": label,
                    "reference": self._extract_tender_id(window),
                    "url": link["href"],
                })
        return awards

    def _discover_documents(self, tenders, limit=30):
        documents = []
        seen = set()
        for tender in tenders[:limit]:
            url = tender.get("url")
            if not url:
                continue
            try:
                html = self._fetch(url)
            except Exception:
                continue
            for doc in self._parse_document_links(html, tender):
                key = (doc.get("url"), doc.get("name"), doc.get("tender_id"))
                if key in seen:
                    continue
                seen.add(key)
                documents.append(doc)
        return documents

    def _parse_document_links(self, html, tender):
        parser = LinkTextParser()
        parser.feed(html)
        docs = []
        for link in parser.links:
            href = link.get("href", "")
            text = link.get("text", "").strip()
            haystack = f"{href} {text}".lower()
            if not self._looks_like_document(haystack):
                continue
            name = self._document_name(text, href)
            doc_id = f"web-{abs(hash((href, name, tender.get('tender_id'))))}"
            docs.append({
                "id": doc_id,
                "source": "website",
                "name": name,
                "type": self._doc_type(name, href),
                "tender_title": tender.get("title", ""),
                "tender_id": tender.get("tender_id", ""),
                "reference": tender.get("reference", ""),
                "closing_date": tender.get("closing_date", ""),
                "url": href,
                "downloadable": True,
                "summary_lines": self._two_line_summary(name, f"{tender.get('title', '')} {tender.get('reference', '')}", uploaded=False),
                "text_excerpt": "",
            })
        return docs

    def _status_for(self, closing_dt, opening_dt, now):
        if closing_dt and closing_dt >= now:
            if (closing_dt.date() - now.date()).days > 14:
                return "Upcoming"
            return "Open"
        if opening_dt and opening_dt >= now - timedelta(days=30):
            return "In Progress"
        return "Closed"

    def _make_insights(self, tenders, awards, organisations):
        now = TODAY()
        open_tenders = [t for t in tenders if t["status"] in {"Open", "Upcoming"}]
        closing_soon = sorted(
            [t for t in open_tenders if t.get("days_to_close") is not None and t["days_to_close"] <= 7],
            key=lambda t: (t["days_to_close"], t.get("closing_date") or ""),
        )
        return {
            "headline": f"{len(open_tenders)} public tenders are currently open/upcoming in the fetched data.",
            "closing_soon": closing_soon[:10],
            "top_organisation": organisations.most_common(1)[0][0] if organisations else "Unknown",
            "award_activity": f"{len(awards)} award/result entries found on the public awards page.",
            "data_gap": "Submitted bidder names are not visible on the public list pages; open each tender detail/status page when the portal publishes bidder participation.",
            "generated_at": now.strftime("%d-%b-%Y %I:%M %p"),
        }

    def _answer_locally(self, question, data):
        q = question.lower()
        tenders = data.get("tenders", [])
        if any(word in q for word in ["closing", "deadline", "last date", "submit"]):
            rows = data.get("closing_dates", [])[:8]
            return "Upcoming bid submission deadlines:\n" + "\n".join(f"- {r['date']}: {r['count']} tender(s)" for r in rows)
        if any(word in q for word in ["open", "active"]):
            items = [t for t in tenders if t["status"] in {"Open", "Upcoming"}][:8]
            return "Open/upcoming tenders:\n" + "\n".join(f"- {t['title']} | closes {t.get('closing_date') or 'unknown'}" for t in items)
        if any(word in q for word in ["closed", "complete"]):
            return f"Closed tenders in the fetched data: {data.get('counts', {}).get('closed', 0)}."
        if any(word in q for word in ["bidder", "submitted", "participants", "who"]):
            return data.get("insights", {}).get("data_gap", "Bidder submission names were not visible in the public feed.")
        matches = []
        for tender in tenders:
            haystack = " ".join([tender.get("title", ""), tender.get("reference", ""), tender.get("tender_id", ""), tender.get("organisation", "")]).lower()
            if any(token for token in q.split() if len(token) > 3 and token in haystack):
                matches.append(tender)
        if matches:
            return "Matching tenders:\n" + "\n".join(f"- {t['title']} | {t['status']} | closes {t.get('closing_date') or 'unknown'}" for t in matches[:8])
        return data.get("insights", {}).get("headline", "No matching tender insight found. Try asking about deadlines, open tenders, bidder data, or an organisation.")

    def _answer_with_openai(self, question, data, api_key):
        return self._answer_with_openai_for_payload(
            "You are a tender intelligence analyst. Answer from the provided eProcure dashboard JSON. Be concise and mention unavailable data honestly.",
            {"question": question, "dashboard": data},
            api_key,
        )

    def _answer_with_openai_for_payload(self, instructions, payload_data, api_key):
        try:
            payload = {
                "model": os.environ.get("OPENAI_MODEL", "gpt-5"),
                "instructions": instructions,
                "input": json.dumps(payload_data, ensure_ascii=False)[:45000],
                "temperature": 0.2,
            }
            body = json.dumps(payload).encode("utf-8")
            req = Request("https://api.openai.com/v1/responses", data=body, method="POST", headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            })
            with urlopen(req, timeout=35) as res:
                obj = json.loads(res.read().decode("utf-8"))
            if obj.get("output_text"):
                return obj["output_text"].strip()
            chunks = []
            for item in obj.get("output", []):
                for content in item.get("content", []):
                    if content.get("type") in {"output_text", "text"} and content.get("text"):
                        chunks.append(content["text"])
            return "\n".join(chunks).strip() or None
        except Exception:
            return None

    def _answer_documents_locally(self, question, documents):
        q = question.lower()
        if not documents:
            return "No website or uploaded documents are available yet. Refresh live data or upload a file first."
        text_docs = [d for d in documents if self._document_text(d)]
        if text_docs and not any(word in q for word in ["download", "available", "link"]):
            return self._answer_from_uploaded_text(question, text_docs)
        if any(word in q for word in ["download", "available", "link"]):
            downloadable = [d for d in documents if d.get("downloadable")]
            if not downloadable:
                if text_docs:
                    return "Uploaded documents are available for chat in this tab, but they are local uploads and do not have public download links."
                return "No downloadable public document links were found in the currently fetched data."
            return "Documents available to download/review:\n" + "\n".join(
                f"- {d.get('name')} | {d.get('tender_title') or 'Uploaded file'} | {d.get('url') or 'local upload'}"
                for d in downloadable[:10]
            )
        if any(word in q for word in ["summary", "insight", "about", "two", "2"]):
            return "Document insights:\n" + "\n".join(
                f"- {d.get('name')}: {' '.join(d.get('summary_lines', []))}"
                for d in documents[:10]
            )
        matches = []
        tokens = self._question_tokens(q)
        for doc in documents:
            haystack = " ".join([
                doc.get("name", ""),
                doc.get("tender_title", ""),
                doc.get("reference", ""),
                self._document_text(doc),
                " ".join(doc.get("summary_lines", [])),
            ]).lower()
            if any(token in haystack for token in tokens):
                matches.append(doc)
        if matches:
            return "Matching documents:\n" + "\n".join(
                f"- {d.get('name')} | {' '.join(d.get('summary_lines', []))}"
                for d in matches[:10]
            )
        return f"{len(documents)} document record(s) are available. Ask for download links, summaries, tender references, or upload text-specific clauses."

    def _answer_from_uploaded_text(self, question, documents):
        q = question.lower()
        if any(word in q for word in ["summary", "summarize", "overview", "brief"]):
            return "Uploaded document overview:\n" + "\n\n".join(self._document_overview(doc) for doc in documents[:3])

        if any(word in q for word in ["all", "full", "information", "details", "content", "read", "explain"]):
            return "Here is the readable content overview from the uploaded document(s):\n\n" + "\n\n".join(
                self._document_overview(doc, include_excerpt=True, include_key_points=True) for doc in documents[:3]
            )

        snippets = []
        for doc in documents:
            snippets.extend(self._relevant_snippets(question, doc, limit=4))

        if snippets:
            return "I found this in the uploaded document content:\n\n" + "\n\n".join(snippets[:8])

        return "I can read the uploaded document text, but I did not find an exact match for that question. Try asking for a clause, date, eligibility, scope, payment, EMD, BOQ, address, or a full overview."

    def _document_text(self, doc):
        return self._clean_extracted_text(doc.get("text_excerpt", ""))

    def _document_overview(self, doc, include_excerpt=False, include_key_points=False):
        text = self._document_text(doc)
        lines = doc.get("summary_lines", [])
        answer = [f"{doc.get('name', 'Uploaded document')}"]
        if lines:
            answer.extend(f"- {line}" for line in lines[:2])
        if text:
            answer.append(f"- Readable text captured: {len(text):,} characters.")
            if include_key_points:
                key_points = self._extract_key_points(text)
                if key_points:
                    answer.append("- Key information found:")
                    answer.extend(f"  {point}" for point in key_points)
            if include_excerpt:
                answer.append(f"- Content excerpt: {text[:2200]}")
        else:
            answer.append("- No readable text was extracted from this file. For scanned PDFs/images, use OCR first or enable OpenAI with a text-readable file.")
        return "\n".join(answer)

    def _extract_key_points(self, text):
        labels = [
            ("Notice", r"(NOTICE INVITING TENDER.{0,220})"),
            ("Reference", r"(\b\d+\s*A\s*R\s*/\s*E[^.]{0,100})"),
            ("Work", r"(Name of work.{0,420})"),
            ("Cost and EMD", r"(Approximate cost.{0,360})"),
            ("Last date", r"(Last date.{0,340})"),
            ("Eligibility", r"(eligibility.{0,340})"),
        ]
        points = []
        for label, pattern in labels:
            match = re.search(pattern, text, re.I)
            if match:
                points.append(f"{label}: {match.group(1).strip()[:380]}")
        return points[:6]

    def _relevant_snippets(self, question, doc, limit=4):
        text = self._document_text(doc)
        if not text:
            return []
        tokens = self._question_tokens(question.lower())
        if not tokens:
            return [f"{doc.get('name', 'Uploaded document')}:\n{text[:900]}"]

        sentences = re.split(r"(?<=[.!?])\s+|\n+", text)
        scored = []
        for sentence in sentences:
            clean = sentence.strip()
            if len(clean) < 12:
                continue
            lower = clean.lower()
            score = sum(1 for token in tokens if token in lower)
            if score:
                scored.append((score, len(clean), clean))
        scored.sort(key=lambda item: (-item[0], item[1]))
        snippets = []
        for _, _, sentence in scored[:limit]:
            snippets.append(f"{doc.get('name', 'Uploaded document')}:\n{sentence[:1000]}")
        return snippets

    def _question_tokens(self, value):
        short_terms = {"emd", "gst", "boq", "nit", "bid", "fee", "pdf", "loa"}
        return [
            token for token in re.split(r"\W+", value.lower())
            if len(token) > 3 or token in short_terms
        ]

    def _read_cache(self, max_age_seconds):
        if not self.cache_file.exists():
            return None
        if max_age_seconds is not None and time.time() - self.cache_file.stat().st_mtime > max_age_seconds:
            return None
        return json.loads(self.cache_file.read_text(encoding="utf-8"))

    def _read_uploads(self):
        if not self.upload_index.exists():
            return []
        try:
            uploads = json.loads(self.upload_index.read_text(encoding="utf-8-sig"))
        except Exception:
            return []
        if isinstance(uploads, dict) and isinstance(uploads.get("value"), list):
            uploads = uploads["value"]
            changed = True
        elif isinstance(uploads, dict):
            uploads = [uploads]
            changed = True
        else:
            changed = False
        if isinstance(uploads, list) and len(uploads) == 1 and isinstance(uploads[0], dict) and isinstance(uploads[0].get("value"), list):
            uploads = uploads[0]["value"]
            changed = True
        original_len = len(uploads) if isinstance(uploads, list) else 0
        uploads = [doc for doc in uploads if isinstance(doc, dict)]
        if len(uploads) != original_len:
            changed = True
        uploads, deduped = self._dedupe_uploads(uploads)
        if deduped:
            changed = True
        for doc in uploads:
            cleaned = self._clean_extracted_text(doc.get("text_excerpt", ""))
            path = Path(doc.get("path", ""))
            if (not cleaned or cleaned != doc.get("text_excerpt", "")) and path.exists():
                try:
                    cleaned = self._clean_extracted_text(self._extract_upload_text(path, doc.get("name", path.name), path.read_bytes()))
                except Exception:
                    cleaned = ""
            if cleaned != doc.get("text_excerpt", ""):
                doc["text_excerpt"] = cleaned[:120000]
                doc["summary_lines"] = self._two_line_summary(doc.get("name", "Uploaded document"), cleaned, uploaded=True)
                changed = True
        if changed:
            self.upload_index.write_text(json.dumps(uploads, indent=2, ensure_ascii=False), encoding="utf-8")
        return uploads

    def _dedupe(self, tenders):
        seen = set()
        output = []
        for tender in tenders:
            key = (tender.get("tender_id") or tender.get("reference") or tender.get("title", "")[:80]).lower()
            if key in seen:
                continue
            seen.add(key)
            output.append(tender)
        return output

    def _parse_date(self, value):
        if not value:
            return None
        for fmt in ("%d-%b-%Y %I:%M %p", "%d-%b-%Y"):
            try:
                return datetime.strptime(value.strip(), fmt)
            except ValueError:
                pass
        return None

    def _extract_tender_id(self, text):
        match = re.search(r"20\d{2}_[A-Z0-9]+_\d+_\d+", text)
        return match.group(0) if match else ""

    def _extract_org(self, text):
        bits = re.split(r"\|\||Visitor No|Designed", text)
        candidates = [b.strip(" []") for b in bits if len(b.strip()) > 12]
        return candidates[-1][:140] if candidates else "Unknown"

    def _extract_org_after_title(self, window, title):
        tail = window.split(title, 1)[-1]
        tail = re.sub(r"\[[^\]]+\]", " ", tail)
        tail = re.sub(r"\d{2}-[A-Za-z]{3}-\d{4}\s+\d{2}:\d{2}\s+[AP]M", " ", tail)
        tail = " ".join(tail.split())
        return tail[:160] if tail else "Unknown"

    def _looks_like_document(self, value):
        doc_words = [
            ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".zip", ".rar",
            "download", "document", "nit", "boq", "corrigendum",
        ]
        return any(word in value for word in doc_words)

    def _document_name(self, text, href):
        if text and text.lower() not in {"click here", "download"}:
            return text[:140]
        parsed = urlparse(href)
        name = unquote(Path(parsed.path).name or "Tender document")
        return name[:140]

    def _doc_type(self, name, href):
        value = f"{name} {href}".lower()
        for ext in ["pdf", "docx", "doc", "xlsx", "xls", "zip", "rar", "csv", "txt"]:
            if f".{ext}" in value or value.endswith(ext):
                return ext
        if "boq" in value:
            return "boq"
        if "corrigendum" in value:
            return "corrigendum"
        return "document"

    def _two_line_summary(self, name, text, uploaded=False):
        clean = " ".join(re.sub(r"<[^>]+>", " ", text or "").split())
        if uploaded:
            if clean:
                line1 = f"Uploaded file '{name}' has readable text that can be searched and discussed."
                line2 = clean[:180]
            else:
                line1 = f"Uploaded file '{name}' is stored for review, but readable text was not extracted."
                line2 = "Use the original file for visual review, or upload a text/CSV/HTML version for deeper local chat."
        else:
            line1 = f"Public tender document link: {name}."
            line2 = f"Related tender/reference context: {clean[:180] or 'No extra public context captured.'}"
        return [line1, line2]

    def _safe_filename(self, filename):
        filename = Path(filename or "").name
        return re.sub(r"[^A-Za-z0-9._ -]", "_", filename).strip(" ._")

    def _extract_upload_text(self, path, filename, content):
        ext = path.suffix.lower()
        if ext in {".txt", ".csv", ".md", ".json", ".xml", ".html", ".htm", ".log"}:
            return content.decode("utf-8", errors="ignore")
        if ext == ".pdf":
            return self._extract_pdf_text(content)
        if ext == ".docx":
            return self._extract_docx_text(path)
        if ext == ".xlsx":
            return self._extract_xlsx_text(path)
        if ext in {".doc", ".xls", ".zip"}:
            return ""
        try:
            return content.decode("utf-8", errors="ignore")
        except Exception:
            return ""

    def _dedupe_uploads(self, uploads):
        selected = {}
        changed = False
        for doc in uploads:
            key = (doc.get("name", "").lower(), doc.get("size", 0))
            current = selected.get(key)
            if current is None or doc.get("uploaded_at", "") >= current.get("uploaded_at", ""):
                if current is not None:
                    changed = True
                selected[key] = doc
            else:
                changed = True
        output = sorted(selected.values(), key=lambda item: item.get("uploaded_at", ""), reverse=True)
        return output, changed

    def _extract_pdf_text(self, content):
        pieces = []
        for match in re.finditer(rb"stream\r?\n(.*?)\r?\nendstream", content, re.S):
            raw = match.group(1).strip(b"\r\n")
            try:
                decoded = zlib.decompress(raw)
            except Exception:
                continue
            stream_text = decoded.decode("latin-1", errors="ignore")
            pieces.append(self._extract_pdf_text_operators(stream_text))
        if pieces:
            return self._normalize_pdf_text(" ".join(pieces))

        text = content.decode("latin-1", errors="ignore")
        chunks = re.findall(r"\(([^()]{12,})\)", text)
        return self._normalize_pdf_text(" ".join(self._decode_pdf_literal(chunk) for chunk in chunks[:500]))

    def _extract_pdf_text_operators(self, stream_text):
        chunks = []
        for literal in re.findall(r"\((?:\\.|[^\\()])*\)", stream_text):
            decoded = self._decode_pdf_literal(literal[1:-1])
            if decoded:
                chunks.append(decoded)
        for hex_literal in re.findall(r"<([0-9A-Fa-f\s]{8,})>", stream_text):
            cleaned = re.sub(r"\s+", "", hex_literal)
            try:
                raw = bytes.fromhex(cleaned)
            except ValueError:
                continue
            for encoding in ("utf-16-be", "latin-1"):
                decoded = raw.decode(encoding, errors="ignore").strip()
                if decoded:
                    chunks.append(decoded)
                    break
        return " ".join(chunks)

    def _decode_pdf_literal(self, value):
        value = re.sub(r"\\([nrtbf()\\])", lambda m: {
            "n": "\n", "r": "\r", "t": "\t", "b": "\b", "f": "\f",
            "(": "(", ")": ")", "\\": "\\",
        }[m.group(1)], value)
        value = re.sub(r"\\([0-7]{1,3})", lambda m: chr(int(m.group(1), 8)), value)
        return value.strip()

    def _normalize_pdf_text(self, text):
        text = re.sub(r"\b[a-z]{2}-[A-Z]{2}\b", " ", text)
        text = re.sub(r"\bpt-BR\b|\ben-GB\b|\ben-US\b", " ", text)
        text = re.sub(r"\s+([,.:;])", r"\1", text)
        text = re.sub(r"\s*-\s*", "-", text)
        text = re.sub(r"\s+", " ", text).strip()
        # PDFs generated from Word often split words into tiny drawing chunks.
        fixes = {
            "O F F ICE": "OFFICE",
            "O F": "OF",
            "T HE": "THE",
            "CO M M A ND A NT": "COMMANDANT",
            "A S S A M RIF L E S": "ASSAM RIFLES",
            "NO T ICE INV IT ING T E NDE R": "NOTICE INVITING TENDER",
            "Date d": "Dated",
            "Ma y": "May",
            "wi t h": "with",
            "be h al f": "behalf",
            "f r om": "from",
            "a nd": "and",
            "s el ec ti o n": "selection",
            "O nl i ne": "Online",
            "ten de r": "tender",
            "t en d e r": "tender",
            "f ee s": "fees",
            "he r e b y": "hereby",
            "i nv i te d": "invited",
            "P r es i d en t": "President",
            "I nd i a": "India",
            "c on tr ac tors": "contractors",
            "e l i g i b i l i t y": "eligibility",
            "S eri al": "Serial",
            "Nam e o f w ork": "Name of work",
            "A pp r ox i m ate c os t": "Approximate cost",
            "E arnes t m on e y": "Earnest money",
            "T en de r f ee": "Tender fee",
        }
        for bad, good in fixes.items():
            text = text.replace(bad, good)
        return text

    def _extract_docx_text(self, path):
        try:
            with zipfile.ZipFile(path) as zf:
                xml = zf.read("word/document.xml").decode("utf-8", errors="ignore")
            xml = re.sub(r"</w:p>", "\n", xml)
            return re.sub(r"<[^>]+>", " ", xml)
        except Exception:
            return ""

    def _extract_xlsx_text(self, path):
        try:
            chunks = []
            with zipfile.ZipFile(path) as zf:
                for name in zf.namelist():
                    if name.endswith(".xml") and ("sharedStrings" in name or "worksheets/sheet" in name):
                        chunks.append(zf.read(name).decode("utf-8", errors="ignore"))
            return re.sub(r"<[^>]+>", " ", "\n".join(chunks))
        except Exception:
            return ""

    def _clean_extracted_text(self, text):
        if not text:
            return ""
        mojibake = sum(text.count(ch) for ch in "ÂÃ�þÿ")
        if mojibake / max(len(text), 1) > 0.03:
            return ""
        text = text.replace("\x00", " ")
        text = re.sub(r"[\x01-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        if not text:
            return ""
        ascii_printable = sum(1 for ch in text if 32 <= ord(ch) <= 126)
        if ascii_printable / max(len(text), 1) < 0.70:
            return ""
        printable = sum(1 for ch in text if ch.isprintable())
        alpha_num = sum(1 for ch in text if ch.isalnum())
        if printable / max(len(text), 1) < 0.85 or alpha_num / max(len(text), 1) < 0.25:
            return ""
        return text

    def _sample_dashboard(self, error):
        now = TODAY()
        return {
            "source": {
                "portal": BASE_URL,
                "live": False,
                "last_updated": now.isoformat(timespec="seconds"),
                "warning": f"Live fetch unavailable; sample data is displayed. {error}",
                "notes": ["Install/connect internet and click Refresh for live portal data."],
            },
            "counts": {"total": 3, "open": 2, "in_progress": 1, "upcoming": 0, "closed": 0, "awards": 0, "corrigenda": 0, "documents": 1, "uploaded_documents": len(self._read_uploads())},
            "insights": {
                "headline": "Sample mode: connect to eProcure for live tender intelligence.",
                "closing_soon": [],
                "top_organisation": "Sample Organisation",
                "award_activity": "No live award data in sample mode.",
                "data_gap": "Bidder names require public detail-page visibility.",
                "generated_at": now.strftime("%d-%b-%Y %I:%M %p"),
            },
            "closing_dates": [{"date": "21-May-2026 03:00 PM", "count": 2, "open_count": 2, "titles": ["Sample civil works tender", "Sample supply tender"]}],
            "organisations": [["Sample Organisation", 3]],
            "tenders": [
                {"title": "Sample civil works tender", "reference": "NIT/001", "tender_id": "2026_SAMPLE_1", "published_date": "", "closing_date": "21-May-2026 03:00 PM", "opening_date": "22-May-2026 03:30 PM", "organisation": "Sample Organisation", "category": "Latest Tenders", "status": "Open", "days_to_close": 5, "submitted_bidders": [], "bidder_submission_visibility": "Not available in sample mode", "documents": [], "url": BASE_URL},
                {"title": "Sample maintenance tender", "reference": "NIT/002", "tender_id": "2026_SAMPLE_2", "published_date": "", "closing_date": "23-May-2026 11:00 AM", "opening_date": "25-May-2026 11:30 AM", "organisation": "Sample Organisation", "category": "Closing Date", "status": "Open", "days_to_close": 7, "submitted_bidders": [], "bidder_submission_visibility": "Not available in sample mode", "documents": [], "url": BASE_URL},
                {"title": "Sample bid under evaluation", "reference": "NIT/003", "tender_id": "2026_SAMPLE_3", "published_date": "", "closing_date": "15-May-2026 02:00 PM", "opening_date": "16-May-2026 02:00 PM", "organisation": "Sample Organisation", "category": "Closing Date", "status": "In Progress", "days_to_close": -1, "submitted_bidders": [], "bidder_submission_visibility": "Not available in sample mode", "documents": [], "url": BASE_URL},
            ],
            "documents": [{
                "id": "web-sample-doc",
                "source": "website",
                "name": "Sample NIT document",
                "type": "pdf",
                "tender_title": "Sample civil works tender",
                "tender_id": "2026_SAMPLE_1",
                "reference": "NIT/001",
                "closing_date": "21-May-2026 03:00 PM",
                "url": BASE_URL,
                "downloadable": True,
                "summary_lines": ["Public tender document link: Sample NIT document.", "Related tender/reference context: Sample civil works tender NIT/001."],
                "text_excerpt": "",
            }],
            "uploaded_documents": self._read_uploads(),
            "awards": [],
        }
