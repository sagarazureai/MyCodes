from collections import Counter, defaultdict
from datetime import datetime, timedelta
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin
from urllib.request import Request, urlopen
import json
import os
import re
import ssl
import time


BASE_URL = "https://eprocure.gov.in/eprocure/app"
TODAY = datetime.now


class LinkTextParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
        self.text = []
        self._href = None
        self._anchor = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == "a":
            self._href = dict(attrs).get("href", "")
            self._anchor = []

    def handle_endtag(self, tag):
        if tag.lower() == "a" and self._href is not None:
            label = " ".join(" ".join(self._anchor).split())
            if label:
                self.links.append({"text": label, "href": urljoin(BASE_URL, self._href)})
            self._href = None
            self._anchor = []

    def handle_data(self, data):
        clean = " ".join(data.split())
        if not clean:
            return
        self.text.append(clean)
        if self._href is not None:
            self._anchor.append(clean)


class TenderService:
    def __init__(self, root: Path):
        self.root = root
        self.cache_file = root / "data" / "cache.json"
        self.cache_file.parent.mkdir(exist_ok=True)

    def get_dashboard(self, refresh=False):
        if not refresh:
            cached = self._read_cache(max_age_seconds=900)
            if cached:
                return cached

        try:
            dashboard = self._build_dashboard(live=True)
            self.cache_file.write_text(json.dumps(dashboard, indent=2, ensure_ascii=False), encoding="utf-8")
            return dashboard
        except Exception as exc:
            cached = self._read_cache(max_age_seconds=None)
            if cached:
                cached["source"]["warning"] = f"Live refresh failed; showing cached data. {exc}"
                return cached
            sample = self._sample_dashboard(str(exc))
            self.cache_file.write_text(json.dumps(sample, indent=2, ensure_ascii=False), encoding="utf-8")
            return sample

    def answer_question(self, question):
        data = self.get_dashboard(refresh=False)
        if not question:
            return {"answer": "Ask about deadlines, open tenders, closed tenders, organisations, references, or bidder availability.", "mode": "local"}

        api_key = os.environ.get("OPENAI_API_KEY", "").strip()
        if api_key:
            answer = self._answer_with_openai(question, data, api_key)
            if answer:
                return {"answer": answer, "mode": "openai"}

        return {"answer": self._answer_locally(question, data), "mode": "local"}

    def _build_dashboard(self, live):
        home = self._fetch(BASE_URL)
        closing = self._fetch(f"{BASE_URL}?page=FrontEndListTendersbyDate&service=page")
        awards = self._fetch(f"{BASE_URL}?page=ResultOfTenders&service=page")
        corrigendum = self._fetch(f"{BASE_URL}?page=FrontEndLatestCorrigendum&service=page")

        tenders = []
        tenders.extend(self._parse_latest_tenders(home, "Latest Tenders"))
        tenders.extend(self._parse_closing_page(closing))
        tenders.extend(self._parse_latest_tenders(corrigendum, "Corrigendum"))
        awards_list = self._parse_awards(awards)

        tenders = self._dedupe(tenders)
        now = TODAY()
        for tender in tenders:
            closing_dt = self._parse_date(tender.get("closing_date"))
            opening_dt = self._parse_date(tender.get("opening_date"))
            tender["status"] = self._status_for(closing_dt, opening_dt, now)
            tender["days_to_close"] = None if not closing_dt else (closing_dt.date() - now.date()).days
            tender["bidder_submission_visibility"] = "Not available on public list page"
            tender["submitted_bidders"] = []

        counts = Counter(t["status"] for t in tenders)
        by_date = defaultdict(list)
        for tender in tenders:
            by_date[tender.get("closing_date") or "Unknown"].append(tender)

        deadline_rows = []
        for date_label, items in by_date.items():
            deadline_rows.append({
                "date": date_label,
                "count": len(items),
                "open_count": sum(1 for x in items if x["status"] == "Open"),
                "titles": [x["title"] for x in items[:5]],
            })

        deadline_rows.sort(key=lambda row: self._parse_date(row["date"]) or datetime.max)
        organisations = Counter(t.get("organisation") or "Unknown" for t in tenders)
        categories = Counter(t.get("category") or "Tender" for t in tenders)

        insights = self._make_insights(tenders, awards_list, organisations)
        return {
            "source": {
                "portal": BASE_URL,
                "live": live,
                "last_updated": now.isoformat(timespec="seconds"),
                "notes": [
                    "Active tender bulk search on eProcure may require captcha; this app uses public list/detail pages that are readable without login.",
                    "Bidder names are shown only when publicly exposed by the portal for a tender detail/status page.",
                ],
            },
            "counts": {
                "total": len(tenders),
                "open": counts.get("Open", 0),
                "in_progress": counts.get("In Progress", 0),
                "upcoming": counts.get("Upcoming", 0),
                "closed": counts.get("Closed", 0),
                "awards": len(awards_list),
                "corrigenda": categories.get("Corrigendum", 0),
            },
            "insights": insights,
            "closing_dates": deadline_rows,
            "organisations": organisations.most_common(8),
            "tenders": tenders[:250],
            "awards": awards_list[:50],
        }

    def _fetch(self, url):
        req = Request(url, headers={
            "User-Agent": "Mozilla/5.0 TenderInsights/1.0",
            "Accept": "text/html,application/xhtml+xml",
        })
        ctx = ssl.create_default_context()
        with urlopen(req, timeout=25, context=ctx) as res:
            return res.read().decode("utf-8", errors="replace")

    def _parse_latest_tenders(self, html, category):
        parser = LinkTextParser()
        parser.feed(html)
        text = " ".join(parser.text)
        tenders = []
        date_re = r"\d{2}-[A-Za-z]{3}-\d{4}\s+\d{2}:\d{2}\s+[AP]M"
        for link in parser.links:
            label = re.sub(r"^\d+\.\s*", "", link["text"]).strip(" []")
            if not label or len(label) < 8:
                continue
            idx = text.find(link["text"])
            window = text[idx: idx + 450] if idx >= 0 else ""
            dates = re.findall(date_re, window)
            ref = ""
            if dates:
                before_first_date = window.split(dates[0])[0]
                ref = before_first_date.replace(link["text"], "").strip(" -[]")
            if dates or category == "Corrigendum":
                tenders.append({
                    "title": label,
                    "reference": ref,
                    "tender_id": self._extract_tender_id(window),
                    "closing_date": dates[0] if len(dates) > 0 else "",
                    "opening_date": dates[1] if len(dates) > 1 else "",
                    "published_date": "",
                    "organisation": self._extract_org(window),
                    "category": category,
                    "url": link["href"],
                })
        return tenders

    def _parse_closing_page(self, html):
        parser = LinkTextParser()
        parser.feed(html)
        text = " ".join(parser.text)
        tenders = []
        date_re = r"\d{2}-[A-Za-z]{3}-\d{4}\s+\d{2}:\d{2}\s+[AP]M"
        for link in parser.links:
            title = link["text"].strip(" []")
            if len(title) < 8 or title.lower() in {"back", "next", "previous"}:
                continue
            idx = text.find(link["text"])
            window = text[max(0, idx - 180): idx + 550] if idx >= 0 else ""
            dates = re.findall(date_re, window)
            ids = re.findall(r"\[(20\d{2}_[^\]]+)\]", window)
            refs = re.findall(r"\[([^\[\]]+)\]", window)
            if len(dates) >= 2:
                tenders.append({
                    "title": title,
                    "reference": refs[0] if refs else "",
                    "tender_id": ids[0] if ids else self._extract_tender_id(window),
                    "published_date": dates[0],
                    "closing_date": dates[1],
                    "opening_date": dates[2] if len(dates) > 2 else "",
                    "organisation": self._extract_org_after_title(window, title),
                    "category": "Closing Date",
                    "url": link["href"],
                })
        return tenders

    def _parse_awards(self, html):
        parser = LinkTextParser()
        parser.feed(html)
        awards = []
        text = " ".join(parser.text)
        for link in parser.links:
            label = link["text"].strip(" []")
            if len(label) > 8 and label.lower() not in {"back", "search"}:
                idx = text.find(link["text"])
                window = text[idx: idx + 350] if idx >= 0 else ""
                awards.append({
                    "title": label,
                    "reference": self._extract_tender_id(window),
                    "url": link["href"],
                })
        return awards

    def _status_for(self, closing_dt, opening_dt, now):
        if closing_dt and closing_dt >= now:
            if (closing_dt.date() - now.date()).days > 14:
                return "Upcoming"
            return "Open"
        if opening_dt and opening_dt >= now - timedelta(days=30):
            return "In Progress"
        return "Closed"

    def _make_insights(self, tenders, awards, organisations):
        now = TODAY()
        open_tenders = [t for t in tenders if t["status"] in {"Open", "Upcoming"}]
        closing_soon = sorted(
            [t for t in open_tenders if t.get("days_to_close") is not None and t["days_to_close"] <= 7],
            key=lambda t: (t["days_to_close"], t.get("closing_date") or ""),
        )
        return {
            "headline": f"{len(open_tenders)} public tenders are currently open/upcoming in the fetched data.",
            "closing_soon": closing_soon[:10],
            "top_organisation": organisations.most_common(1)[0][0] if organisations else "Unknown",
            "award_activity": f"{len(awards)} award/result entries found on the public awards page.",
            "data_gap": "Submitted bidder names are not visible on the public list pages; open each tender detail/status page when the portal publishes bidder participation.",
            "generated_at": now.strftime("%d-%b-%Y %I:%M %p"),
        }

    def _answer_locally(self, question, data):
        q = question.lower()
        tenders = data.get("tenders", [])
        if any(word in q for word in ["closing", "deadline", "last date", "submit"]):
            rows = data.get("closing_dates", [])[:8]
            return "Upcoming bid submission deadlines:\n" + "\n".join(f"- {r['date']}: {r['count']} tender(s)" for r in rows)
        if any(word in q for word in ["open", "active"]):
            items = [t for t in tenders if t["status"] in {"Open", "Upcoming"}][:8]
            return "Open/upcoming tenders:\n" + "\n".join(f"- {t['title']} | closes {t.get('closing_date') or 'unknown'}" for t in items)
        if any(word in q for word in ["closed", "complete"]):
            return f"Closed tenders in the fetched data: {data.get('counts', {}).get('closed', 0)}."
        if any(word in q for word in ["bidder", "submitted", "participants", "who"]):
            return data.get("insights", {}).get("data_gap", "Bidder submission names were not visible in the public feed.")
        matches = []
        for tender in tenders:
            haystack = " ".join([tender.get("title", ""), tender.get("reference", ""), tender.get("tender_id", ""), tender.get("organisation", "")]).lower()
            if any(token for token in q.split() if len(token) > 3 and token in haystack):
                matches.append(tender)
        if matches:
            return "Matching tenders:\n" + "\n".join(f"- {t['title']} | {t['status']} | closes {t.get('closing_date') or 'unknown'}" for t in matches[:8])
        return data.get("insights", {}).get("headline", "No matching tender insight found. Try asking about deadlines, open tenders, bidder data, or an organisation.")

    def _answer_with_openai(self, question, data, api_key):
        try:
            payload = {
                "model": os.environ.get("OPENAI_MODEL", "gpt-5"),
                "instructions": "You are a tender intelligence analyst. Answer from the provided eProcure dashboard JSON. Be concise and mention unavailable data honestly.",
                "input": json.dumps({"question": question, "dashboard": data}, ensure_ascii=False)[:45000],
                "temperature": 0.2,
            }
            body = json.dumps(payload).encode("utf-8")
            req = Request("https://api.openai.com/v1/responses", data=body, method="POST", headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            })
            with urlopen(req, timeout=35) as res:
                obj = json.loads(res.read().decode("utf-8"))
            if obj.get("output_text"):
                return obj["output_text"].strip()
            chunks = []
            for item in obj.get("output", []):
                for content in item.get("content", []):
                    if content.get("type") in {"output_text", "text"} and content.get("text"):
                        chunks.append(content["text"])
            return "\n".join(chunks).strip() or None
        except Exception:
            return None

    def _read_cache(self, max_age_seconds):
        if not self.cache_file.exists():
            return None
        if max_age_seconds is not None and time.time() - self.cache_file.stat().st_mtime > max_age_seconds:
            return None
        return json.loads(self.cache_file.read_text(encoding="utf-8"))

    def _dedupe(self, tenders):
        seen = set()
        output = []
        for tender in tenders:
            key = (tender.get("tender_id") or tender.get("reference") or tender.get("title", "")[:80]).lower()
            if key in seen:
                continue
            seen.add(key)
            output.append(tender)
        return output

    def _parse_date(self, value):
        if not value:
            return None
        for fmt in ("%d-%b-%Y %I:%M %p", "%d-%b-%Y"):
            try:
                return datetime.strptime(value.strip(), fmt)
            except ValueError:
                pass
        return None

    def _extract_tender_id(self, text):
        match = re.search(r"20\d{2}_[A-Z0-9]+_\d+_\d+", text)
        return match.group(0) if match else ""

    def _extract_org(self, text):
        bits = re.split(r"\|\||Visitor No|Designed", text)
        candidates = [b.strip(" []") for b in bits if len(b.strip()) > 12]
        return candidates[-1][:140] if candidates else "Unknown"

    def _extract_org_after_title(self, window, title):
        tail = window.split(title, 1)[-1]
        tail = re.sub(r"\[[^\]]+\]", " ", tail)
        tail = re.sub(r"\d{2}-[A-Za-z]{3}-\d{4}\s+\d{2}:\d{2}\s+[AP]M", " ", tail)
        tail = " ".join(tail.split())
        return tail[:160] if tail else "Unknown"

    def _sample_dashboard(self, error):
        now = TODAY()
        return {
            "source": {
                "portal": BASE_URL,
                "live": False,
                "last_updated": now.isoformat(timespec="seconds"),
                "warning": f"Live fetch unavailable; sample data is displayed. {error}",
                "notes": ["Install/connect internet and click Refresh for live portal data."],
            },
            "counts": {"total": 3, "open": 2, "in_progress": 1, "upcoming": 0, "closed": 0, "awards": 0, "corrigenda": 0},
            "insights": {
                "headline": "Sample mode: connect to eProcure for live tender intelligence.",
                "closing_soon": [],
                "top_organisation": "Sample Organisation",
                "award_activity": "No live award data in sample mode.",
                "data_gap": "Bidder names require public detail-page visibility.",
                "generated_at": now.strftime("%d-%b-%Y %I:%M %p"),
            },
            "closing_dates": [{"date": "21-May-2026 03:00 PM", "count": 2, "open_count": 2, "titles": ["Sample civil works tender", "Sample supply tender"]}],
            "organisations": [["Sample Organisation", 3]],
            "tenders": [
                {"title": "Sample civil works tender", "reference": "NIT/001", "tender_id": "2026_SAMPLE_1", "published_date": "", "closing_date": "21-May-2026 03:00 PM", "opening_date": "22-May-2026 03:30 PM", "organisation": "Sample Organisation", "category": "Latest Tenders", "status": "Open", "days_to_close": 5, "submitted_bidders": [], "bidder_submission_visibility": "Not available in sample mode", "url": BASE_URL},
                {"title": "Sample maintenance tender", "reference": "NIT/002", "tender_id": "2026_SAMPLE_2", "published_date": "", "closing_date": "23-May-2026 11:00 AM", "opening_date": "25-May-2026 11:30 AM", "organisation": "Sample Organisation", "category": "Closing Date", "status": "Open", "days_to_close": 7, "submitted_bidders": [], "bidder_submission_visibility": "Not available in sample mode", "url": BASE_URL},
                {"title": "Sample bid under evaluation", "reference": "NIT/003", "tender_id": "2026_SAMPLE_3", "published_date": "", "closing_date": "15-May-2026 02:00 PM", "opening_date": "16-May-2026 02:00 PM", "organisation": "Sample Organisation", "category": "Closing Date", "status": "In Progress", "days_to_close": -1, "submitted_bidders": [], "bidder_submission_visibility": "Not available in sample mode", "url": BASE_URL},
            ],
            "awards": [],
        }
