from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse
import json
import mimetypes
import os
import traceback

from tender_service import TenderService


ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
service = TenderService(ROOT)


def load_env():
    env_file = ROOT / ".env"
    if not env_file.exists():
        return
    for line in env_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


class AppHandler(BaseHTTPRequestHandler):
    server_version = "RealEstateTenderIntel/1.0"

    def do_GET(self):
        parsed = urlparse(self.path)
        try:
            if parsed.path == "/":
                self.send_file(ROOT / "templates" / "index.html", "text/html; charset=utf-8")
            elif parsed.path == "/api/tenders":
                refresh = parse_qs(parsed.query).get("refresh", ["0"])[0] == "1"
                self.send_json(service.get_dashboard(refresh=refresh))
            elif parsed.path.startswith("/static/"):
                rel = parsed.path.replace("/static/", "", 1)
                target = (STATIC / rel).resolve()
                if STATIC.resolve() not in target.parents and target != STATIC.resolve():
                    self.send_error(403)
                    return
                self.send_file(target)
            else:
                self.send_error(404)
        except Exception as exc:
            self.send_json({"error": str(exc), "trace": traceback.format_exc()}, status=500)

    def do_POST(self):
        parsed = urlparse(self.path)
        try:
            body = self.rfile.read(int(self.headers.get("content-length", "0") or 0))
            payload = json.loads(body.decode("utf-8") or "{}")
            if parsed.path == "/api/chat":
                question = str(payload.get("question", "")).strip()
                self.send_json(service.answer_question(question))
            elif parsed.path == "/api/refresh":
                self.send_json(service.get_dashboard(refresh=True))
            else:
                self.send_error(404)
        except Exception as exc:
            self.send_json({"error": str(exc), "trace": traceback.format_exc()}, status=500)

    def send_file(self, path, content_type=None):
        if not path.exists() or not path.is_file():
            self.send_error(404)
            return
        content_type = content_type or mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        data = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_json(self, payload, status=200):
        data = json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, fmt, *args):
        print("%s - %s" % (self.address_string(), fmt % args))


if __name__ == "__main__":
    load_env()
    port = int(os.environ.get("PORT", "8080"))
    host = os.environ.get("HOST", "127.0.0.1")
    server = ThreadingHTTPServer((host, port), AppHandler)
    print(f"RealEstate Tender Intelligence running at http://{host}:{port}")
    print("Press Ctrl+C to stop.")
    server.serve_forever()
