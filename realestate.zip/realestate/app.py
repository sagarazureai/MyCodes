from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse
import json
import mimetypes
import os
import re
import traceback

from tender_service import TenderService


ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
service = TenderService(ROOT)


def load_env():
    env_file = ROOT / ".env"
    if not env_file.exists():
        return
    for line in env_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


class AppHandler(BaseHTTPRequestHandler):
    server_version = "RealEstateTenderIntel/1.0"

    def do_GET(self):
        parsed = urlparse(self.path)
        try:
            if parsed.path == "/":
                self.send_file(ROOT / "templates" / "index.html", "text/html; charset=utf-8")
            elif parsed.path == "/api/tenders":
                refresh = parse_qs(parsed.query).get("refresh", ["0"])[0] == "1"
                self.send_json(service.get_dashboard(refresh=refresh))
            elif parsed.path == "/api/documents":
                self.send_json(service.get_documents())
            elif parsed.path.startswith("/static/"):
                rel = parsed.path.replace("/static/", "", 1)
                target = (STATIC / rel).resolve()
                if STATIC.resolve() not in target.parents and target != STATIC.resolve():
                    self.send_error(403)
                    return
                self.send_file(target)
            else:
                self.send_error(404)
        except Exception as exc:
            self.send_json({"error": str(exc), "trace": traceback.format_exc()}, status=500)

    def do_POST(self):
        parsed = urlparse(self.path)
        try:
            body = self.rfile.read(int(self.headers.get("content-length", "0") or 0))
            if parsed.path == "/api/upload":
                filename, content = parse_multipart_upload(self.headers.get("content-type", ""), body)
                if not filename or not content:
                    self.send_json({"error": "No file was uploaded."}, status=400)
                    return
                self.send_json({"document": service.save_upload(filename, content)})
                return

            payload = json.loads(body.decode("utf-8") or "{}")
            if parsed.path == "/api/chat":
                question = str(payload.get("question", "")).strip()
                self.send_json(service.answer_question(question))
            elif parsed.path == "/api/document-chat":
                question = str(payload.get("question", "")).strip()
                scope = str(payload.get("scope", "all")).strip() or "all"
                doc_id = str(payload.get("doc_id", "")).strip()
                self.send_json(service.answer_document_question(question, scope=scope, doc_id=doc_id))
            elif parsed.path == "/api/refresh":
                self.send_json(service.get_dashboard(refresh=True))
            else:
                self.send_error(404)
        except Exception as exc:
            self.send_json({"error": str(exc), "trace": traceback.format_exc()}, status=500)

    def send_file(self, path, content_type=None):
        if not path.exists() or not path.is_file():
            self.send_error(404)
            return
        content_type = content_type or mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        data = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_json(self, payload, status=200):
        data = json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, fmt, *args):
        print("%s - %s" % (self.address_string(), fmt % args))


def parse_multipart_upload(content_type, body):
    match = re.search(r"boundary=(?P<boundary>[^;]+)", content_type or "")
    if not match:
        return "", b""
    boundary = match.group("boundary").strip().strip('"').encode("utf-8")
    for part in body.split(b"--" + boundary):
        if b"Content-Disposition" not in part or b"filename=" not in part:
            continue
        header_blob, _, content = part.partition(b"\r\n\r\n")
        header_text = header_blob.decode("utf-8", errors="ignore")
        file_match = re.search(r'filename="([^"]*)"', header_text)
        filename = file_match.group(1) if file_match else "upload.bin"
        content = content.rstrip(b"\r\n")
        if content.endswith(b"--"):
            content = content[:-2].rstrip(b"\r\n")
        return filename, content
    return "", b""


if __name__ == "__main__":
    load_env()
    port = int(os.environ.get("PORT", "8080"))
    host = os.environ.get("HOST", "127.0.0.1")
    server = ThreadingHTTPServer((host, port), AppHandler)
    print(f"RealEstate Tender Intelligence running at http://{host}:{port}")
    print("Press Ctrl+C to stop.")
    server.serve_forever()
