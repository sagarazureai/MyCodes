# Manufacturing AI agent

A Python web application for autonomous multi-agent orchestration in manufacturing.

## Features
- Modern dashboard UI with a clear left-side hierarchy
- Root orchestrator: **Manufacturing AI agent**
- Sub-agents: **ERP Agent**, **Automated Tasks Agent**, **Upper MES Agent**
- Live "Currently Calling" status while agent calls are executed
- Gemini-powered dynamic planning with fallback deterministic plan
- Built-in dummy manufacturing dataset with processed KPI results, shortages, and recommendations

## Run
1. Create and activate a virtual environment.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Set your Gemini key in `.env` (already wired):
   ```env
   GEMINI_API_KEY=your_key
   ```
4. Start the app:
   ```bash
   python app.py
   ```
5. Open: http://localhost:5000

## Notes
- The orchestrator executes automatically without confirmation prompts.
- If Gemini is unavailable, the app uses an internal manufacturing workflow fallback.
