import os
from typing import Any, Dict

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request

from orchestrator import ManufacturingOrchestrator

load_dotenv()

app = Flask(__name__)


@app.get("/")
def index() -> str:
    return render_template("index.html")


@app.post("/api/orchestrate")
def orchestrate() -> Any:
    payload: Dict[str, Any] = request.get_json(silent=True) or {}
    objective = str(payload.get("objective", "")).strip()

    if not objective:
        return jsonify({"error": "Please provide an objective."}), 400

    orchestrator = ManufacturingOrchestrator(api_key=os.getenv("GEMINI_API_KEY", ""))
    result = orchestrator.run(objective)
    return jsonify(result)


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
