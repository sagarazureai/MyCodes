import json
import hashlib
import re
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List

import requests


@dataclass
class Agent:
    name: str
    description: str


class ManufacturingOrchestrator:
    """Plans and executes multi-agent manufacturing workflows."""

    def __init__(self, api_key: str = "") -> None:
        self.api_key = api_key
        self.model = "gemini-1.5-flash"
        self.agents = [
            Agent(
                name="ERP Agent",
                description="Handles orders, procurement, inventory, and scheduling data.",
            ),
            Agent(
                name="Automated Tasks Agent",
                description="Executes routine automation jobs and task handoffs.",
            ),
            Agent(
                name="Upper MES Agent",
                description="Coordinates production execution, quality, and line status.",
            ),
        ]

    def run(self, objective: str) -> Dict[str, Any]:
        base_data = self._dummy_data()
        scenario = self._build_scenario_from_objective(objective, base_data)
        dummy_data = scenario["data"]
        processed_results = self._process_dummy_data(dummy_data)
        plan = self._build_plan(objective)
        calls = self._execute_plan(plan, processed_results, dummy_data, objective)

        return {
            "title": "Manufacturing AI agent",
            "objective": objective,
            "generated_at": datetime.utcnow().isoformat() + "Z",
            "scenario_applied": scenario["summary"],
            "scenario_rules": scenario["rules"],
            "dummy_data": dummy_data,
            "processed_results": processed_results,
            "plan": plan,
            "calls": calls,
            "insights": self._build_insights(calls),
        }

    def _build_plan(self, objective: str) -> List[Dict[str, str]]:
        ai_plan = self._plan_from_gemini(objective)
        if ai_plan:
            return ai_plan

        return [
            {
                "agent": "ERP Agent",
                "action": "Collect order demand, current inventory, and material constraints.",
            },
            {
                "agent": "Upper MES Agent",
                "action": "Validate line capacity, machine readiness, and shift plan.",
            },
            {
                "agent": "Automated Tasks Agent",
                "action": "Trigger procurement tasks, work-order creation, and alert routing.",
            },
            {
                "agent": "Upper MES Agent",
                "action": "Apply execution schedule and monitor completion milestones.",
            },
        ]

    def _plan_from_gemini(self, objective: str) -> List[Dict[str, str]]:
        if not self.api_key:
            return []

        prompt = (
            "You are orchestrating a manufacturing multi-agent system. "
            "Return only valid JSON as an array of 4 to 7 objects. "
            "Each object must have keys: agent, action. "
            "Allowed agent values: ERP Agent, Automated Tasks Agent, Upper MES Agent. "
            f"Objective: {objective}"
        )

        url = (
            "https://generativelanguage.googleapis.com/v1beta/models/"
            f"{self.model}:generateContent?key={self.api_key}"
        )

        body = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "temperature": 0.3,
                "responseMimeType": "application/json",
            },
        }

        try:
            response = requests.post(url, json=body, timeout=15)
            response.raise_for_status()
            data = response.json()
            text = (
                data.get("candidates", [{}])[0]
                .get("content", {})
                .get("parts", [{}])[0]
                .get("text", "")
            )
            parsed = json.loads(text)
            cleaned: List[Dict[str, str]] = []

            for step in parsed:
                agent = str(step.get("agent", "")).strip()
                action = str(step.get("action", "")).strip()
                if agent in {a.name for a in self.agents} and action:
                    cleaned.append({"agent": agent, "action": action})

            return cleaned
        except (requests.RequestException, ValueError, KeyError, TypeError):
            return []

    def _execute_plan(
        self,
        plan: List[Dict[str, str]],
        processed_results: Dict[str, Any],
        dummy_data: Dict[str, Any],
        objective: str,
    ) -> List[Dict[str, str]]:
        calls: List[Dict[str, str]] = []
        shortage_count = len(processed_results["shortages"])
        auto_tasks = len(processed_results["recommended_actions"])
        bottleneck_line = processed_results["line_utilization"][0]["line"]
        task_queue: List[Dict[str, str]] = []

        for idx, step in enumerate(plan, start=1):
            result_summary = "Step executed."
            input_snapshot: Dict[str, Any] = {}
            output_snapshot: Dict[str, Any] = {}

            if step["agent"] == "ERP Agent":
                result_summary = (
                    f"Validated demand and inventory. Material shortages: {shortage_count}."
                )
                input_snapshot = {
                    "objective": objective,
                    "orders": dummy_data["orders"],
                    "inventory": dummy_data["inventory"],
                }
                output_snapshot = {
                    "demand_by_sku": processed_results["demand_by_sku"],
                    "material_requirements": processed_results["material_requirements"],
                    "shortages": processed_results["shortages"],
                }
            elif step["agent"] == "Automated Tasks Agent":
                task_queue = [
                    {"task": "Create purchase requisitions", "owner": "Procurement Bot"},
                    {"task": "Generate work-order updates", "owner": "Planning Bot"},
                    {"task": "Publish alert notifications", "owner": "Comms Bot"},
                ]
                result_summary = (
                    f"Created {auto_tasks} automation tasks for purchasing and scheduling."
                )
                input_snapshot = {
                    "shortages": processed_results["shortages"],
                    "recommended_actions": processed_results["recommended_actions"],
                    "bottleneck_line": bottleneck_line,
                }
                output_snapshot = {
                    "task_queue": task_queue,
                    "automation_summary": {
                        "tasks_created": len(task_queue),
                        "execution_mode": "autonomous",
                    },
                }
            elif step["agent"] == "Upper MES Agent":
                result_summary = f"Prioritized bottleneck line: {bottleneck_line}."
                input_snapshot = {
                    "line_capacity_per_shift": dummy_data["line_capacity_per_shift"],
                    "line_utilization": processed_results["line_utilization"],
                    "upstream_task_queue": task_queue,
                }
                output_snapshot = {
                    "dispatch_plan": {
                        "bottleneck_line": bottleneck_line,
                        "priority_orders": [
                            order["id"]
                            for order in sorted(
                                dummy_data["orders"],
                                key=lambda item: (item["priority"] != "high", -item["qty"]),
                            )[:2]
                        ],
                    },
                    "line_watchlist": processed_results["line_utilization"][:2],
                }

            calls.append(
                {
                    "id": f"CALL-{idx:03d}",
                    "agent": step["agent"],
                    "action": step["action"],
                    "result": result_summary,
                    "input_snapshot": input_snapshot,
                    "output_snapshot": output_snapshot,
                    "status": "completed",
                    "timestamp": datetime.utcnow().isoformat() + "Z",
                }
            )

        return calls

    def _build_insights(self, calls: List[Dict[str, str]]) -> Dict[str, Any]:
        by_agent: Dict[str, int] = {}
        for call in calls:
            by_agent[call["agent"]] = by_agent.get(call["agent"], 0) + 1

        return {
            "total_calls": len(calls),
            "calls_by_agent": by_agent,
            "automation_mode": "autonomous",
        }

    def _dummy_data(self) -> Dict[str, Any]:
        return {
            "orders": [
                {"id": "SO-1001", "sku": "Motor-X1", "qty": 180, "priority": "high"},
                {"id": "SO-1002", "sku": "Pump-Z9", "qty": 120, "priority": "medium"},
                {"id": "SO-1003", "sku": "Valve-Q2", "qty": 240, "priority": "high"},
            ],
            "inventory": {
                "Steel": 880,
                "Copper": 330,
                "SealKit": 290,
                "ControllerBoard": 170,
            },
            "bom": {
                "Motor-X1": {"Steel": 3, "Copper": 1, "ControllerBoard": 1},
                "Pump-Z9": {"Steel": 2, "SealKit": 2, "Copper": 1},
                "Valve-Q2": {"Steel": 1, "SealKit": 1},
            },
            "line_capacity_per_shift": {
                "Line-1": {"capacity": 190, "uptime_pct": 87},
                "Line-2": {"capacity": 210, "uptime_pct": 79},
                "Line-3": {"capacity": 175, "uptime_pct": 92},
            },
            "sku_to_line": {
                "Motor-X1": "Line-1",
                "Pump-Z9": "Line-2",
                "Valve-Q2": "Line-3",
            },
        }

    def _build_scenario_from_objective(
        self, objective: str, base_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Applies deterministic objective-driven adjustments so results change
        per user question while keeping the app runnable without external systems.
        """
        text = objective.lower()
        data = deepcopy(base_data)
        rules: List[str] = []

        demand_factor = 1.0
        inventory_factor = 1.0
        capacity_factor = 1.0

        # Objective fingerprint ensures different free-form questions produce
        # different scenario parameters, even when no explicit keyword matches.
        objective_hash = hashlib.sha256(objective.strip().encode("utf-8")).hexdigest()
        hash_window = int(objective_hash[:8], 16)
        signed_shift = ((hash_window % 31) - 15) / 100  # [-0.15, +0.15]
        demand_factor += signed_shift * 0.7
        inventory_factor -= signed_shift * 0.45
        capacity_factor += signed_shift * 0.35
        rules.append(
            "Objective fingerprint applied for non-keyword variance in demand/inventory/capacity."
        )

        if any(word in text for word in ["expedite", "urgent", "rush", "asap", "fast"]):
            demand_factor += 0.18
            capacity_factor -= 0.08
            rules.append("Rush objective detected: demand up, effective capacity down.")

        if any(word in text for word in ["minimize shortage", "avoid shortage", "no shortage"]):
            inventory_factor += 0.12
            rules.append("Shortage-avoidance intent detected: inventory buffer increased.")

        if any(word in text for word in ["maintenance", "breakdown", "downtime"]):
            capacity_factor -= 0.15
            rules.append("Maintenance/downtime context detected: capacity reduced.")

        if any(word in text for word in ["optimize cost", "reduce cost", "cost down"]):
            inventory_factor -= 0.08
            rules.append("Cost optimization intent detected: leaner inventory applied.")

        if any(word in text for word in ["overtime", "extra shift", "additional shift"]):
            capacity_factor += 0.14
            rules.append("Overtime intent detected: effective capacity increased.")

        line_match = re.search(r"line[\s\-]?([123])", text)
        if line_match:
            target_line = f"Line-{line_match.group(1)}"
            for line, cfg in data["line_capacity_per_shift"].items():
                if line == target_line:
                    cfg["uptime_pct"] = min(98, cfg["uptime_pct"] + 6)
                else:
                    cfg["uptime_pct"] = max(65, cfg["uptime_pct"] - 3)
            rules.append(f"Line targeting detected: prioritized {target_line} uptime.")

        percent_match = re.search(r"(\d{1,2})\s*%", text)
        if percent_match:
            pct = int(percent_match.group(1))
            demand_factor += min(0.35, pct / 100)
            rules.append(f"Percentage target detected: demand scaled by +{pct}%.")

        unit_match = re.search(r"(\d{2,4})\s*(units|pieces|qty|quantity)?", text)
        if unit_match:
            extra_units = int(unit_match.group(1))
            first_order = data["orders"][0]
            first_order["qty"] += min(260, extra_units // 4)
            rules.append(f"Numeric target detected: boosted {first_order['sku']} demand.")

        if "motor" in text:
            data["orders"][0]["qty"] += 70
            rules.append("Motor demand intent detected: Motor-X1 demand increased.")
        if "pump" in text:
            data["orders"][1]["qty"] += 70
            rules.append("Pump demand intent detected: Pump-Z9 demand increased.")
        if "valve" in text:
            data["orders"][2]["qty"] += 70
            rules.append("Valve demand intent detected: Valve-Q2 demand increased.")

        demand_factor = min(1.55, max(0.70, demand_factor))
        inventory_factor = min(1.45, max(0.65, inventory_factor))
        capacity_factor = min(1.35, max(0.65, capacity_factor))

        self._scale_order_demand(data, demand_factor)
        self._scale_inventory(data, inventory_factor)
        self._scale_capacity(data, capacity_factor)

        if not rules:
            rules.append("No strong scenario keywords detected: baseline manufacturing case used.")

        summary = (
            f"Scenario factors -> demand x{demand_factor:.2f}, "
            f"inventory x{inventory_factor:.2f}, capacity x{capacity_factor:.2f}"
        )

        return {"data": data, "summary": summary, "rules": rules}

    def _scale_order_demand(self, data: Dict[str, Any], factor: float) -> None:
        for order in data["orders"]:
            order["qty"] = max(10, int(round(order["qty"] * factor)))

    def _scale_inventory(self, data: Dict[str, Any], factor: float) -> None:
        for material in data["inventory"]:
            data["inventory"][material] = max(20, int(round(data["inventory"][material] * factor)))

    def _scale_capacity(self, data: Dict[str, Any], factor: float) -> None:
        for line_cfg in data["line_capacity_per_shift"].values():
            line_cfg["capacity"] = max(60, int(round(line_cfg["capacity"] * factor)))

    def _process_dummy_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        demand_by_sku: Dict[str, int] = {}
        for order in data["orders"]:
            sku = order["sku"]
            demand_by_sku[sku] = demand_by_sku.get(sku, 0) + int(order["qty"])

        material_requirements: Dict[str, int] = {}
        for sku, demand in demand_by_sku.items():
            bom_items = data["bom"].get(sku, {})
            for material, units_per_product in bom_items.items():
                material_requirements[material] = material_requirements.get(material, 0) + (
                    demand * units_per_product
                )

        shortages: List[Dict[str, Any]] = []
        for material, required in material_requirements.items():
            available = int(data["inventory"].get(material, 0))
            gap = required - available
            if gap > 0:
                shortages.append(
                    {"material": material, "required": required, "available": available, "gap": gap}
                )

        line_load_map: Dict[str, int] = {}
        for sku, demand in demand_by_sku.items():
            line = data["sku_to_line"].get(sku, "Unassigned")
            line_load_map[line] = line_load_map.get(line, 0) + demand

        line_utilization: List[Dict[str, Any]] = []
        for line, cfg in data["line_capacity_per_shift"].items():
            effective_capacity = int(cfg["capacity"] * (cfg["uptime_pct"] / 100))
            load = line_load_map.get(line, 0)
            utilization = round((load / effective_capacity) * 100, 1) if effective_capacity else 0.0
            line_utilization.append(
                {
                    "line": line,
                    "demand_units": load,
                    "effective_capacity": effective_capacity,
                    "utilization_pct": utilization,
                }
            )

        line_utilization.sort(key=lambda item: item["utilization_pct"], reverse=True)

        recommendations: List[str] = []
        if shortages:
            top = sorted(shortages, key=lambda item: item["gap"], reverse=True)[0]
            recommendations.append(
                f"Raise urgent PO for {top['material']} to cover shortage of {top['gap']} units."
            )
        overloaded = [line for line in line_utilization if line["utilization_pct"] > 100]
        if overloaded:
            recommendations.append(
                f"Resequence orders from {overloaded[0]['line']} or add overtime to avoid delay."
            )
        if not recommendations:
            recommendations.append("No critical constraints detected. Proceed with current plan.")

        total_required = sum(material_requirements.values())
        total_available = sum(int(v) for v in data["inventory"].values())
        supply_coverage = round((total_available / total_required) * 100, 1) if total_required else 100.0

        return {
            "demand_by_sku": demand_by_sku,
            "material_requirements": material_requirements,
            "shortages": shortages,
            "line_utilization": line_utilization,
            "kpis": {
                "total_orders": len(data["orders"]),
                "total_units_planned": sum(demand_by_sku.values()),
                "materials_short": len(shortages),
                "supply_coverage_pct": supply_coverage,
            },
            "recommended_actions": recommendations,
        }
