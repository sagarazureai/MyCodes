Technology Demand Analyzer

How to start:
1. Double-click Start_Tech_Demand_Analyzer.bat.
2. Your browser will open the app automatically.
3. Upload a CSV or XLSX file, ask a question, and click Analyze.

What it does:
- Reads CSV and modern XLSX files locally in the browser.
- Finds high-demand technologies from skills, role, title, description, and technology columns.
- Uses openings/count columns as demand weight when present.
- Shows bar, share, and trend visuals.
- Shows the uploaded data in a table and can export the current table to CSV.
- Uses the provided Gemini API key only when "Use AI summary" is checked. Local analysis still works without internet.

Best file columns:
- Role or Job Title
- Skills or Technologies
- Location
- Openings or Count
- Posted Date or Month

No installation is required. The launcher uses Windows PowerShell, which is included with Windows.
