const GEMINI_API_KEY = "AIzaSyDCV1gsSIxZKiNZItPY5KLcaatRpO8LPzQ";

const TECH_LIBRARY = [
  ["JavaScript", "javascript", "js", "node.js", "nodejs", "react", "angular", "vue"],
  ["Python", "python", "django", "flask", "fastapi", "pandas", "numpy"],
  ["Java", "java", "spring", "spring boot", "hibernate"],
  ["SQL", "sql", "mysql", "postgresql", "postgres", "oracle", "sql server", "pl/sql"],
  ["AWS", "aws", "amazon web services", "ec2", "s3", "lambda", "cloudformation"],
  ["Azure", "azure", "microsoft azure", "aks", "adf"],
  ["Google Cloud", "gcp", "google cloud", "bigquery", "cloud run"],
  ["DevOps", "devops", "ci/cd", "jenkins", "github actions", "gitlab ci"],
  ["Docker", "docker", "container", "containers"],
  ["Kubernetes", "kubernetes", "k8s", "helm"],
  ["Data Engineering", "data engineering", "etl", "spark", "hadoop", "databricks", "airflow"],
  ["Machine Learning", "machine learning", "ml", "deep learning", "tensorflow", "pytorch", "scikit"],
  ["Generative AI", "generative ai", "genai", "llm", "large language model", "prompt engineering"],
  ["Power BI", "power bi", "powerbi", "dax"],
  ["Tableau", "tableau"],
  ["Excel", "excel", "vlookup", "pivot"],
  ["Salesforce", "salesforce", "apex", "lightning"],
  ["SAP", "sap", "abap", "hana"],
  ["Cybersecurity", "cybersecurity", "security", "soc", "siem", "iam"],
  ["Testing", "testing", "qa", "selenium", "cypress", "playwright"],
  ["C#", "c#", ".net", "dotnet", "asp.net"],
  ["C++", "c++", "cpp"],
  ["PHP", "php", "laravel"],
  ["Mobile", "android", "ios", "flutter", "react native", "kotlin", "swift"]
];

const state = {
  fileName: "",
  rows: [],
  headers: [],
  analysis: null,
  filteredRows: [],
  view: "insights"
};

const els = {
  fileInput: document.getElementById("fileInput"),
  dropzone: document.getElementById("dropzone"),
  fileStatus: document.getElementById("fileStatus"),
  queryInput: document.getElementById("queryInput"),
  analyzeBtn: document.getElementById("analyzeBtn"),
  sampleBtn: document.getElementById("sampleBtn"),
  chartType: document.getElementById("chartType"),
  aiToggle: document.getElementById("aiToggle"),
  rowsShown: document.getElementById("rowsShown"),
  rowCount: document.getElementById("rowCount"),
  columnCount: document.getElementById("columnCount"),
  techCount: document.getElementById("techCount"),
  topTech: document.getElementById("topTech"),
  chartTitle: document.getElementById("chartTitle"),
  chartCanvas: document.getElementById("chartCanvas"),
  aiInsight: document.getElementById("aiInsight"),
  insightList: document.getElementById("insightList"),
  dataTable: document.getElementById("dataTable"),
  downloadBtn: document.getElementById("downloadBtn"),
  insightsTab: document.getElementById("insightsTab"),
  dataTab: document.getElementById("dataTab"),
  insightsView: document.getElementById("insightsView"),
  dataView: document.getElementById("dataView")
};

els.fileInput.addEventListener("change", event => {
  const file = event.target.files[0];
  if (file) loadFile(file);
});

["dragenter", "dragover"].forEach(name => {
  els.dropzone.addEventListener(name, event => {
    event.preventDefault();
    els.dropzone.classList.add("dragging");
  });
});

["dragleave", "drop"].forEach(name => {
  els.dropzone.addEventListener(name, event => {
    event.preventDefault();
    els.dropzone.classList.remove("dragging");
  });
});

els.dropzone.addEventListener("drop", event => {
  const file = event.dataTransfer.files[0];
  if (file) loadFile(file);
});

els.analyzeBtn.addEventListener("click", () => runAnalysis());
els.sampleBtn.addEventListener("click", loadSample);
els.chartType.addEventListener("change", () => renderAll());
els.rowsShown.addEventListener("input", () => renderTable());
els.downloadBtn.addEventListener("click", downloadCurrentTable);
els.insightsTab.addEventListener("click", () => setView("insights"));
els.dataTab.addEventListener("click", () => setView("data"));

function setView(view) {
  state.view = view;
  els.insightsTab.classList.toggle("active", view === "insights");
  els.dataTab.classList.toggle("active", view === "data");
  els.insightsView.classList.toggle("hidden", view !== "insights");
  els.dataView.classList.toggle("hidden", view !== "data");
}

async function loadFile(file) {
  els.fileStatus.textContent = `Loading ${file.name}`;
  try {
    const extension = file.name.toLowerCase().split(".").pop();
    let parsed;
    if (extension === "csv") {
      parsed = parseCsv(await file.text());
    } else if (extension === "xlsx" || extension === "xls") {
      if (extension === "xls") {
        throw new Error("Older .xls files are not supported without external dependencies. Please save the file as .xlsx or CSV.");
      }
      parsed = await parseXlsx(await file.arrayBuffer());
    } else {
      throw new Error("Please upload a CSV or Excel file.");
    }

    state.fileName = file.name;
    state.headers = parsed.headers;
    state.rows = parsed.rows;
    state.filteredRows = parsed.rows;
    els.fileStatus.textContent = file.name;
    els.queryInput.value = els.queryInput.value || "Show the top technologies in demand as a bar chart";
    runAnalysis();
  } catch (error) {
    showError(error.message);
  }
}

function loadSample() {
  const csv = `Role,Location,Skills,Openings,Posted Date,Experience
Data Engineer,Bangalore,"Python, SQL, Spark, AWS, Airflow",48,2026-01-12,4-7 years
Frontend Developer,Pune,"JavaScript, React, TypeScript, CSS",34,2026-02-08,2-5 years
Cloud DevOps Engineer,Hyderabad,"AWS, Kubernetes, Docker, Jenkins",42,2026-02-18,5-8 years
AI Engineer,Bangalore,"Python, Generative AI, LLM, Azure",31,2026-03-02,3-6 years
BI Analyst,Chennai,"Power BI, SQL, Excel, Tableau",29,2026-03-18,2-4 years
Security Analyst,Delhi,"Cybersecurity, SIEM, IAM, Python",22,2026-04-03,3-5 years
Backend Developer,Mumbai,"Java, Spring Boot, SQL, Docker",39,2026-04-10,4-7 years
Salesforce Developer,Remote,"Salesforce, Apex, JavaScript",18,2026-04-19,2-5 years`;
  const parsed = parseCsv(csv);
  state.fileName = "sample-demand-data.csv";
  state.headers = parsed.headers;
  state.rows = parsed.rows;
  state.filteredRows = parsed.rows;
  els.fileStatus.textContent = state.fileName;
  els.queryInput.value = "Show top technologies in Bangalore as a bar chart";
  runAnalysis();
}

function parseCsv(text) {
  const rows = [];
  let row = [];
  let value = "";
  let quoted = false;

  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];
    if (char === '"' && quoted && next === '"') {
      value += '"';
      index += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === "," && !quoted) {
      row.push(value.trim());
      value = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && next === "\n") index += 1;
      row.push(value.trim());
      if (row.some(cell => cell !== "")) rows.push(row);
      row = [];
      value = "";
    } else {
      value += char;
    }
  }
  row.push(value.trim());
  if (row.some(cell => cell !== "")) rows.push(row);

  if (!rows.length) return { headers: [], rows: [] };
  const headers = makeUniqueHeaders(rows[0].map((cell, index) => cell || `Column ${index + 1}`));
  const dataRows = rows.slice(1).map(cells => rowFromCells(headers, cells));
  return { headers, rows: dataRows };
}

async function parseXlsx(buffer) {
  const files = await unzipXlsx(buffer);
  const workbookXml = getTextFile(files, "xl/workbook.xml");
  const relsXml = getTextFile(files, "xl/_rels/workbook.xml.rels");
  const sharedXml = getTextFile(files, "xl/sharedStrings.xml", true);
  const sheetPath = firstWorksheetPath(workbookXml, relsXml);
  const sheetXml = getTextFile(files, sheetPath);
  const sharedStrings = sharedXml ? parseSharedStrings(sharedXml) : [];
  return parseWorksheet(sheetXml, sharedStrings);
}

async function unzipXlsx(buffer) {
  if (!("DecompressionStream" in window)) {
    throw new Error("This browser cannot unpack Excel files. Please use Microsoft Edge or Google Chrome, or upload CSV.");
  }
  const view = new DataView(buffer);
  const files = new Map();
  let offset = 0;

  while (offset < view.byteLength - 30) {
    const signature = view.getUint32(offset, true);
    if (signature !== 0x04034b50) {
      offset += 1;
      continue;
    }

    const flags = view.getUint16(offset + 6, true);
    const method = view.getUint16(offset + 8, true);
    const compressedSize = view.getUint32(offset + 18, true);
    const fileNameLength = view.getUint16(offset + 26, true);
    const extraLength = view.getUint16(offset + 28, true);
    const nameBytes = new Uint8Array(buffer, offset + 30, fileNameLength);
    const name = new TextDecoder().decode(nameBytes).replace(/\\/g, "/");
    const dataStart = offset + 30 + fileNameLength + extraLength;

    if (flags & 0x08) {
      throw new Error("This Excel file uses a streaming ZIP format this simple app cannot read. Save it again as .xlsx or export to CSV.");
    }

    const compressed = buffer.slice(dataStart, dataStart + compressedSize);
    let bytes;
    if (method === 0) {
      bytes = new Uint8Array(compressed);
    } else if (method === 8) {
      bytes = await inflateRaw(compressed);
    } else {
      throw new Error(`Unsupported Excel compression method: ${method}`);
    }
    files.set(name, new TextDecoder("utf-8").decode(bytes));
    offset = dataStart + compressedSize;
  }

  if (!files.size) throw new Error("Could not read the Excel workbook.");
  return files;
}

async function inflateRaw(buffer) {
  const stream = new Blob([buffer]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

function getTextFile(files, path, optional = false) {
  const value = files.get(path);
  if (!value && !optional) throw new Error(`Missing ${path} inside the workbook.`);
  return value;
}

function firstWorksheetPath(workbookXml, relsXml) {
  const workbook = parseXml(workbookXml);
  const rels = parseXml(relsXml);
  const firstSheet = workbook.querySelector("sheet");
  if (!firstSheet) throw new Error("The workbook does not contain a worksheet.");
  const relId = firstSheet.getAttribute("r:id") || firstSheet.getAttribute("id");
  const relation = Array.from(rels.querySelectorAll("Relationship")).find(item => item.getAttribute("Id") === relId);
  const target = relation ? relation.getAttribute("Target") : "worksheets/sheet1.xml";
  return target.startsWith("xl/") ? target : `xl/${target.replace(/^\/xl\//, "")}`;
}

function parseSharedStrings(xmlText) {
  const xml = parseXml(xmlText);
  return Array.from(xml.querySelectorAll("si")).map(item => {
    const parts = Array.from(item.querySelectorAll("t")).map(textNode => textNode.textContent || "");
    return parts.join("");
  });
}

function parseWorksheet(xmlText, sharedStrings) {
  const xml = parseXml(xmlText);
  const rows = Array.from(xml.querySelectorAll("sheetData row")).map(rowNode => {
    const cells = [];
    Array.from(rowNode.querySelectorAll("c")).forEach(cell => {
      const ref = cell.getAttribute("r") || "";
      const columnIndex = columnNameToIndex(ref.replace(/[0-9]/g, ""));
      cells[columnIndex] = cellValue(cell, sharedStrings);
    });
    return cells;
  });

  if (!rows.length) return { headers: [], rows: [] };
  const headers = makeUniqueHeaders(rows[0].map((cell, index) => String(cell || `Column ${index + 1}`)));
  const dataRows = rows.slice(1).map(cells => rowFromCells(headers, cells));
  return { headers, rows: dataRows };
}

function parseXml(text) {
  const xml = new DOMParser().parseFromString(text, "application/xml");
  if (xml.querySelector("parsererror")) throw new Error("Unable to parse workbook XML.");
  return xml;
}

function columnNameToIndex(name) {
  if (!name) return 0;
  return name.split("").reduce((sum, char) => sum * 26 + char.charCodeAt(0) - 64, 0) - 1;
}

function cellValue(cell, sharedStrings) {
  const type = cell.getAttribute("t");
  const valueNode = cell.querySelector("v");
  const inlineNode = cell.querySelector("is t");
  const raw = valueNode ? valueNode.textContent : inlineNode ? inlineNode.textContent : "";
  if (type === "s") return sharedStrings[Number(raw)] || "";
  if (type === "b") return raw === "1" ? "TRUE" : "FALSE";
  return raw || "";
}

function makeUniqueHeaders(headers) {
  const counts = {};
  return headers.map(header => {
    const clean = String(header || "Column").trim();
    counts[clean] = (counts[clean] || 0) + 1;
    return counts[clean] === 1 ? clean : `${clean} ${counts[clean]}`;
  });
}

function rowFromCells(headers, cells) {
  const row = {};
  headers.forEach((header, index) => {
    row[header] = cells[index] == null ? "" : String(cells[index]);
  });
  return row;
}

async function runAnalysis() {
  if (!state.rows.length) {
    loadSample();
    return;
  }

  const query = els.queryInput.value.trim();
  const filter = filterRowsForQuery(state.rows, query);
  state.filteredRows = filter.rows;
  state.analysis = analyzeRows(state.filteredRows, query);
  updateMetrics();
  renderAll();
  await enrichWithAi(query, state.analysis);
}

function filterRowsForQuery(rows, query) {
  const lower = query.toLowerCase();
  const locations = uniqueValuesByLikelyColumn(rows, ["location", "city", "place", "country"]);
  const matchedLocation = locations.find(location => lower.includes(String(location).toLowerCase()));
  if (!matchedLocation) return { rows };
  return {
    rows: rows.filter(row => Object.values(row).some(value => String(value).toLowerCase().includes(String(matchedLocation).toLowerCase())))
  };
}

function uniqueValuesByLikelyColumn(rows, names) {
  const headers = Object.keys(rows[0] || {});
  const column = headers.find(header => names.some(name => header.toLowerCase().includes(name)));
  if (!column) return [];
  return Array.from(new Set(rows.map(row => row[column]).filter(Boolean))).slice(0, 200);
}

function analyzeRows(rows, query) {
  const textColumns = likelyTextColumns(rows);
  const demandColumn = likelyDemandColumn(rows);
  const dateColumn = likelyDateColumn(rows);
  const counts = new Map();
  const examples = new Map();
  const trend = new Map();

  rows.forEach(row => {
    const rowText = textColumns.map(column => row[column]).join(" ").toLowerCase();
    const weight = demandColumn ? Math.max(1, Number(String(row[demandColumn]).replace(/[^0-9.]/g, "")) || 1) : 1;
    const month = dateColumn ? normalizeMonth(row[dateColumn]) : "All rows";

    TECH_LIBRARY.forEach(([name, ...terms]) => {
      const found = terms.some(term => termMatch(rowText, term));
      if (!found) return;
      counts.set(name, (counts.get(name) || 0) + weight);
      if (!examples.has(name)) examples.set(name, row);
      if (!trend.has(name)) trend.set(name, new Map());
      trend.get(name).set(month, (trend.get(name).get(month) || 0) + weight);
    });
  });

  const topTech = Array.from(counts, ([name, count]) => ({ name, count, example: examples.get(name) }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 12);

  const locations = topValues(rows, ["location", "city", "place", "country"], 6);
  const roles = topValues(rows, ["role", "title", "position", "job"], 6);
  const months = Array.from(new Set(Array.from(trend.values()).flatMap(map => Array.from(map.keys())))).sort();

  return { topTech, locations, roles, trend, months, query, totalRows: rows.length };
}

function likelyTextColumns(rows) {
  const headers = Object.keys(rows[0] || {});
  const preferred = ["skill", "technology", "tech", "description", "role", "title", "summary", "requirement"];
  const matches = headers.filter(header => preferred.some(name => header.toLowerCase().includes(name)));
  return matches.length ? matches : headers;
}

function likelyDemandColumn(rows) {
  const headers = Object.keys(rows[0] || {});
  return headers.find(header => /opening|count|demand|vacanc|jobs|positions/i.test(header));
}

function likelyDateColumn(rows) {
  const headers = Object.keys(rows[0] || {});
  return headers.find(header => /date|posted|month|created/i.test(header));
}

function termMatch(text, term) {
  const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`(^|[^a-z0-9+#.])${escaped}([^a-z0-9+#.]|$)`, "i").test(text);
}

function normalizeMonth(value) {
  const numeric = Number(value);
  if (numeric > 20000 && numeric < 80000) {
    const excelDate = new Date(Date.UTC(1899, 11, 30 + numeric));
    return `${excelDate.getUTCFullYear()}-${String(excelDate.getUTCMonth() + 1).padStart(2, "0")}`;
  }
  const date = new Date(value);
  if (!Number.isNaN(date.getTime())) return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
  const text = String(value || "").trim();
  return text || "Unknown";
}

function topValues(rows, likelyNames, limit) {
  const headers = Object.keys(rows[0] || {});
  const column = headers.find(header => likelyNames.some(name => header.toLowerCase().includes(name)));
  if (!column) return [];
  const counts = new Map();
  rows.forEach(row => {
    const value = row[column];
    if (value) counts.set(value, (counts.get(value) || 0) + 1);
  });
  return Array.from(counts, ([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count).slice(0, limit);
}

function updateMetrics() {
  const analysis = state.analysis || { topTech: [] };
  els.rowCount.textContent = state.filteredRows.length.toLocaleString();
  els.columnCount.textContent = state.headers.length.toLocaleString();
  els.techCount.textContent = analysis.topTech.length.toLocaleString();
  els.topTech.textContent = analysis.topTech[0]?.name || "-";
}

function renderAll() {
  renderChart();
  renderInsights();
  renderTable();
}

function renderChart() {
  const canvas = els.chartCanvas;
  const ctx = canvas.getContext("2d");
  const width = canvas.width;
  const height = canvas.height;
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = "#fbfcfe";
  ctx.fillRect(0, 0, width, height);

  const analysis = state.analysis;
  if (!analysis || !analysis.topTech.length) {
    drawEmpty(ctx, width, height, "No recognizable technologies found yet.");
    els.chartTitle.textContent = "No technology demand found";
    return;
  }

  const requestedType = queryChartType(analysis.query) || els.chartType.value;
  els.chartType.value = requestedType;
  els.chartTitle.textContent = chartTitle(requestedType, analysis.query);

  if (requestedType === "pie") drawPie(ctx, width, height, analysis.topTech.slice(0, 8));
  else if (requestedType === "line") drawLine(ctx, width, height, analysis);
  else drawBar(ctx, width, height, analysis.topTech.slice(0, 10));
}

function queryChartType(query) {
  const lower = query.toLowerCase();
  if (lower.includes("pie") || lower.includes("share")) return "pie";
  if (lower.includes("trend") || lower.includes("line") || lower.includes("month")) return "line";
  if (lower.includes("bar") || lower.includes("top")) return "bar";
  return "";
}

function chartTitle(type, query) {
  if (type === "pie") return "Technology demand share";
  if (type === "line") return "Technology demand trend";
  return query ? "Top technologies for your query" : "Top technologies in demand";
}

function drawEmpty(ctx, width, height, message) {
  ctx.fillStyle = "#667085";
  ctx.font = "24px Arial";
  ctx.textAlign = "center";
  ctx.fillText(message, width / 2, height / 2);
}

function drawBar(ctx, width, height, data) {
  const margin = { top: 28, right: 26, bottom: 120, left: 72 };
  const chartWidth = width - margin.left - margin.right;
  const chartHeight = height - margin.top - margin.bottom;
  const max = Math.max(...data.map(item => item.count));
  const barWidth = chartWidth / data.length - 14;
  const colors = ["#2f67d8", "#0f7b63", "#c7444a", "#a87309", "#6f4cc3", "#18869a", "#d15f2f", "#3d7a40"];

  drawAxis(ctx, margin, width, height);
  data.forEach((item, index) => {
    const x = margin.left + index * (chartWidth / data.length) + 7;
    const barHeight = (item.count / max) * chartHeight;
    const y = margin.top + chartHeight - barHeight;
    ctx.fillStyle = colors[index % colors.length];
    ctx.fillRect(x, y, barWidth, barHeight);
    ctx.fillStyle = "#17202a";
    ctx.font = "18px Arial";
    ctx.textAlign = "center";
    ctx.fillText(Math.round(item.count), x + barWidth / 2, y - 8);
    drawRotatedLabel(ctx, item.name, x + barWidth / 2, height - 94);
  });
}

function drawAxis(ctx, margin, width, height) {
  ctx.strokeStyle = "#cfd8e3";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(margin.left, margin.top);
  ctx.lineTo(margin.left, height - margin.bottom);
  ctx.lineTo(width - margin.right, height - margin.bottom);
  ctx.stroke();
}

function drawRotatedLabel(ctx, text, x, y) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(-Math.PI / 5);
  ctx.fillStyle = "#344054";
  ctx.font = "16px Arial";
  ctx.textAlign = "right";
  ctx.fillText(text, 0, 0);
  ctx.restore();
}

function drawPie(ctx, width, height, data) {
  const total = data.reduce((sum, item) => sum + item.count, 0);
  const cx = width * 0.34;
  const cy = height * 0.5;
  const radius = Math.min(width, height) * 0.32;
  const colors = ["#2f67d8", "#0f7b63", "#c7444a", "#a87309", "#6f4cc3", "#18869a", "#d15f2f", "#3d7a40"];
  let angle = -Math.PI / 2;

  data.forEach((item, index) => {
    const slice = (item.count / total) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, radius, angle, angle + slice);
    ctx.closePath();
    ctx.fillStyle = colors[index % colors.length];
    ctx.fill();
    angle += slice;
  });

  data.forEach((item, index) => {
    const y = 90 + index * 42;
    ctx.fillStyle = colors[index % colors.length];
    ctx.fillRect(width * 0.62, y - 18, 24, 24);
    ctx.fillStyle = "#17202a";
    ctx.font = "19px Arial";
    ctx.textAlign = "left";
    ctx.fillText(`${item.name} - ${Math.round((item.count / total) * 100)}%`, width * 0.62 + 36, y);
  });
}

function drawLine(ctx, width, height, analysis) {
  const data = analysis.topTech.slice(0, 5);
  const months = analysis.months.length > 1 ? analysis.months : ["All rows"];
  const margin = { top: 32, right: 180, bottom: 74, left: 72 };
  const chartWidth = width - margin.left - margin.right;
  const chartHeight = height - margin.top - margin.bottom;
  const max = Math.max(1, ...data.flatMap(item => months.map(month => analysis.trend.get(item.name)?.get(month) || 0)));
  const colors = ["#2f67d8", "#0f7b63", "#c7444a", "#a87309", "#6f4cc3"];

  drawAxis(ctx, margin, width, height);
  months.forEach((month, index) => {
    const x = margin.left + (months.length === 1 ? chartWidth / 2 : (index / (months.length - 1)) * chartWidth);
    ctx.fillStyle = "#344054";
    ctx.font = "15px Arial";
    ctx.textAlign = "center";
    ctx.fillText(month, x, height - 36);
  });

  data.forEach((tech, techIndex) => {
    ctx.strokeStyle = colors[techIndex];
    ctx.lineWidth = 4;
    ctx.beginPath();
    months.forEach((month, index) => {
      const value = analysis.trend.get(tech.name)?.get(month) || 0;
      const x = margin.left + (months.length === 1 ? chartWidth / 2 : (index / (months.length - 1)) * chartWidth);
      const y = margin.top + chartHeight - (value / max) * chartHeight;
      if (index === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();
    ctx.fillStyle = colors[techIndex];
    ctx.fillRect(width - 150, 62 + techIndex * 34, 20, 20);
    ctx.fillStyle = "#17202a";
    ctx.font = "17px Arial";
    ctx.textAlign = "left";
    ctx.fillText(tech.name, width - 122, 79 + techIndex * 34);
  });
}

function renderInsights() {
  const analysis = state.analysis;
  if (!analysis) return;
  const top = analysis.topTech.slice(0, 5).map(item => `${item.name} (${Math.round(item.count)})`).join(", ");
  els.aiInsight.textContent = top
    ? `Top demand signals found: ${top}. Counts use openings/count columns when available; otherwise each matching row counts as one demand signal.`
    : "No matching technologies were found in the detected skill, role, title, or description columns.";

  const cards = [
    ["Highest demand", analysis.topTech[0] ? `${analysis.topTech[0].name} leads with ${Math.round(analysis.topTech[0].count)} demand signals.` : "No clear leader found."],
    ["Strong locations", analysis.locations.length ? analysis.locations.map(item => item.name).join(", ") : "No location column was detected."],
    ["Common roles", analysis.roles.length ? analysis.roles.map(item => item.name).join(", ") : "No role or title column was detected."],
    ["Trend readiness", analysis.months.length > 1 ? "A date column was found, so trend visuals are available." : "Add a posted date or month column for richer trend analysis."],
    ["Table interaction", `${state.filteredRows.length.toLocaleString()} rows match the current query and are available in the Table tab.`],
    ["Query used", analysis.query || "No query entered; showing overall technology demand."]
  ];

  els.insightList.innerHTML = cards.map(([title, body]) => (
    `<article class="insight-card"><strong>${escapeHtml(title)}</strong><p>${escapeHtml(body)}</p></article>`
  )).join("");
}

async function enrichWithAi(query, analysis) {
  if (!els.aiToggle.checked || !query || !analysis.topTech.length) return;
  const payload = {
    contents: [{
      parts: [{
        text: `In 90 words or less, explain these technology-demand findings for the user's query: "${query}". Data summary: ${JSON.stringify({
          topTechnologies: analysis.topTech.slice(0, 8).map(item => ({ name: item.name, demand: Math.round(item.count) })),
          locations: analysis.locations,
          roles: analysis.roles,
          rowsAnalyzed: analysis.totalRows
        })}`
      }]
    }]
  };

  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=${GEMINI_API_KEY}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (!response.ok) return;
    const json = await response.json();
    const text = json.candidates?.[0]?.content?.parts?.[0]?.text;
    if (text) els.aiInsight.textContent = text.trim();
  } catch {
    // The local analysis remains fully usable when the AI service is offline.
  }
}

function renderTable() {
  const limit = Math.max(5, Math.min(500, Number(els.rowsShown.value) || 50));
  const headers = state.headers;
  const rows = state.filteredRows.slice(0, limit);
  els.dataTable.querySelector("thead").innerHTML = `<tr>${headers.map(header => `<th>${escapeHtml(header)}</th>`).join("")}</tr>`;
  els.dataTable.querySelector("tbody").innerHTML = rows.map(row => (
    `<tr>${headers.map(header => `<td title="${escapeHtml(row[header])}">${escapeHtml(row[header])}</td>`).join("")}</tr>`
  )).join("");
}

function downloadCurrentTable() {
  if (!state.filteredRows.length) return;
  const csv = [
    state.headers.map(csvEscape).join(","),
    ...state.filteredRows.map(row => state.headers.map(header => csvEscape(row[header])).join(","))
  ].join("\r\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "technology-demand-analysis.csv";
  link.click();
  URL.revokeObjectURL(link.href);
}

function csvEscape(value) {
  const text = String(value ?? "");
  return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function showError(message) {
  els.fileStatus.textContent = "Error";
  els.aiInsight.textContent = message;
  els.chartTitle.textContent = "Could not load file";
  const ctx = els.chartCanvas.getContext("2d");
  ctx.clearRect(0, 0, els.chartCanvas.width, els.chartCanvas.height);
  drawEmpty(ctx, els.chartCanvas.width, els.chartCanvas.height, message);
}

loadSample();
