@echo off
setlocal
cd /d "%~dp0"
echo Starting Technology Demand Analyzer...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
endlocal
