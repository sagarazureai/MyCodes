from __future__ import annotations

import csv
import json
import mimetypes
import os
import random
import sys
import time
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass, field
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse


ROOT = Path(__file__).resolve().parent
DEFAULT_DATA_DIR = ROOT / "input_data"
MANUAL_DATA_FILE = DEFAULT_DATA_DIR / "manual_components.json"
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "AIzaSyDCV1gsSIxZKiNZItPY5KLcaatRpO8LPzQ")


@dataclass
class SupplierOption:
    name: str
    cost: float
    lead: int
    quality: float
    reliability: int
    score: int


@dataclass
class Component:
    id: str
    component: str
    supplier: str
    region: str
    risk: int
    leadTime: int
    quality: float
    availability: list[int]
    recommendation: str
    demand: int
    stock: int
    reorderPoint: int
    costImpact: float
    alternatives: list[SupplierOption] = field(default_factory=list)


def slugify(value: str) -> str:
    slug = "".join(char.lower() if char.isalnum() else "-" for char in value).strip("-")
    return "-".join(part for part in slug.split("-") if part) or f"component-{int(time.time())}"


def default_alternatives(component_name: str, risk: int) -> list[SupplierOption]:
    base_score = max(68, min(94, 100 - risk // 5))
    prefixes = ["Kyoto", "Austin", "Dresden", "Penang", "Gumi", "Johor"]
    suffixes = ["Advanced Supply", "Electronics", "Component Systems", "Precision Tech"]
    return [
        SupplierOption(
            name=f"{random.choice(prefixes)} {random.choice(suffixes)}",
            cost=round(random.uniform(0.08, 24.0), 2),
            lead=random.randint(7, 18),
            quality=round(random.uniform(95.0, 99.4), 1),
            reliability=random.randint(82, 96),
            score=max(65, min(96, base_score + random.randint(-5, 6))),
        )
        for _ in range(3)
    ]


def number(row: dict[str, Any], key: str, default: float = 0) -> float:
    value = row.get(key, default)
    if value in ("", None):
        return default
    return float(value)


def boolean(row: dict[str, Any], key: str, default: bool = False) -> bool:
    value = row.get(key, default)
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def derive_analysis(row: dict[str, Any]) -> dict[str, Any]:
    weekly_demand = number(row, "weeklyDemand", number(row, "demand", 100000))
    stock = number(row, "onHandInventory", number(row, "stock", weekly_demand * 0.45))
    open_po = number(row, "openPoQty", 0)
    committed = number(row, "supplierCommittedQty", weekly_demand * 0.7)
    in_transit = number(row, "inTransitQty", 0)
    avg_daily_usage = number(row, "avgDailyUsage", weekly_demand / 7)
    standard_lead = max(1, number(row, "standardLeadTimeDays", number(row, "leadTime", 10)))
    actual_lead = max(1, number(row, "actualLeadTimeDays", standard_lead))
    delayed_shipments = number(row, "delayedShipments", 0)
    total_shipments = max(1, number(row, "totalShipments", 10))
    defect_parts = number(row, "defectParts", 0)
    inspected_parts = max(1, number(row, "inspectedParts", 10000))
    logistics_delay = number(row, "logisticsDelayDays", max(0, actual_lead - standard_lead))
    geopolitical_exposure = number(row, "geopoliticalExposure", 35)
    single_source = boolean(row, "singleSource", False)
    unit_cost = number(row, "unitCost", 1)
    production_priority = number(row, "productionPriority", 3)
    days_until_line_stop = number(row, "daysUntilLineStop", stock / max(1, avg_daily_usage))

    coverage_days = (stock + in_transit + open_po) / max(1, avg_daily_usage)
    fulfillment_ratio = committed / max(1, weekly_demand)
    delay_rate = delayed_shipments / total_shipments
    defect_rate = defect_parts / inspected_parts
    lead_variance = max(0, actual_lead - standard_lead) / standard_lead

    risk = (
        max(0, 28 - coverage_days) * 1.7
        + max(0, 1 - fulfillment_ratio) * 28
        + delay_rate * 20
        + lead_variance * 20
        + logistics_delay * 1.5
        + geopolitical_exposure * 0.16
        + (12 if single_source else 0)
        + production_priority * 2.2
        + max(0, 10 - days_until_line_stop) * 2
    )
    risk_score = int(max(5, min(98, round(risk))))
    quality_score = round(max(80, min(99.9, 100 - defect_rate * 100)), 1)
    reorder_point = int(round(avg_daily_usage * (actual_lead + 7)))
    cost_impact = round(max(0.05, max(0, reorder_point - stock) * unit_cost / 1_000_000), 2)

    first_availability = max(12, min(98, int(round((stock + in_transit) / max(1, weekly_demand) * 100))))
    weekly_burn = max(3, int(round((weekly_demand - committed) / max(1, weekly_demand) * 11 + delay_rate * 10 + lead_variance * 8)))
    availability = [max(8, first_availability - index * weekly_burn) for index in range(8)]

    if risk_score >= 85:
        recommendation = "Expedite logistics, split allocation, and approve alternate source"
    elif risk_score >= 70:
        recommendation = "Raise reorder point and reserve backup supplier capacity"
    elif risk_score >= 50:
        recommendation = "Monitor supplier commits and rebalance plant allocation"
    else:
        recommendation = "Maintain current plan and continue supplier monitoring"

    return {
        "risk": risk_score,
        "leadTime": int(round(actual_lead)),
        "quality": quality_score,
        "availability": availability,
        "recommendation": recommendation,
        "demand": int(round(weekly_demand)),
        "stock": int(round(stock)),
        "reorderPoint": reorder_point,
        "costImpact": cost_impact,
    }


def make_component(row: dict[str, Any]) -> Component:
    component = str(row.get("component") or row.get("name") or "Unspecified component").strip()
    analysis = derive_analysis(row)
    risk = analysis["risk"]

    raw_alternatives = row.get("alternatives")
    alternatives: list[SupplierOption] = []
    if isinstance(raw_alternatives, list):
        for item in raw_alternatives[:5]:
            if isinstance(item, dict):
                alternatives.append(
                    SupplierOption(
                        name=str(item.get("name", "Qualified alternate")),
                        cost=float(item.get("cost", 1.0)),
                        lead=int(float(item.get("lead", 12))),
                        quality=float(item.get("quality", 97.0)),
                        reliability=int(float(item.get("reliability", 88))),
                        score=int(float(item.get("score", 82))),
                    )
                )
    if not alternatives:
        alternatives = default_alternatives(component, risk)

    return Component(
        id=str(row.get("id") or slugify(component)),
        component=component,
        supplier=str(row.get("supplier", "Primary supplier")),
        region=str(row.get("region", "Global")),
        risk=analysis["risk"],
        leadTime=analysis["leadTime"],
        quality=analysis["quality"],
        availability=analysis["availability"],
        recommendation=analysis["recommendation"],
        demand=analysis["demand"],
        stock=analysis["stock"],
        reorderPoint=analysis["reorderPoint"],
        costImpact=analysis["costImpact"],
        alternatives=alternatives,
    )


def dummy_components() -> list[Component]:
    return [make_component(row) for row in dummy_raw_rows()]


def dummy_raw_rows() -> list[dict[str, Any]]:
    return [
        {
            "component": "32-bit automotive MCU",
            "supplier": "Shenzhen MicroLogic",
            "region": "China",
            "plant": "Pune Assembly 1",
            "productionLine": "EV controller line",
            "weeklyDemand": 184000,
            "onHandInventory": 61000,
            "openPoQty": 22000,
            "supplierCommittedQty": 92000,
            "inTransitQty": 18000,
            "avgDailyUsage": 26285,
            "standardLeadTimeDays": 10,
            "actualLeadTimeDays": 18,
            "delayedShipments": 7,
            "totalShipments": 10,
            "defectParts": 312,
            "inspectedParts": 12000,
            "unitCost": 8.7,
            "logisticsDelayDays": 5,
            "geopoliticalExposure": 78,
            "singleSource": "yes",
            "productionPriority": 5,
            "daysUntilLineStop": 3,
        },
        {
            "component": "Power management IC",
            "supplier": "Taipei PowerSil",
            "region": "Taiwan",
            "plant": "Chennai Mobile Plant",
            "productionLine": "Main board SMT",
            "weeklyDemand": 310000,
            "onHandInventory": 128000,
            "openPoQty": 70000,
            "supplierCommittedQty": 210000,
            "inTransitQty": 44000,
            "avgDailyUsage": 44285,
            "standardLeadTimeDays": 9,
            "actualLeadTimeDays": 14,
            "delayedShipments": 5,
            "totalShipments": 12,
            "defectParts": 228,
            "inspectedParts": 16000,
            "unitCost": 2.9,
            "logisticsDelayDays": 3,
            "geopoliticalExposure": 62,
            "singleSource": "no",
            "productionPriority": 5,
            "daysUntilLineStop": 4,
        },
        {
            "component": "MLCC 10uF X7R capacitor",
            "supplier": "Osaka Passive Group",
            "region": "Japan",
            "plant": "Noida Electronics",
            "productionLine": "Passive placement",
            "weeklyDemand": 1240000,
            "onHandInventory": 620000,
            "openPoQty": 180000,
            "supplierCommittedQty": 990000,
            "inTransitQty": 210000,
            "avgDailyUsage": 177142,
            "standardLeadTimeDays": 8,
            "actualLeadTimeDays": 11,
            "delayedShipments": 4,
            "totalShipments": 18,
            "defectParts": 96,
            "inspectedParts": 25000,
            "unitCost": 0.05,
            "logisticsDelayDays": 2,
            "geopoliticalExposure": 36,
            "singleSource": "no",
            "productionPriority": 4,
            "daysUntilLineStop": 5,
        },
        {
            "component": "6.1 inch OLED module",
            "supplier": "Busan Display Co.",
            "region": "South Korea",
            "plant": "Chennai Mobile Plant",
            "productionLine": "Final assembly",
            "weeklyDemand": 82000,
            "onHandInventory": 57000,
            "openPoQty": 18000,
            "supplierCommittedQty": 78000,
            "inTransitQty": 12000,
            "avgDailyUsage": 11714,
            "standardLeadTimeDays": 7,
            "actualLeadTimeDays": 9,
            "delayedShipments": 1,
            "totalShipments": 11,
            "defectParts": 184,
            "inspectedParts": 9000,
            "unitCost": 22.4,
            "logisticsDelayDays": 1,
            "geopoliticalExposure": 28,
            "singleSource": "no",
            "productionPriority": 3,
            "daysUntilLineStop": 6,
        },
        {
            "component": "Lithium polymer cell",
            "supplier": "Ningde Energy Materials",
            "region": "China",
            "plant": "Pune Assembly 2",
            "productionLine": "Battery pack line",
            "weeklyDemand": 146000,
            "onHandInventory": 76000,
            "openPoQty": 26000,
            "supplierCommittedQty": 92000,
            "inTransitQty": 11000,
            "avgDailyUsage": 20857,
            "standardLeadTimeDays": 10,
            "actualLeadTimeDays": 15,
            "delayedShipments": 6,
            "totalShipments": 14,
            "defectParts": 412,
            "inspectedParts": 15000,
            "unitCost": 6.2,
            "logisticsDelayDays": 4,
            "geopoliticalExposure": 71,
            "singleSource": "yes",
            "productionPriority": 4,
            "daysUntilLineStop": 4,
        },
    ]


def read_json(path: Path) -> list[dict[str, Any]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(data, dict):
        data = data.get("production_data", data.get("components", [data]))
    return [item for item in data if isinstance(item, dict)]


def read_csv(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return [dict(row) for row in csv.DictReader(handle)]


def load_components(data_dir: Path = DEFAULT_DATA_DIR) -> tuple[list[Component], list[str]]:
    data_dir.mkdir(exist_ok=True)
    rows: list[dict[str, Any]] = []
    loaded_files: list[str] = []
    for path in sorted(data_dir.iterdir()):
        if path.suffix.lower() == ".json":
            rows.extend(read_json(path))
            loaded_files.append(path.name)
        elif path.suffix.lower() == ".csv":
            rows.extend(read_csv(path))
            loaded_files.append(path.name)
    components = [make_component(row) for row in rows] if rows else dummy_components()
    return components, loaded_files


def write_dummy_files() -> list[str]:
    DEFAULT_DATA_DIR.mkdir(exist_ok=True)
    rows = dummy_raw_rows()
    json_path = DEFAULT_DATA_DIR / "components.json"
    csv_path = DEFAULT_DATA_DIR / "components.csv"
    json_path.write_text(json.dumps({"production_data": rows}, indent=2), encoding="utf-8")
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        fieldnames = list(rows[0].keys())
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    return [str(json_path.relative_to(ROOT)), str(csv_path.relative_to(ROOT))]


class SupplyGuardHandler(SimpleHTTPRequestHandler):
    server_version = "SupplyGuard/1.0"

    def translate_path(self, path: str) -> str:
        parsed = urlparse(path)
        clean_path = parsed.path.lstrip("/") or "index.html"
        return str((ROOT / clean_path).resolve())

    def send_json(self, payload: Any, status: int = 200) -> None:
        body = json.dumps(payload, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_json_body(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        if length == 0:
            return {}
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/components":
            query = parse_qs(parsed.query)
            folder = query.get("folder", [str(DEFAULT_DATA_DIR)])[0]
            data_dir = Path(folder)
            if not data_dir.is_absolute():
                data_dir = ROOT / data_dir
            try:
                components, files = load_components(data_dir)
                self.send_json(
                    {
                        "components": [asdict(component) for component in components],
                        "sourceFolder": str(data_dir),
                        "loadedFiles": files,
                    }
                )
            except Exception as exc:
                self.send_json({"error": str(exc)}, 400)
            return
        super().do_GET()

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/components":
            try:
                payload = self.read_json_body()
                component = asdict(make_component(payload))
                DEFAULT_DATA_DIR.mkdir(exist_ok=True)
                existing = read_json(MANUAL_DATA_FILE) if MANUAL_DATA_FILE.exists() else []
                existing.append(payload)
                MANUAL_DATA_FILE.write_text(json.dumps({"production_data": existing}, indent=2), encoding="utf-8")
                self.send_json({"saved": component, "file": str(MANUAL_DATA_FILE.relative_to(ROOT))}, 201)
            except Exception as exc:
                self.send_json({"error": str(exc)}, 400)
            return

        if parsed.path == "/api/generate-dummy":
            try:
                files = write_dummy_files()
                self.send_json({"created": files})
            except Exception as exc:
                self.send_json({"error": str(exc)}, 500)
            return

        if parsed.path == "/api/summary":
            try:
                payload = self.read_json_body()
                summary = gemini_summary(payload.get("components", []))
                self.send_json({"summary": summary})
            except Exception as exc:
                self.send_json({"error": str(exc)}, 502)
            return

        self.send_error(404)

    def guess_type(self, path: str) -> str:
        return mimetypes.guess_type(path)[0] or "application/octet-stream"


def gemini_summary(components: list[dict[str, Any]]) -> str:
    prompt = (
        "Write a concise executive supply chain risk summary for electronics manufacturing. "
        "Mention risk hotspots, cost exposure, and recommended mitigations. Data: "
        f"{json.dumps(components[:12])}"
    )
    body = json.dumps({"contents": [{"parts": [{"text": prompt}]}]}).encode("utf-8")
    request = urllib.request.Request(
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
        data=body,
        headers={"Content-Type": "application/json", "x-goog-api-key": GEMINI_API_KEY},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=20) as response:
        data = json.loads(response.read().decode("utf-8"))
    return data["candidates"][0]["content"]["parts"][0]["text"]


def main() -> None:
    port = int(os.environ.get("PORT", "8000"))
    write_dummy_files()
    server = ThreadingHTTPServer(("127.0.0.1", port), SupplyGuardHandler)
    print(f"SupplyGuard Python app running at http://127.0.0.1:{port}")
    print(f"Input folder: {DEFAULT_DATA_DIR}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping SupplyGuard.")


if __name__ == "__main__":
    main()
