const fallbackRawData = [
  {
    component: "32-bit automotive MCU",
    supplier: "Shenzhen MicroLogic",
    region: "China",
    plant: "Pune Assembly 1",
    productionLine: "EV controller line",
    weeklyDemand: 184000,
    onHandInventory: 61000,
    openPoQty: 22000,
    supplierCommittedQty: 92000,
    inTransitQty: 18000,
    avgDailyUsage: 26285,
    standardLeadTimeDays: 10,
    actualLeadTimeDays: 18,
    delayedShipments: 7,
    totalShipments: 10,
    defectParts: 312,
    inspectedParts: 12000,
    unitCost: 8.7,
    logisticsDelayDays: 5,
    geopoliticalExposure: 78,
    singleSource: "yes",
    productionPriority: 5,
    daysUntilLineStop: 3,
  },
  {
    component: "Power management IC",
    supplier: "Taipei PowerSil",
    region: "Taiwan",
    plant: "Chennai Mobile Plant",
    productionLine: "Main board SMT",
    weeklyDemand: 310000,
    onHandInventory: 128000,
    openPoQty: 70000,
    supplierCommittedQty: 210000,
    inTransitQty: 44000,
    avgDailyUsage: 44285,
    standardLeadTimeDays: 9,
    actualLeadTimeDays: 14,
    delayedShipments: 5,
    totalShipments: 12,
    defectParts: 228,
    inspectedParts: 16000,
    unitCost: 2.9,
    logisticsDelayDays: 3,
    geopoliticalExposure: 62,
    singleSource: "no",
    productionPriority: 5,
    daysUntilLineStop: 4,
  },
  {
    component: "MLCC 10uF X7R capacitor",
    supplier: "Osaka Passive Group",
    region: "Japan",
    plant: "Noida Electronics",
    productionLine: "Passive placement",
    weeklyDemand: 1240000,
    onHandInventory: 620000,
    openPoQty: 180000,
    supplierCommittedQty: 990000,
    inTransitQty: 210000,
    avgDailyUsage: 177142,
    standardLeadTimeDays: 8,
    actualLeadTimeDays: 11,
    delayedShipments: 4,
    totalShipments: 18,
    defectParts: 96,
    inspectedParts: 25000,
    unitCost: 0.05,
    logisticsDelayDays: 2,
    geopoliticalExposure: 36,
    singleSource: "no",
    productionPriority: 4,
    daysUntilLineStop: 5,
  },
  {
    component: "6.1 inch OLED module",
    supplier: "Busan Display Co.",
    region: "South Korea",
    plant: "Chennai Mobile Plant",
    productionLine: "Final assembly",
    weeklyDemand: 82000,
    onHandInventory: 57000,
    openPoQty: 18000,
    supplierCommittedQty: 78000,
    inTransitQty: 12000,
    avgDailyUsage: 11714,
    standardLeadTimeDays: 7,
    actualLeadTimeDays: 9,
    delayedShipments: 1,
    totalShipments: 11,
    defectParts: 184,
    inspectedParts: 9000,
    unitCost: 22.4,
    logisticsDelayDays: 1,
    geopoliticalExposure: 28,
    singleSource: "no",
    productionPriority: 3,
    daysUntilLineStop: 6,
  },
  {
    component: "Lithium polymer cell",
    supplier: "Ningde Energy Materials",
    region: "China",
    plant: "Pune Assembly 2",
    productionLine: "Battery pack line",
    weeklyDemand: 146000,
    onHandInventory: 76000,
    openPoQty: 26000,
    supplierCommittedQty: 92000,
    inTransitQty: 11000,
    avgDailyUsage: 20857,
    standardLeadTimeDays: 10,
    actualLeadTimeDays: 15,
    delayedShipments: 6,
    totalShipments: 14,
    defectParts: 412,
    inspectedParts: 15000,
    unitCost: 6.2,
    logisticsDelayDays: 4,
    geopoliticalExposure: 71,
    singleSource: "yes",
    productionPriority: 4,
    daysUntilLineStop: 4,
  },
];

let components = [];

const actions = [
  { text: "Approve MCU alternate source qualification", owner: "Procurement", done: false },
  { text: "Expedite PMIC ocean-to-air conversion for week 19", owner: "Logistics", done: true },
  { text: "Negotiate MLCC allocation transfer from Plant B", owner: "Supplier Mgmt", done: false },
  { text: "Review battery cell demand signal with S&OP", owner: "Planning", done: false },
];

const riskColors = {
  critical: "#e0301e",
  high: "#eb8c00",
  medium: "#ffb600",
  low: "#25845f",
};

const qs = (selector) => document.querySelector(selector);
const qsa = (selector) => [...document.querySelectorAll(selector)];

function severity(risk) {
  if (risk >= 85) return "critical";
  if (risk >= 70) return "high";
  if (risk >= 50) return "medium";
  return "low";
}

function formatNumber(value) {
  return new Intl.NumberFormat("en-US").format(value);
}

function slugify(value) {
  return String(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

function toNumber(value, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function toBool(value) {
  return ["1", "true", "yes", "y"].includes(String(value).toLowerCase());
}

function deriveClientComponent(row) {
  if (row.risk && row.quality && row.availability && row.recommendation) return row;

  const weeklyDemand = toNumber(row.weeklyDemand || row.demand, 100000);
  const stock = toNumber(row.onHandInventory || row.stock, weeklyDemand * 0.45);
  const openPo = toNumber(row.openPoQty, 0);
  const committed = toNumber(row.supplierCommittedQty, weeklyDemand * 0.7);
  const inTransit = toNumber(row.inTransitQty, 0);
  const avgDailyUsage = toNumber(row.avgDailyUsage, weeklyDemand / 7);
  const standardLead = Math.max(1, toNumber(row.standardLeadTimeDays || row.leadTime, 10));
  const actualLead = Math.max(1, toNumber(row.actualLeadTimeDays, standardLead));
  const delayedShipments = toNumber(row.delayedShipments, 0);
  const totalShipments = Math.max(1, toNumber(row.totalShipments, 10));
  const defectParts = toNumber(row.defectParts, 0);
  const inspectedParts = Math.max(1, toNumber(row.inspectedParts, 10000));
  const logisticsDelay = toNumber(row.logisticsDelayDays, Math.max(0, actualLead - standardLead));
  const geopoliticalExposure = toNumber(row.geopoliticalExposure, 35);
  const productionPriority = toNumber(row.productionPriority, 3);
  const daysUntilLineStop = toNumber(row.daysUntilLineStop, stock / Math.max(1, avgDailyUsage));
  const unitCost = toNumber(row.unitCost, 1);

  const coverageDays = (stock + inTransit + openPo) / Math.max(1, avgDailyUsage);
  const fulfillmentRatio = committed / Math.max(1, weeklyDemand);
  const delayRate = delayedShipments / totalShipments;
  const defectRate = defectParts / inspectedParts;
  const leadVariance = Math.max(0, actualLead - standardLead) / standardLead;
  const risk = Math.round(
    Math.max(0, 28 - coverageDays) * 1.7 +
      Math.max(0, 1 - fulfillmentRatio) * 28 +
      delayRate * 20 +
      leadVariance * 20 +
      logisticsDelay * 1.5 +
      geopoliticalExposure * 0.16 +
      (toBool(row.singleSource) ? 12 : 0) +
      productionPriority * 2.2 +
      Math.max(0, 10 - daysUntilLineStop) * 2,
  );
  const riskScore = Math.max(5, Math.min(98, risk));
  const firstAvailability = Math.max(12, Math.min(98, Math.round(((stock + inTransit) / Math.max(1, weeklyDemand)) * 100)));
  const weeklyBurn = Math.max(3, Math.round((1 - fulfillmentRatio) * 11 + delayRate * 10 + leadVariance * 8));
  const availability = Array.from({ length: 8 }, (_, index) => Math.max(8, firstAvailability - index * weeklyBurn));
  const reorderPoint = Math.round(avgDailyUsage * (actualLead + 7));
  const recommendations = {
    critical: "Expedite logistics, split allocation, and approve alternate source",
    high: "Raise reorder point and reserve backup supplier capacity",
    medium: "Monitor supplier commits and rebalance plant allocation",
    low: "Maintain current plan and continue supplier monitoring",
  };

  return {
    ...row,
    id: row.id || slugify(row.component),
    risk: riskScore,
    leadTime: Math.round(actualLead),
    quality: Number(Math.max(80, Math.min(99.9, 100 - defectRate * 100)).toFixed(1)),
    availability,
    recommendation: recommendations[severity(riskScore)],
    demand: Math.round(weeklyDemand),
    stock: Math.round(stock),
    reorderPoint,
    costImpact: Number(Math.max(0.05, (Math.max(0, reorderPoint - stock) * unitCost) / 1000000).toFixed(2)),
    alternatives: [
      { name: "AI-ranked alternate supplier A", cost: unitCost * 1.08, lead: Math.max(6, Math.round(actualLead * 0.75)), quality: 98.1, reliability: 92, score: 88 },
      { name: "AI-ranked alternate supplier B", cost: unitCost * 0.96, lead: Math.max(7, Math.round(actualLead * 0.9)), quality: 97.2, reliability: 87, score: 83 },
      { name: "AI-ranked alternate supplier C", cost: unitCost * 1.14, lead: Math.max(5, Math.round(actualLead * 0.7)), quality: 96.8, reliability: 90, score: 84 },
    ],
  };
}

function isServerMode() {
  return window.location.protocol === "http:" || window.location.protocol === "https:";
}

function showToast(message) {
  const toast = qs("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove("show"), 3200);
}

function setFolderStatus(message) {
  const status = qs("#folderStatus");
  if (status) status.textContent = message;
}

function updatePortfolioMetrics() {
  const averageRisk = Math.round(components.reduce((sum, item) => sum + item.risk, 0) / components.length);
  const atRisk = components.filter((item) => item.risk >= 60).length;
  const exposure = components.reduce((sum, item) => sum + Number(item.costImpact || 0), 0);
  qs("#globalRisk").textContent = String(averageRisk);
  qs("#atRiskParts").textContent = String(atRisk);
  qs("#costImpact").textContent = `$${exposure.toFixed(1)}M`;
}

async function loadComponentsFromServer() {
  if (!isServerMode()) {
    setFolderStatus("Open through the Python server to scan folders and save manual entries.");
    return;
  }

  const folder = encodeURIComponent(qs("#folderPath")?.value || "input_data");
  try {
    const response = await fetch(`/api/components?folder=${folder}`);
    if (!response.ok) throw new Error("Folder scan failed");
    const data = await response.json();
    components = (data.components?.length ? data.components : fallbackRawData).map(deriveClientComponent);
    const files = data.loadedFiles?.length ? data.loadedFiles.join(", ") : "dummy fallback";
    setFolderStatus(`Loaded ${components.length} components from ${data.sourceFolder}. Files: ${files}.`);
    renderAll();
  } catch (error) {
    components = fallbackRawData.map(deriveClientComponent);
    setFolderStatus("Could not reach the Python data API, so the dashboard is using built-in dummy data.");
    renderAll();
  }
}

function renderComponentRows(list = components) {
  qs("#componentRows").innerHTML = list
    .map((item) => {
      const sev = severity(item.risk);
      return `
        <tr>
          <td><strong>${item.component}</strong><br><small>${item.region}</small></td>
          <td>${item.supplier}</td>
          <td><span class="badge ${sev}">${item.risk} ${sev}</span></td>
          <td>${item.leadTime} days</td>
          <td>${item.quality.toFixed(1)}%</td>
          <td>${item.recommendation}</td>
          <td><button class="mini-button" data-po="${item.id}" type="button">Generate PO</button></td>
        </tr>
      `;
    })
    .join("");
}

function renderRiskMix() {
  const buckets = ["critical", "high", "medium", "low"].map((name) => ({
    name,
    count: components.filter((item) => severity(item.risk) === name).length,
  }));
  qs("#riskMix").innerHTML = buckets
    .map(
      (bucket) => `
      <div class="risk-row">
        <div class="risk-label"><span>${bucket.name}</span><strong>${bucket.count}</strong></div>
        <div class="bar"><i style="width:${bucket.count * 22}%; background:${riskColors[bucket.name]}"></i></div>
      </div>
    `,
    )
    .join("");
}

function renderForecastCards() {
  qs("#forecastCards").innerHTML = components
    .map((item) => {
      const min = Math.min(...item.availability);
      return `
        <article class="forecast-card">
          <header>
            <div>
              <strong>${item.component}</strong>
              <p>${item.supplier}</p>
            </div>
            <span class="badge ${severity(item.risk)}">${min}% wk8</span>
          </header>
          <div class="sparkline">
            ${item.availability.map((point) => `<i style="height:${point}%"></i>`).join("")}
          </div>
          <div class="meta-grid">
            <div><span>Demand</span><strong>${formatNumber(item.demand)}</strong></div>
            <div><span>On hand</span><strong>${formatNumber(item.stock)}</strong></div>
          </div>
        </article>
      `;
    })
    .join("");
}

function renderReorderList() {
  qs("#reorderList").innerHTML = components
    .map((item) => {
      const delta = item.reorderPoint - item.stock;
      const urgent = delta > 0;
      return `
        <div class="stack-item">
          <strong>${item.component}</strong>
          <p>${urgent ? "Reorder" : "Monitor"} ${formatNumber(Math.abs(delta))} units ${urgent ? "to restore safety stock" : "above trigger"}</p>
          <span class="badge ${urgent ? severity(item.risk) : "low"}">${formatNumber(item.reorderPoint)} trigger</span>
        </div>
      `;
    })
    .join("");
}

function renderSupplierOptions() {
  qs("#componentSelect").innerHTML = components
    .map((item) => `<option value="${item.id}">${item.component}</option>`)
    .join("");
}

function renderSupplierCards(id = components[0]?.id) {
  const item = components.find((component) => component.id === id);
  if (!item) {
    qs("#supplierCards").innerHTML = "";
    return;
  }
  qs("#supplierCards").innerHTML = item.alternatives
    .map(
      (supplier) => `
      <article class="supplier-card">
        <header>
          <div>
            <strong>${supplier.name}</strong>
            <p>Recommended alternate for ${item.component}</p>
          </div>
          <div class="score-ring" style="--score:${supplier.score}">${supplier.score}</div>
        </header>
        <div class="meta-grid">
          <div><span>Unit cost</span><strong>$${supplier.cost}</strong></div>
          <div><span>Lead time</span><strong>${supplier.lead} days</strong></div>
          <div><span>Quality</span><strong>${supplier.quality}%</strong></div>
          <div><span>Reliability</span><strong>${supplier.reliability}%</strong></div>
        </div>
        <footer>
          <span class="badge ${supplier.score >= 88 ? "low" : "medium"}">${supplier.score >= 88 ? "preferred" : "qualified"}</span>
          <button class="mini-button" data-po="${item.id}" data-alt="${supplier.name}" type="button">Create PO</button>
        </footer>
      </article>
    `,
    )
    .join("");
}

function renderActions() {
  qs("#actionList").innerHTML = actions
    .map(
      (action, index) => `
      <div class="action-item">
        <label>
          <input type="checkbox" data-action="${index}" ${action.done ? "checked" : ""} />
          <span>${action.text}</span>
        </label>
        <small>${action.owner}</small>
      </div>
    `,
    )
    .join("");
}

function updateSimulator() {
  const stock = Number(qs("#stockSlider").value);
  const expedite = qs("#expediteToggle").checked;
  const split = qs("#splitToggle").checked;
  const delayReduction = Math.min(72, Math.round(stock * 0.72 + (expedite ? 24 : 0) + (split ? 15 : 0)));
  const costAvoided = (0.62 + stock * 0.021 + (split ? 0.34 : 0) - (expedite ? 0.12 : 0)).toFixed(2);
  const recovery = Math.max(4, 18 - Math.round(stock / 5) - (expedite ? 3 : 0) - (split ? 2 : 0));
  qs("#stockValue").textContent = `${stock}%`;
  qs("#simResults").innerHTML = `
    <div class="sim-result"><span>Delay risk reduced</span><strong>${delayReduction}%</strong></div>
    <div class="sim-result"><span>Cost impact avoided</span><strong>$${costAvoided}M</strong></div>
    <div class="sim-result"><span>Schedule recovery</span><strong>${recovery} days</strong></div>
  `;
}

function drawRiskChart(days = 14) {
  const canvas = qs("#riskChart");
  const ctx = canvas.getContext("2d");
  const w = canvas.width;
  const h = canvas.height;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#fbfaf8";
  ctx.fillRect(0, 0, w, h);

  const points = Array.from({ length: 8 }, (_, index) => {
    const base = 48 + index * (days / 10);
    const shock = index > 3 ? 14 : 0;
    return Math.min(96, Math.round(base + shock + Math.sin(index * 1.4) * 7));
  });

  ctx.strokeStyle = "#ded8d2";
  ctx.lineWidth = 1;
  ctx.font = "13px Segoe UI";
  ctx.fillStyle = "#6f6f6f";
  for (let i = 0; i < 5; i += 1) {
    const y = 24 + i * 52;
    ctx.beginPath();
    ctx.moveTo(46, y);
    ctx.lineTo(w - 20, y);
    ctx.stroke();
    ctx.fillText(`${100 - i * 20}`, 14, y + 4);
  }

  const xStep = (w - 88) / (points.length - 1);
  const coords = points.map((point, index) => ({
    x: 52 + index * xStep,
    y: h - 34 - (point / 100) * (h - 66),
    point,
  }));

  const gradient = ctx.createLinearGradient(0, 0, w, 0);
  gradient.addColorStop(0, "#ffb600");
  gradient.addColorStop(0.55, "#eb8c00");
  gradient.addColorStop(1, "#e0301e");
  ctx.strokeStyle = gradient;
  ctx.lineWidth = 5;
  ctx.lineJoin = "round";
  ctx.beginPath();
  coords.forEach((coord, index) => {
    if (index === 0) ctx.moveTo(coord.x, coord.y);
    else ctx.lineTo(coord.x, coord.y);
  });
  ctx.stroke();

  coords.forEach((coord, index) => {
    ctx.fillStyle = index > 4 ? "#e0301e" : "#eb8c00";
    ctx.beginPath();
    ctx.arc(coord.x, coord.y, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#252525";
    ctx.fillText(`W${index + 1}`, coord.x - 9, h - 10);
  });
}

function openPo(componentId, alternateName) {
  const item = components.find((component) => component.id === componentId);
  const alternate = alternateName || item.alternatives[0].name;
  qs("#poTitle").textContent = `Generate PO for ${item.component}`;
  qs("#poDetails").innerHTML = `
    <div class="stack-item">
      <strong>${alternate}</strong>
      <p>Recommended quantity: ${formatNumber(Math.ceil((item.reorderPoint - item.stock) * 1.18))} units</p>
      <p>Approval route: Procurement lead -> Finance controller -> Plant planner</p>
      <span class="badge ${severity(item.risk)}">Risk score ${item.risk}</span>
    </div>
  `;
  qs("#poDialog").showModal();
}

function renderLocalExecutiveSummary() {
  qs("#executiveSummary").innerHTML = `
    <p>Supply chain health remains generally stable, but semiconductor and battery exposure is elevated across the next four weeks. The strongest near-term risk is the 32-bit automotive MCU, where projected availability falls below 40% by week six and creates an estimated $1.42M production exposure.</p>
    <p>Recommended executive action is to approve alternate-source purchase orders for MCU and PMIC demand, increase safety stock by 18-25% on critical devices, and keep expedited logistics active for the next two planning cycles.</p>
  `;
}

async function generateExecutiveSummary() {
  qs("#executiveSummary").innerHTML = "<p>Generating summary...</p>";

  try {
    if (!isServerMode()) throw new Error("Python summary API is not running");
    const response = await fetch("/api/summary", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        components: components.map(({ component, risk, leadTime, stock, reorderPoint, costImpact }) => ({
          component,
          risk,
          leadTime,
          stock,
          reorderPoint,
          costImpact,
        })),
      }),
    });

    if (!response.ok) throw new Error("AI summary request failed");
    const data = await response.json();
    const text = data.summary;
    if (text) {
      qs("#executiveSummary").innerHTML = `<p>${text.replace(/\n+/g, "</p><p>")}</p>`;
    } else {
      renderLocalExecutiveSummary();
    }
  } catch {
    renderLocalExecutiveSummary();
    showToast("Using local executive summary. AI endpoint was not reachable from this browser.");
  }
}

function setupEvents() {
  qsa(".nav-item").forEach((button) => {
    button.addEventListener("click", () => {
      qsa(".nav-item").forEach((item) => item.classList.remove("active"));
      qsa(".view").forEach((view) => view.classList.remove("active"));
      button.classList.add("active");
      qs(`#${button.dataset.view}`).classList.add("active");
    });
  });

  qsa("[data-horizon]").forEach((button) => {
    button.addEventListener("click", () => {
      qsa("[data-horizon]").forEach((item) => item.classList.remove("active"));
      button.classList.add("active");
      drawRiskChart(Number(button.dataset.horizon));
    });
  });

  qs("#supplierSearch").addEventListener("input", (event) => {
    const query = event.target.value.toLowerCase();
    renderComponentRows(
      components.filter(
        (item) =>
          item.component.toLowerCase().includes(query) ||
          item.supplier.toLowerCase().includes(query) ||
          item.recommendation.toLowerCase().includes(query),
      ),
    );
  });

  qs("#componentForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const formData = new FormData(form);
    const component = Object.fromEntries(formData.entries());
    [
      "weeklyDemand",
      "onHandInventory",
      "openPoQty",
      "supplierCommittedQty",
      "inTransitQty",
      "avgDailyUsage",
      "standardLeadTimeDays",
      "actualLeadTimeDays",
      "delayedShipments",
      "totalShipments",
      "defectParts",
      "inspectedParts",
      "unitCost",
      "logisticsDelayDays",
      "geopoliticalExposure",
      "productionPriority",
      "daysUntilLineStop",
    ].forEach((key) => {
      component[key] = Number(component[key]);
    });

    if (isServerMode()) {
      try {
        const response = await fetch("/api/components", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(component),
        });
        if (!response.ok) throw new Error("Save failed");
        form.reset();
        await loadComponentsFromServer();
        showToast("Component saved to input_data/manual_components.json.");
        return;
      } catch {
        showToast("Python API save failed. Adding this component to the current browser view only.");
      }
    }

    components = [
      ...components,
      deriveClientComponent(component),
    ];
    renderAll();
    showToast("Component added to the current browser view.");
  });

  qs("#loadFolderBtn").addEventListener("click", loadComponentsFromServer);
  qs("#dummyDataBtn").addEventListener("click", async () => {
    if (!isServerMode()) {
      setFolderStatus("Run the Python server to create dummy CSV and JSON files automatically.");
      return;
    }
    try {
      const response = await fetch("/api/generate-dummy", { method: "POST" });
      if (!response.ok) throw new Error("Dummy generation failed");
      const data = await response.json();
      setFolderStatus(`Created dummy input files: ${data.created.join(", ")}.`);
      await loadComponentsFromServer();
      showToast("Dummy data files created.");
    } catch {
      showToast("Could not create dummy files from the Python server.");
    }
  });

  document.body.addEventListener("click", (event) => {
    const poButton = event.target.closest("[data-po]");
    if (poButton) openPo(poButton.dataset.po, poButton.dataset.alt);
  });

  qs("#componentSelect").addEventListener("change", (event) => renderSupplierCards(event.target.value));
  ["#stockSlider", "#expediteToggle", "#splitToggle"].forEach((selector) => {
    qs(selector).addEventListener("input", updateSimulator);
  });

  qs("#notifyBtn").addEventListener("click", async () => {
    if (!("Notification" in window)) {
      showToast("Browser notifications are not supported here.");
      return;
    }
    const permission = await Notification.requestPermission();
    if (permission === "granted") {
      new Notification("SupplyGuard critical alert", {
        body: "MCU availability is projected below reorder threshold in week 3.",
      });
      showToast("Critical supply alerts are enabled.");
    } else {
      showToast("Notification permission was not granted.");
    }
  });

  qs("#reportBtn").addEventListener("click", () => {
    qs('[data-view="reports"]').click();
    generateExecutiveSummary();
  });
  qs("#aiSummaryBtn").addEventListener("click", generateExecutiveSummary);
  qs("#approvePoBtn").addEventListener("click", () => showToast("Alternative purchase order routed for approval."));
}

function renderAll() {
  updatePortfolioMetrics();
  renderComponentRows();
  renderRiskMix();
  renderForecastCards();
  renderReorderList();
  renderSupplierOptions();
  renderSupplierCards(components[0]?.id);
  renderActions();
  updateSimulator();
  drawRiskChart();
}

async function init() {
  components = fallbackRawData.map(deriveClientComponent);
  setupEvents();
  renderAll();
  await loadComponentsFromServer();
  renderLocalExecutiveSummary();
}

init();
