# SupplyGuard

Python-powered prototype for an electronics supply chain risk prediction and optimization portal using PwC-inspired colors.

## Run

```powershell
python server.py
```

Then open:

```text
http://127.0.0.1:8000
```

If your machine uses the Windows launcher instead:

```powershell
py server.py
```

The app includes dashboard analytics, component forecasting, supplier scorecards, mitigation simulation, notification alerts, executive reporting, manual component entry, folder-based data ingestion, dummy data generation, and alternative PO generation.

## Input Data

Place `.csv` or `.json` files in `input_data`, then click `Scan Folder`. Input files should contain raw production and supply facts only. Do not include calculated fields such as risk score, quality percentage, forecast availability, recommendation, reorder point, or cost impact; the app derives those during analysis.

Supported fields include:

```text
component,supplier,region,plant,productionLine,weeklyDemand,onHandInventory,openPoQty,supplierCommittedQty,inTransitQty,avgDailyUsage,standardLeadTimeDays,actualLeadTimeDays,delayedShipments,totalShipments,defectParts,inspectedParts,unitCost,logisticsDelayDays,geopoliticalExposure,singleSource,productionPriority,daysUntilLineStop
```

The dashboard derives:

```text
risk score, quality proxy, 8-week availability forecast, reorder point, cost impact, supplier alternatives, and recommendations
```

Manual entries are saved to `input_data/manual_components.json`.

The supplied Gemini API key is used by `server.py` for the executive summary feature and calls `gemini-2.5-flash`. For production, move the key to an environment variable named `GEMINI_API_KEY`.
