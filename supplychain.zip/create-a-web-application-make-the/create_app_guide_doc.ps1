$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$outPath = Join-Path $root "SupplyGuard_Application_Guide.docx"
$buildDir = Join-Path $root "docx_build"

if (Test-Path $buildDir) {
  Remove-Item -LiteralPath $buildDir -Recurse -Force
}

New-Item -ItemType Directory -Path (Join-Path $buildDir "_rels") | Out-Null
New-Item -ItemType Directory -Path (Join-Path $buildDir "word") | Out-Null
New-Item -ItemType Directory -Path (Join-Path $buildDir "word\_rels") | Out-Null

function Escape-XmlText {
  param([string]$Text)
  return [System.Security.SecurityElement]::Escape($Text)
}

function ParagraphXml {
  param(
    [string]$Text,
    [string]$Style = "Normal"
  )
  $escaped = Escape-XmlText $Text
  return "<w:p><w:pPr><w:pStyle w:val=`"$Style`"/></w:pPr><w:r><w:t xml:space=`"preserve`">$escaped</w:t></w:r></w:p>"
}

function BulletXml {
  param([string]$Text)
  $escaped = Escape-XmlText $Text
  return "<w:p><w:pPr><w:pStyle w:val=`"ListParagraph`"/></w:pPr><w:r><w:t xml:space=`"preserve`">• $escaped</w:t></w:r></w:p>"
}

$sections = @(
  @{ Type = "Title"; Text = "SupplyGuard Application Guide" },
  @{ Type = "Subtitle"; Text = "Electronics Supply Chain Risk Predictor and Optimization Portal" },
  @{ Type = "Heading1"; Text = "1. What This Application Does" },
  @{ Type = "Normal"; Text = "SupplyGuard is a dashboard for electronics manufacturers to monitor supplier risk, forecast component shortages, compare alternative suppliers, simulate mitigation actions, and prepare executive summaries. Input files contain only raw production and supply data; the application derives risk scores, quality signals, forecasts, reorder points, cost impact, and recommendations from that raw data." },
  @{ Type = "Heading1"; Text = "2. Main Files" },
  @{ Type = "Bullet"; Text = "index.html: Defines the app layout, navigation, panels, data input form, and modal workflow." },
  @{ Type = "Bullet"; Text = "styles.css: Controls the PwC-inspired visual design, responsive layout, cards, dashboards, forms, and tables." },
  @{ Type = "Bullet"; Text = "app.js: Powers the dashboard, charts, search, supplier cards, simulation, manual entry, folder scan calls, and executive summary behavior." },
  @{ Type = "Bullet"; Text = "server.py: Runs the Python web server and API endpoints for data loading, manual saves, dummy data creation, and AI summary generation." },
  @{ Type = "Bullet"; Text = "input_data: Folder where CSV and JSON input files are placed for the Python server to read." },
  @{ Type = "Heading1"; Text = "3. How To Run It" },
  @{ Type = "Normal"; Text = "Step 1: Open a terminal in the project folder." },
  @{ Type = "Normal"; Text = "Step 2: Run python server.py. If your system uses the Windows launcher, run py server.py." },
  @{ Type = "Normal"; Text = "Step 3: Open http://127.0.0.1:8000 in the browser." },
  @{ Type = "Normal"; Text = "Step 4: Use the dashboard normally. The Python server automatically creates dummy files in input_data if needed." },
  @{ Type = "Heading1"; Text = "4. Step-by-Step User Flow" },
  @{ Type = "Heading2"; Text = "Step 1: Open the Overview" },
  @{ Type = "Normal"; Text = "The Overview screen shows portfolio-level risk metrics: average risk index, number of at-risk components, estimated cost exposure, critical alerts, lead-time variance, mitigation coverage, and forecast confidence." },
  @{ Type = "Heading2"; Text = "Step 2: Review the Risk Timeline" },
  @{ Type = "Normal"; Text = "The Supply Risk Timeline chart shows how risk changes over a 2-week, 4-week, or 6-week horizon. Use the 2W, 4W, and 6W buttons to redraw the forecast." },
  @{ Type = "Heading2"; Text = "Step 3: Check Severity Mix" },
  @{ Type = "Normal"; Text = "The Risk Mix panel groups components into critical, high, medium, and low risk. The categories are calculated from each component's risk score." },
  @{ Type = "Heading2"; Text = "Step 4: Search Supplier Performance" },
  @{ Type = "Normal"; Text = "The supplier table lists each component, primary supplier, region, risk score, lead time, quality, and recommendation. Use the search box to filter by supplier, component, or recommendation." },
  @{ Type = "Heading2"; Text = "Step 5: Generate an Alternative PO" },
  @{ Type = "Normal"; Text = "Click Generate PO on a component row. A modal opens with a recommended alternate supplier, recommended quantity, approval route, and risk score. Clicking Approve PO simulates routing the purchase order for approval." },
  @{ Type = "Heading2"; Text = "Step 6: Add Data Manually" },
  @{ Type = "Normal"; Text = "In the Manual Entry & Folder Import section, fill in raw production fields such as component, supplier, plant, production line, weekly demand, on-hand inventory, open PO quantity, supplier committed quantity, in-transit quantity, lead times, shipment delays, defect counts, inspected parts, unit cost, and line-stop timing. Click Add Component. When the Python server is running, the raw record is saved to input_data/manual_components.json." },
  @{ Type = "Heading2"; Text = "Step 7: Load Data From a Folder" },
  @{ Type = "Normal"; Text = "Place CSV or JSON files inside input_data, or type another folder path in the Server input folder field. Click Scan Folder. The Python API reads raw .csv and .json production files, analyzes them, and refreshes the dashboard." },
  @{ Type = "Heading2"; Text = "Step 8: Create Dummy Data" },
  @{ Type = "Normal"; Text = "Click Create Dummy Data to generate sample components.csv and components.json files in input_data. This is useful for demos, testing, and understanding the expected data shape." },
  @{ Type = "Heading2"; Text = "Step 9: Use Forecast, Suppliers, Mitigation, and Reports" },
  @{ Type = "Normal"; Text = "Forecast shows availability trends and reorder points. Suppliers compares alternate suppliers by cost, lead time, quality, reliability, and score. Mitigation simulates the impact of safety stock, expedited logistics, and split allocation. Reports shows executive health and cost impact summaries." },
  @{ Type = "Heading1"; Text = "5. Data Input Format" },
  @{ Type = "Normal"; Text = "CSV files should contain raw fields only: component, supplier, region, plant, productionLine, weeklyDemand, onHandInventory, openPoQty, supplierCommittedQty, inTransitQty, avgDailyUsage, standardLeadTimeDays, actualLeadTimeDays, delayedShipments, totalShipments, defectParts, inspectedParts, unitCost, logisticsDelayDays, geopoliticalExposure, singleSource, productionPriority, and daysUntilLineStop." },
  @{ Type = "Normal"; Text = "Do not include risk, quality percentage, availability forecast, recommendation, reorder point, cost impact, or supplier scorecards in input files. Those are generated by the analysis layer." },
  @{ Type = "Normal"; Text = "JSON files can contain either one raw production object or an object with a production_data array." },
  @{ Type = "Heading1"; Text = "6. How The Data Moves Through The App" },
  @{ Type = "Bullet"; Text = "The browser loads index.html, styles.css, and app.js." },
  @{ Type = "Bullet"; Text = "app.js asks the Python server for /api/components when running from http://127.0.0.1:8000." },
  @{ Type = "Bullet"; Text = "server.py scans the selected input folder and parses .csv and .json files." },
  @{ Type = "Bullet"; Text = "If no input files are found, server.py uses built-in raw dummy production records." },
  @{ Type = "Bullet"; Text = "server.py derives risk score, quality proxy, 8-week availability, recommendation, reorder point, cost exposure, and supplier alternatives." },
  @{ Type = "Bullet"; Text = "The browser receives the analyzed component list and redraws metrics, charts, tables, scorecards, reorder points, and reports." },
  @{ Type = "Bullet"; Text = "Manual form submissions are sent to POST /api/components and saved as raw data into input_data/manual_components.json." },
  @{ Type = "Bullet"; Text = "Executive summary refresh sends component risk data to POST /api/summary, where server.py calls Gemini 2.5 Flash." },
  @{ Type = "Heading1"; Text = "7. Important Notes" },
  @{ Type = "Bullet"; Text = "The Python server is standard-library only, so no Flask or Streamlit installation is required." },
  @{ Type = "Bullet"; Text = "The AI summary uses the provided Gemini API key. For production, store the key in the GEMINI_API_KEY environment variable instead of hardcoding it." },
  @{ Type = "Bullet"; Text = "Opening index.html directly still works for the visual demo, but saving data and folder scanning require the Python server." },
  @{ Type = "Bullet"; Text = "Browser notifications require permission from the browser and may behave differently on file URLs versus localhost." },
  @{ Type = "Heading1"; Text = "8. Recommended Demo Script" },
  @{ Type = "Normal"; Text = "Start at the Overview, explain the risk cards, switch the forecast horizon, filter the supplier table, generate a PO, add a manual component, scan input_data, open Suppliers for alternate scorecards, adjust mitigation sliders, and finish with the Reports tab." }
)

$bodyParts = New-Object System.Collections.Generic.List[string]
foreach ($section in $sections) {
  if ($section.Type -eq "Bullet") {
    $bodyParts.Add((BulletXml $section.Text))
  } else {
    $bodyParts.Add((ParagraphXml $section.Text $section.Type))
  }
}

$documentXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    $($bodyParts -join "`n")
    <w:sectPr>
      <w:pgSz w:w="12240" w:h="15840"/>
      <w:pgMar w:top="1008" w:right="1008" w:bottom="1008" w:left="1008" w:header="720" w:footer="720" w:gutter="0"/>
    </w:sectPr>
  </w:body>
</w:document>
"@

$stylesXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:style w:type="paragraph" w:default="1" w:styleId="Normal">
    <w:name w:val="Normal"/>
    <w:rPr><w:sz w:val="22"/><w:rFonts w:ascii="Aptos" w:hAnsi="Aptos"/></w:rPr>
    <w:pPr><w:spacing w:after="160" w:line="276" w:lineRule="auto"/></w:pPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Title">
    <w:name w:val="Title"/>
    <w:rPr><w:b/><w:color w:val="2D2D2D"/><w:sz w:val="44"/></w:rPr>
    <w:pPr><w:spacing w:after="120"/></w:pPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Subtitle">
    <w:name w:val="Subtitle"/>
    <w:rPr><w:color w:val="A32020"/><w:sz w:val="24"/></w:rPr>
    <w:pPr><w:spacing w:after="320"/></w:pPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading1">
    <w:name w:val="heading 1"/>
    <w:rPr><w:b/><w:color w:val="A32020"/><w:sz w:val="30"/></w:rPr>
    <w:pPr><w:spacing w:before="280" w:after="120"/></w:pPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading2">
    <w:name w:val="heading 2"/>
    <w:rPr><w:b/><w:color w:val="EB8C00"/><w:sz w:val="25"/></w:rPr>
    <w:pPr><w:spacing w:before="180" w:after="90"/></w:pPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="ListParagraph">
    <w:name w:val="List Paragraph"/>
    <w:rPr><w:sz w:val="22"/></w:rPr>
    <w:pPr><w:ind w:left="360"/><w:spacing w:after="120"/></w:pPr>
  </w:style>
</w:styles>
"@

$contentTypesXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>
"@

$relsXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>
"@

$docRelsXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>
"@

Set-Content -LiteralPath (Join-Path $buildDir "[Content_Types].xml") -Value $contentTypesXml -Encoding UTF8
Set-Content -LiteralPath (Join-Path $buildDir "_rels\.rels") -Value $relsXml -Encoding UTF8
Set-Content -LiteralPath (Join-Path $buildDir "word\document.xml") -Value $documentXml -Encoding UTF8
Set-Content -LiteralPath (Join-Path $buildDir "word\styles.xml") -Value $stylesXml -Encoding UTF8
Set-Content -LiteralPath (Join-Path $buildDir "word\_rels\document.xml.rels") -Value $docRelsXml -Encoding UTF8

if (Test-Path $outPath) {
  Remove-Item -LiteralPath $outPath -Force
}

$zipPath = Join-Path $root "SupplyGuard_Application_Guide.zip"
if (Test-Path $zipPath) {
  Remove-Item -LiteralPath $zipPath -Force
}

Compress-Archive -Path (Join-Path $buildDir "*") -DestinationPath $zipPath -Force
Move-Item -LiteralPath $zipPath -Destination $outPath -Force
Remove-Item -LiteralPath $buildDir -Recurse -Force

Write-Output $outPath
