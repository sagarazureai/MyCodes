/**
 * Nexthink NQL & PowerShell Assistant Studio
 * Client Application Logic
 */

document.addEventListener('DOMContentLoaded', () => {
    // ------------------------------------------------------------------
    // Application State
    // ------------------------------------------------------------------
    const state = {
        apiKey: localStorage.getItem('nql_studio_apikey') || 'AQ.Ab8RN6I8Z9S3AX8UDodB7zL8CufKhwaot_9y8i5sP5Uq_oyDNA',
        model: localStorage.getItem('nql_studio_model') || 'gemini-2.5-flash',
        activeMode: 'generate', // 'generate' | 'analyze' | 'reference'
        activeTargetTab: 'ps', // 'ps' | 'nql' | 'nqlscript'
        activeSubTab: 'sectionLineByLine',
        data: null // Stores the active AI response object
    };

    // ------------------------------------------------------------------
    // DOM Elements Reference
    // ------------------------------------------------------------------
    const elements = {
        // Headers & Modals
        activeModelLabel: document.getElementById('activeModelLabel'),
        btnOpenSettings: document.getElementById('btnOpenSettings'),
        btnCloseSettings: document.getElementById('btnCloseSettings'),
        btnSaveSettings: document.getElementById('btnSaveSettings'),
        settingsModal: document.getElementById('settingsModal'),
        apiKeyInput: document.getElementById('apiKeyInput'),
        modelSelect: document.getElementById('modelSelect'),

        // Navigation Tabs
        tabModeGenerate: document.getElementById('tabModeGenerate'),
        tabModeAnalyze: document.getElementById('tabModeAnalyze'),
        tabModeRef: document.getElementById('tabModeRef'),
        modeBtns: document.querySelectorAll('.mode-btn'),

        // Control Sections
        sectionGenerateControls: document.getElementById('sectionGenerateControls'),
        sectionAnalyzeControls: document.getElementById('sectionAnalyzeControls'),
        sectionReference: document.getElementById('sectionReference'),
        workspaceSection: document.getElementById('workspaceSection'),
        loadingState: document.getElementById('loadingState'),
        loadingText: document.getElementById('loadingText'),

        // Inputs
        promptInput: document.getElementById('promptInput'),
        btnGenerate: document.getElementById('btnGenerate'),
        presetChips: document.querySelectorAll('.preset-chip'),
        analyzeInput: document.getElementById('analyzeInput'),
        btnAnalyze: document.getElementById('btnAnalyze'),
        fileInput: document.getElementById('fileInput'),
        btnUpload: document.getElementById('btnUpload'),
        dropZone: document.getElementById('dropZone'),
        dropOverlay: document.getElementById('dropOverlay'),

        // Left Panel (Explanation & Metadata)
        overviewText: document.getElementById('overviewText'),
        riskBadge: document.getElementById('riskBadge'),
        categoryBadge: document.getElementById('categoryBadge'),
        subTabs: document.querySelectorAll('.sub-tab'),
        subContents: document.querySelectorAll('.sub-content'),
        lineByLineList: document.getElementById('lineByLineList'),
        paramsList: document.getElementById('paramsList'),
        nexthinkGuideText: document.getElementById('nexthinkGuideText'),

        // Right Panel (Code Workspace)
        codeTabs: document.querySelectorAll('.code-tab'),
        btnCopyCode: document.getElementById('btnCopyCode'),
        btnDownloadCode: document.getElementById('btnDownloadCode'),
        lineNumbers: document.getElementById('lineNumbers'),
        codeViewer: document.getElementById('codeViewer')
    };

    // Initialize UI settings
    elements.apiKeyInput.value = state.apiKey;
    elements.modelSelect.value = state.model;
    elements.activeModelLabel.innerText = state.model;

    // ------------------------------------------------------------------
    // Domain System Instructions for Gemini
    // ------------------------------------------------------------------
    const SYSTEM_PROMPT_NQL_PS = `You are an elite enterprise IT Automation Expert specializing in Nexthink Platform, Nexthink Query Language (NQL), and Windows PowerShell (.ps1) engineering.

Your knowledge base includes:
1. Nexthink Query Language (NQL) Syntax & Data Platform:
   - Data Namespaces: devices, users, execution.events, web.events, binary.events, network.events, operating_system, packages, remote_action, system_crashes.
   - Operators: where, summarize, compute, with, include, sort, limit, during past, between, project.
   - Example NQL: devices | where hardware.disk.free_space < 10GB | include operating_system

2. Nexthink Remote Actions & PowerShell (.ps1):
   - Standard Remote Action script structure.
   - Parameter inputs, error trapping (try/catch), logging, and returning outputs via [hashtable]$outputs or nxtparam.
   - Execution context: Local SYSTEM or Logged-in User.

CRITICAL INSTRUCTION: You MUST ALWAYS respond with ONLY valid JSON (no markdown wrapping outside the JSON, no surrounding text).
JSON Schema:
{
  "summary": "String explaining operational purpose",
  "riskLevel": "Low" | "Medium" | "High",
  "category": "Category name (e.g. Disk Cleanup, Performance, App Health)",
  "nqlQuery": "Valid Nexthink NQL query string",
  "nqlScript": "Nexthink NQL Remote Action JSON/XML payload definition",
  "psScript": "Full PowerShell remediation script with parameters and error handling",
  "lineByLine": [
    { "line": 1, "code": "code snippet or line", "explanation": "Detailed step breakdown of what this line accomplishes" }
  ],
  "parameters": [
    { "name": "$ParamName", "type": "String/Int/Switch", "description": "Purpose of parameter" }
  ],
  "nexthinkNotes": "Deployment notes for Nexthink console"
}`;

    // ------------------------------------------------------------------
    // Event Handlers - Navigation & Modes
    // ------------------------------------------------------------------
    elements.modeBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const mode = btn.dataset.mode;
            switchMode(mode);
        });
    });

    function switchMode(mode) {
        state.activeMode = mode;
        elements.modeBtns.forEach(b => b.classList.remove('active'));

        if (mode === 'generate') {
            elements.tabModeGenerate.classList.add('active');
            elements.sectionGenerateControls.classList.remove('hidden');
            elements.sectionAnalyzeControls.classList.add('hidden');
            elements.sectionReference.classList.add('hidden');
            elements.workspaceSection.classList.remove('hidden');
        } else if (mode === 'analyze') {
            elements.tabModeAnalyze.classList.add('active');
            elements.sectionGenerateControls.classList.add('hidden');
            elements.sectionAnalyzeControls.classList.remove('hidden');
            elements.sectionReference.classList.add('hidden');
            elements.workspaceSection.classList.remove('hidden');
        } else if (mode === 'reference') {
            elements.tabModeRef.classList.add('active');
            elements.sectionGenerateControls.classList.add('hidden');
            elements.sectionAnalyzeControls.classList.add('hidden');
            elements.sectionReference.classList.remove('hidden');
            elements.workspaceSection.classList.add('hidden');
        }
    }

    // Preset Chip Buttons
    elements.presetChips.forEach(chip => {
        chip.addEventListener('click', () => {
            elements.promptInput.value = chip.dataset.prompt;
            elements.promptInput.focus();
        });
    });

    // Sub-tab Navigation (Left Panel)
    elements.subTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetId = tab.dataset.target;
            elements.subTabs.forEach(t => t.classList.remove('active'));
            elements.subContents.forEach(c => c.classList.add('hidden'));

            tab.classList.add('active');
            document.getElementById(targetId).classList.remove('hidden');
        });
    });

    // Code Target Tabs Navigation (Right Panel)
    elements.codeTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const target = tab.dataset.target; // 'ps' | 'nql' | 'nqlscript'
            state.activeTargetTab = target;
            elements.codeTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            renderCodeViewer();
        });
    });

    // ------------------------------------------------------------------
    // Settings Modal
    // ------------------------------------------------------------------
    elements.btnOpenSettings.addEventListener('click', () => elements.settingsModal.classList.remove('hidden'));
    elements.btnCloseSettings.addEventListener('click', () => elements.settingsModal.classList.add('hidden'));
    
    elements.btnSaveSettings.addEventListener('click', () => {
        state.apiKey = elements.apiKeyInput.value.trim();
        state.model = elements.modelSelect.value;
        
        localStorage.setItem('nql_studio_apikey', state.apiKey);
        localStorage.setItem('nql_studio_model', state.model);
        
        elements.activeModelLabel.innerText = state.model;
        elements.settingsModal.classList.add('hidden');
        showToast('Settings saved successfully');
    });

    // ------------------------------------------------------------------
    // Upload & File Handling
    // ------------------------------------------------------------------
    elements.btnUpload.addEventListener('click', () => elements.fileInput.click());

    elements.fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) readFileContent(file);
    });

    // Drag & Drop
    ['dragenter', 'dragover'].forEach(eventName => {
        elements.dropZone.addEventListener(eventName, (e) => {
            e.preventDefault();
            elements.dropOverlay.classList.remove('hidden');
        });
    });

    ['dragleave', 'drop'].forEach(eventName => {
        elements.dropZone.addEventListener(eventName, (e) => {
            e.preventDefault();
            elements.dropOverlay.classList.add('hidden');
        });
    });

    elements.dropZone.addEventListener('drop', (e) => {
        const file = e.dataTransfer.files[0];
        if (file) readFileContent(file);
    });

    function readFileContent(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            elements.analyzeInput.value = e.target.result;
            showToast(`Loaded file: ${file.name}`);
        };
        reader.readAsText(file);
    }

    // ------------------------------------------------------------------
    // API Calling & Gemini Integration
    // ------------------------------------------------------------------
    elements.btnGenerate.addEventListener('click', handleGenerate);
    elements.btnAnalyze.addEventListener('click', handleAnalyze);

    async function handleGenerate() {
        const prompt = elements.promptInput.value.trim();
        if (!prompt) {
            alert('Please enter your query requirement prompt first.');
            return;
        }

        const userPrompt = `REQUIREMENT: Generate an NQL Query, NQL Script definition, and PowerShell (.ps1) remediation script for the following task:\n"${prompt}"`;
        await executeGeminiRequest(userPrompt, "Generating NQL queries & PowerShell scripts...");
    }

    async function handleAnalyze() {
        const code = elements.analyzeInput.value.trim();
        if (!code) {
            alert('Please paste or upload code to analyze.');
            return;
        }

        const userPrompt = `ANALYZE CODE: Perform a thorough line-by-line breakdown, operational risk assessment, parameter identification, and Nexthink platform analysis of the following script/query:\n\`\`\`\n${code}\n\`\`\``;
        await executeGeminiRequest(userPrompt, "Analyzing script line-by-line...");
    }

    async function executeGeminiRequest(userPrompt, loadingMsg) {
        if (!state.apiKey) {
            alert('Please set your Gemini API Key in the Settings menu.');
            elements.settingsModal.classList.remove('hidden');
            return;
        }

        // UI Loading state
        elements.loadingText.innerText = loadingMsg;
        elements.loadingState.classList.remove('hidden');
        elements.workspaceSection.classList.add('hidden');

        try {
            const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${state.model}:generateContent?key=${state.apiKey}`;
            
            const payload = {
                contents: [
                    {
                        role: 'user',
                        parts: [
                            { text: SYSTEM_PROMPT_NQL_PS },
                            { text: userPrompt }
                        ]
                    }
                ],
                generationConfig: {
                    temperature: 0.2,
                    responseMimeType: "application/json"
                }
            };

            const response = await fetch(endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                const errData = await response.json();
                throw new Error(errData.error?.message || `HTTP error ${response.status}`);
            }

            const resData = await response.json();
            const rawText = resData.candidates?.[0]?.content?.parts?.[0]?.text;

            if (!rawText) {
                throw new Error("Empty response received from AI model.");
            }

            // Clean & Parse JSON
            let cleanJsonText = rawText.trim();
            if (cleanJsonText.startsWith('```json')) {
                cleanJsonText = cleanJsonText.replace(/^```json\s*/, '').replace(/\s*```$/, '');
            } else if (cleanJsonText.startsWith('```')) {
                cleanJsonText = cleanJsonText.replace(/^```\s*/, '').replace(/\s*```$/, '');
            }

            const parsedData = JSON.parse(cleanJsonText);
            state.data = parsedData;

            // Render workspace
            renderWorkspace();
            showToast('Analysis & generation complete!');

        } catch (error) {
            console.error("Gemini API Error:", error);
            alert(`Error: ${error.message}`);
        } finally {
            elements.loadingState.classList.add('hidden');
            elements.workspaceSection.classList.remove('hidden');
        }
    }

    // ------------------------------------------------------------------
    // Render Functions
    // ------------------------------------------------------------------
    function renderWorkspace() {
        if (!state.data) return;

        const d = state.data;

        // Render Left Panel Overview
        elements.overviewText.innerText = d.summary || "No summary provided.";
        
        // Risk Badge
        const risk = (d.riskLevel || "Low").toLowerCase();
        elements.riskBadge.className = `risk-badge ${risk}`;
        elements.riskBadge.innerText = `Risk: ${d.riskLevel || 'Low'}`;

        // Category Badge
        elements.categoryBadge.innerText = d.category || "Nexthink System";

        // Render Line-by-Line Breakdown
        elements.lineByLineList.innerHTML = '';
        if (d.lineByLine && d.lineByLine.length > 0) {
            d.lineByLine.forEach((item, index) => {
                const div = document.createElement('div');
                div.className = 'line-item';
                div.innerHTML = `
                    <div class="line-header">
                        <span class="line-no">Line ${item.line || index + 1}</span>
                        ${item.code ? `<span class="line-code-snippet">${escapeHtml(item.code)}</span>` : ''}
                    </div>
                    <div class="line-desc">${escapeHtml(item.explanation || '')}</div>
                `;
                elements.lineByLineList.appendChild(div);
            });
        } else {
            elements.lineByLineList.innerHTML = '<p class="text-muted">No line-by-line breakdown available.</p>';
        }

        // Render Parameters Table
        if (d.parameters && d.parameters.length > 0) {
            let html = `<table class="params-table">
                <thead>
                    <tr><th>Parameter</th><th>Type</th><th>Description</th></tr>
                </thead>
                <tbody>`;
            d.parameters.forEach(p => {
                html += `<tr>
                    <td><code>${escapeHtml(p.name)}</code></td>
                    <td>${escapeHtml(p.type || 'String')}</td>
                    <td>${escapeHtml(p.description)}</td>
                </tr>`;
            });
            html += `</tbody></table>`;
            elements.paramsList.innerHTML = html;
        } else {
            elements.paramsList.innerHTML = '<p class="text-muted">No parameters identified.</p>';
        }

        // Render Nexthink Guide
        if (d.nexthinkNotes) {
            elements.nexthinkGuideText.innerHTML = `<p>${escapeHtml(d.nexthinkNotes)}</p>`;
        }

        // Render Right Panel Code Viewer
        renderCodeViewer();
    }

    function renderCodeViewer() {
        if (!state.data) return;

        let code = '';
        let lang = 'powershell';

        if (state.activeTargetTab === 'ps') {
            code = state.data.psScript || '# No PowerShell script generated.';
            lang = 'powershell';
        } else if (state.activeTargetTab === 'nql') {
            code = state.data.nqlQuery || '// No NQL query generated.';
            lang = 'sql';
        } else if (state.activeTargetTab === 'nqlscript') {
            code = state.data.nqlScript || '// No NQL script payload generated.';
            lang = 'json';
        }

        elements.codeViewer.className = `language-${lang}`;
        elements.codeViewer.textContent = code;
        hljs.highlightElement(elements.codeViewer);

        // Generate line numbers
        const lineCount = code.split('\n').length;
        let numHtml = '';
        for (let i = 1; i <= lineCount; i++) {
            numHtml += `${i}<br>`;
        }
        elements.lineNumbers.innerHTML = numHtml;
    }

    // ------------------------------------------------------------------
    // Copy & Download Functionality
    // ------------------------------------------------------------------
    elements.btnCopyCode.addEventListener('click', () => {
        const code = elements.codeViewer.textContent;
        if (!code) return;

        navigator.clipboard.writeText(code).then(() => {
            const origText = elements.btnCopyCode.innerHTML;
            elements.btnCopyCode.innerHTML = `<i class="fa-solid fa-check"></i> Copied!`;
            setTimeout(() => {
                elements.btnCopyCode.innerHTML = origText;
            }, 2000);
        });
    });

    elements.btnDownloadCode.addEventListener('click', () => {
        const code = elements.codeViewer.textContent;
        if (!code) return;

        let ext = 'ps1';
        let mime = 'text/plain';

        if (state.activeTargetTab === 'nql') {
            ext = 'nql';
        } else if (state.activeTargetTab === 'nqlscript') {
            ext = 'json';
            mime = 'application/json';
        }

        const blob = new Blob([code], { type: mime });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `nexthink_script_${Date.now()}.${ext}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    });

    // ------------------------------------------------------------------
    // Utilities
    // ------------------------------------------------------------------
    function escapeHtml(str) {
        if (!str) return '';
        return str
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function showToast(message) {
        console.log(`[Toast] ${message}`);
    }
});
