@echo off
title Nexthink NQL ^& PowerShell Studio Launcher
color 0A
cls

echo =========================================================================
echo               NEXTHINK NQL ^& POWERSHELL ASSISTANT STUDIO
echo =========================================================================
echo.
echo Launching standalone web application...
echo.

:: Check if Python is available for local HTTP server
where python >nul 2>nul
if %errorlevel%==0 (
    echo [INFO] Python detected. Starting local HTTP web server on port 8080...
    echo [INFO] Access URL: http://localhost:8080
    echo [INFO] Press Ctrl+C in this console window to stop the server.
    echo.
    start "" http://localhost:8080/index.html
    python -m http.server 8080
) else (
    echo [INFO] Python not found. Launching directly in your default browser...
    echo [INFO] Opening index.html directly...
    start "" "%~dp0index.html"
    echo.
    echo Application launched successfully in browser!
    pause
)
