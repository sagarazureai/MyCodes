# Nexthink NQL & PowerShell Assistant Studio

A standalone, zero-dependency web application designed to generate, analyze, and explain Nexthink Query Language (NQL) queries, NQL scripts, and PowerShell (`.ps1`) scripts powered by **Google Gemini 2.5 Flash API**.

---

## Folder Structure

```
d:\Sagar\Python\Sagar\nexthink\
├── index.html               # Main Web App UI Layout
├── styles.css               # Glassmorphism Dark Mode Styling
├── app.js                   # Client Logic & Gemini API Integration
├── run_nql_ps_studio.bat    # 1-Click Windows Launcher Script
└── NQL_PS_STUDIO_README.md  # User Documentation
```

---

## Quick Start / Launching

### Method 1: Double-Click Launcher (Recommended)
Double-click `run_nql_ps_studio.bat` inside the `nexthink` folder.
It will automatically launch `index.html` in your default browser.

### Method 2: PowerShell Terminal
```powershell
cd d:\Sagar\Python\Sagar\nexthink
.\run_nql_ps_studio.bat
```

### Method 3: Direct Open
Double-click `index.html` inside the `nexthink` folder to open it directly in Chrome, Edge, Firefox, or Safari.

---

## Configuration & API Key

- **Pre-configured Key**: Pre-loaded with your active API key (`AQ.Ab8RN6I8Z9S3AX8UDodB7zL8CufKhwaot_9y8i5sP5Uq_oyDNA`).
- **Model**: Defaulting to `gemini-2.5-flash`.
- **Settings**: Click the **Gear icon** in the top right header to update your API key or model selection at any time.
